# PUBLIUS

An independent rebuild of the Hamilton 2.0 dashboard method (Russian, Chinese and Iranian government and state-media
messaging across platforms), extended with an aggregator tier and a statistical model that ranks posts by their chance
of breaking out into US domestic discourse at a level associated with unrest. Named for the pen name Hamilton, Madison
and Jay shared; Federalist No. 68 is where Hamilton warned of "the desire in foreign powers to gain an improper
ascendant in our councils." Not affiliated with the Alliance for Securing Democracy, GMF or ISD.

```
 watchlist (1,259 Hamilton entities + 24 aggregators + 17 state-media sites: 2,640 accounts, 2,367 switched on)
        │
        ▼  collect (read-only: public previews, feeds, official APIs with your keys)
 Telegram · Web/RSS · YouTube · X · Facebook · Instagram · TikTok · VK · Rutube · Odysee · Bluesky · Mastodon · CN hot lists · Discord · Eitaa
        │
        ▼  analyse
 lexicon evidence → narratives (14) → flashpoint coupling → severity S0–S4
 link graph (story links + MinHash; signature links and footers removed) → echo clusters → coordinated link sharing
 velocity vs source baseline
 ordinal breakout model  P(B ≥ k), k = 2..6, 80% credible interval, ICD-203 word, lift, risk index, flag
        │
        ▼  breakout checks at 1 h · 6 h · 24 h · 72 h · 7 d  (counts only)
 Bluesky · Reddit · X counts · Threads · YouTube search · Mastodon · Truth Social · Gab · GDELT (US mainstream news)
        │
        ▼  auto-labels (+ your labels) → calibrate (MAP under priors, IPW, time-split backtest)
 dashboard on http://127.0.0.1:8768  ·  static export  ·  GHOST LOOM pack (ghostloom-pack.json)
```

## New in 1.1

* **GHOST LOOM bridge.** Every post in the window is coded for GHOST LOOM's eight anti-AI seams (data centers,
  militarized AI, the AI bubble, distrust of Western AI, jobs, art and slop, doom, boycott) behind an AI gate, in
  English, Russian, Persian and Chinese (`publius/analysis/ghostloom.py`). The snapshot gains a `ghostloom` section, and
  `export` and `exercise` also write `ghostloom-pack.json`, the file GHOST LOOM's PUBLIUS tab loads.
  `python -m publius ghostloom --out FILE` writes the pack from the store; `--from` builds it from a snapshot JSON or an
  exported dashboard instead (a 1.0 export is coded over the posts it carries and says so).
* **Nothing simulated crosses over.** A pack made from an exercise keeps the real collection, the real brief and the
  lane statuses as they really stand, and leaves out simulated counts, public figures, indicator counts, labels,
  calibration and the breakout scores of measured posts. Items name only the watchlisted outlet or office; posts by
  sources with unverified affiliation are counted, never listed.
* **Rails tightened.** The Weibo hot-search board is refused: its endpoint answers only to a logged-in cookie. The
  Discord bot reads announcement channels only, and the Telegram user session reads broadcast channels only; a chat
  channel or group is its members' conversation even when someone lists it.
* The optional second opinion defaults to `claude-sonnet-5`.

## Install and run

Python 3.11+. `numpy` for calibration; `telethon` only if you want the Telegram user-session lane.

```bash
cd publius
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m publius init          # writes config.toml with a token, imports the watchlists
python -m publius verify        # live-checks Telegram channels, feeds and YouTube channels (~25 min for all)
python -m publius run           # collect → analyse → breakout every 30 min, and serve the dashboard
```

`run` prints a link such as `http://127.0.0.1:8768/#k=<token>`. Open it once; the dashboard remembers the token.
Everything binds to 127.0.0.1 and the API refuses requests without the token.

Other commands: `collect`, `analyse`, `breakout`, `triage`, `cycle`, `serve`, `label <post_id> <1-6>`, `calibrate`,
`export --out DIR`, `exercise --out DIR`, `ghostloom --out FILE [--from FILE]`, `status`, `platforms`, `login telegram`.

### Exercise mode

`python -m publius exercise --out DIR [--seed N] [--opinions FILE]` shows every downstream feature working before
the keys and the calendar allow it. It copies the store and runs the copy through simulated US-audience lanes (X,
Reddit, Bluesky, Threads, YouTube search, TikTok, Truth Social, Mastodon, Gab, GDELT). The real store is never written.
Posts, sources, severity, narratives, coordination, flashpoints and the brief stay real. The simulated parts are the
lane counts, which are drawn from a documented data-generating process with a few scripted injects so every
Breakout Scale level appears; public figures, which are numbered placeholders and never real accounts; indicator
counts; auto-labels; and a dry-run calibration. Every simulated value carries a SIM mark. The result is
`DIR/publius-exercise.html`, with `DIR/ghostloom-pack.json` beside it. `--opinions` records second opinions from a JSON
file exactly as the triage pass does.

## Lanes and what they need

With no keys at all you get Telegram public previews (315 of the 434 listed channels had posted within 30 days when
checked on 24 Sep 2026), the state media websites, the Pravda aggregator network, YouTube channel feeds, the China hot
lists, and GDELT. GDELT is the only breakout lane that needs no key, and it measures level 4 only; level 3 needs two
social lanes (Bluesky, Reddit, X counts).

| Lane | Needs | Notes |
|---|---|---|
| Telegram (user session) | `api_id`, `api_hash` from my.telegram.org, then `python -m publius login telegram` | Reads channels with previews disabled, including Tasnim's 2.5M-subscriber channel |
| X | bearer token; pay-per-use ($0.005/post read, $0.010/user read, $0.005/counts call) | `x.daily_budget_usd` caps spend (default $5/day); handles resolve to numeric ids once |
| YouTube | Data API v3 key (free) | RSS works without it; the key adds statistics and the search lane |
| Bluesky | app password `handle:xxxx-xxxx-xxxx-xxxx` | Needed for breakout search |
| Reddit | OAuth script app (client id/secret) | Breakout lane: counts submissions linking a URL |
| Facebook / Instagram | Graph API token (Page Public Content Access; IG Business Discovery with your IG business id) | App review required |
| Threads | `threads_keyword_search` permission | Breakout lane |
| TikTok | Research API approval (academic / non-profit only) | TikTok's eligibility rules, not ours |
| VK | service token | Russian-domestic lane |
| Discord | bot token; the bot must be invited to the server | Announcement channels on the watchlist only; chat channels are refused |
| Truth Social, Gab | your token | Off by default: cloud IPs are blocked and their terms restrict automated access; your decision |
| Claude second opinion | Anthropic API key, `triage.enabled = true` | Re-reads the top of the queue. Advisory only: scoring keeps the rule severity, and disagreements of 2+ levels are flagged for the analyst |

Platforms with no lawful read route for third parties (WhatsApp, Snapchat, LinkedIn, Pinterest, Nextdoor, Rumble,
GETTR, WeChat/Douyin, Max) stay listed on the Platforms tab; their content is tracked through the links that surface elsewhere.
Weibo's hot-search board is refused because its endpoint needs a logged-in cookie; the Baidu and Toutiao boards are public.

## GHOST LOOM

GHOST LOOM (Ed. 2026.09d and later) has a PUBLIUS tab that reads `ghostloom-pack.json`: the analyst brief, the
AI-seam counts by country and seam, the coded items, narratives, flashpoints, Pravda provenance, coordination, the
operations register, lanes and model priors. Load a new pack with the tab's loader; it stays in the browser.
The seam codes are topic detectors with DALABA's English and Chinese patterns plus Russian and Persian equivalents.
A code says a post raised a topic, never which side it took, and it says nothing about any account that later shares
the post. Coverage is stated in the pack: `window` when coded from the store, `carried` when coded from an export.

## The model in one paragraph

The outcome is the Breakout Scale level (Nimmo, Brookings 2020) a post reaches in US-audience lanes within 7 days. A
proportional-odds model gives P(B ≥ k) for k = 2..6 from 22 features: content (US-domestic subject, wedge issues,
out-group terms, moral-emotional and negative language, known falsehoods, delegitimisation, calls to action, violence),
context (coupling to a live US flashpoint), source (audience, platform US reach, tier, language) and diffusion (early
engagement against the source's own baseline, echo across sources, RU/CN/IR convergence, extra platforms, pickups so
far). Priors come from published effect sizes where they exist (Rathje 2021, Brady 2017, Vosoughi 2018, Robertson 2023,
Szabo & Huberman 2010, Giglietto 2020) and analyst judgement where they do not; every prior is listed on the Model tab.
Severity (S0–S4) is scored separately and multiplies P(B ≥ 3) into the risk index. `publius calibrate` refits on
observed outcomes and only switches the dashboard over once there are at least 200 labelled posts including 10 at
level 3+. It trains on the features as they stood when a post was first scored (and only on posts first scored within
6 hours of publication), so no feature already contains the outcome; weights each label by the inverse of the selection
probability fixed at that moment (rule, or a 5% audit draw), rescaled to the Kish effective sample size; drops labels
where fewer than two social lanes answered (levels 2 and 3 cannot be told apart otherwise); and backtests on a later
time split purged of one horizon.

What it does not claim: that a single foreign post causes unrest. The strongest studies find small direct effects of
foreign posts on US attitudes and behaviour (Eady et al. 2023; Bail et al. 2020). The measurable risk is amplification
of domestic grievances that are already live, which is what the flashpoint and diffusion terms capture.

## What the dashboard shows

Brief (BLUF, key judgments, KPIs, operations with indicator counts) · Overview (the Hamilton panels) · Search · Trends
(Fightin' Words) · Unrest Watch (probability × severity, flags, second-opinion filter) · Narratives · Breakout (lanes,
measured posts by level, outcome labels, injects in exercise mode) · Coordination (echo clusters, coordinated link
sharing, aggregator provenance) · Flashpoints (GDELT salience) · Watchlist · Platforms (US reach, access, collection
health, API spend) · Model (priors, calibration backtest against the prior, reliability diagram, fitted coefficients)
· Method. Each post opens a drawer with its probabilities, the terms that move them, per-lane pickup charts at every
check, the second opinion, its label, and a form to record the observed outcome.

## Rails

* Read-only everywhere. No posting, reacting, following, joining or DMs; no self-bots; no scraping behind logins or bot walls.
* Watchlist inclusion follows the Hamilton rule: overt state accounts, plus aggregators with documented, graded state linkage.
* No profiles of US persons. Breakout lanes store counts; an account is named only at or above the public-figure
  threshold (default 100,000 followers). Upstream channels an aggregator names are shown as provenance and never scored.
* Individuals from the Nov 2023 Hamilton list: media personalities are off by default (the list includes US persons);
  officials are collected but hidden from the Unrest Watch, and capped at WATCH, until their current role is re-verified.
* Aggregators whose state linkage is not independently evidenced are parked as candidates: listed, never collected or scored.
* The watchlist files are the switch. Turning a source off (or dropping it) and re-running `init` deletes what was
  collected from it.
* Loopback only. The server answers only to its loopback Host header (no DNS rebinding), needs the token on every API
  call (it generates one for the session if the config has none), and accepts same-origin JSON POSTs only.
* Broadcast only. Discord announcement channels, Telegram broadcast channels, public boards. Login-gated endpoints are
  refused even when a config supplies a cookie.
* robots.txt is not consulted: collection reads public previews, feeds and official APIs a platform serves for this
  purpose. Operators who want robots.txt honoured should add a check in `util.http_get` before running at scale.

## Files

```
publius/            package (connectors/, analysis/, dashboard/, data/)
watchlists/         hamilton_base.json · aggregators.json (+ covert-operation indicators) · verification.json
scripts/            build_watchlists.py (rebuilds the watchlists from the published Hamilton list)
tests/              test_offline.py (37 tests, no network)
config.example.toml
```
