"""PUBLIUS — an independent rebuild of the Hamilton 2.0 method (Russian, Chinese and Iranian state and state-aligned
messaging across platforms) with a US domestic-unrest breakout model. Not affiliated with ASD, GMF or ISD."""
__version__ = "1.1.0"
