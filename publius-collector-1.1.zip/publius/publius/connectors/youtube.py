"""YouTube: keyless channel RSS (last 15 uploads with view counts) for collection and verification; the Data API v3
(optional key) adds statistics and powers the breakout search lane (search.list costs 100 quota units per call, so
the lane only runs for posts already selected for breakout checks)."""
from __future__ import annotations

import time
from typing import Optional

from ..util import HttpError, http_get, http_get_json, sha1
from .base import Connector, SearchResult, Stats, register
from .rss import parse_feed

API = "https://www.googleapis.com/youtube/v3/"


@register
class YouTube(Connector):
    platform = "youtube"
    label = "YouTube"
    breakout_lane = True
    search_requires = ("api_key",)      # collection runs on public RSS; search needs the Data API

    def feed_url(self, handle: str) -> str:
        if handle.startswith("UC") and len(handle) == 24:
            return f"https://www.youtube.com/feeds/videos.xml?channel_id={handle}"
        return f"https://www.youtube.com/feeds/videos.xml?user={handle}"

    def fetch(self, handle: str) -> tuple[str, list[dict]]:
        return parse_feed(http_get(self.feed_url(handle), browser=True))

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                title, items = self.fetch(s["handle"])
                last = max([i["ts"] or 0 for i in items] or [0]) or None
                age = (time.time() - last) / 86400 if last else None
                st = "live" if age is not None and age <= 30 else ("stale" if last else "empty")
                note = f"{len(items)} uploads in feed; newest {age:.0f} d ago" if age is not None else "no uploads in feed"
                self.store.set_source_status(s["id"], st, note, last_post_ts=last, name=title or None)
                res.append({"id": s["id"], "status": st, "note": note, "title": title})
            except HttpError as e:
                st = "dead" if e.status == 404 else "error"
                note = "channel terminated or not found (feed 404)" if e.status == 404 else str(e)
                self.store.set_source_status(s["id"], st, note)
                res.append({"id": s["id"], "status": st, "note": note})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            _, items = self.fetch(src["handle"])
            n, newest = 0, None
            for it in items:
                newest = max(newest or 0, it["ts"] or 0)
                if self.emit(src, sha1(it["guid"]), it["ts"], it["body"], url=it["link"], title=it["title"], media={"video": 1}, metrics={"views": it["views"]}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        key = str(self.cfg.get("api_key", "")).strip()
        if not key:
            return SearchResult("youtube", ok=False, note="youtube.api_key not set")
        if kind != "phrase":        # search.list costs 100 units; URLs and hashtags do not work as YouTube queries
            return SearchResult("youtube", ok=False, note="phrase queries only")
        q = f"\"{query}\"" if kind == "phrase" else query
        params = {"part": "snippet", "q": q, "type": "video", "maxResults": 50, "key": key, "order": "date", "regionCode": "US"}
        if since:
            params["publishedAfter"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(since))
        r = http_get_json(API + "search", params=params)
        items = r.get("items") or []
        wl = {s["handle"].lower() for s in self.store.sources(platform="youtube")}
        ch_ids = [i["snippet"]["channelId"] for i in items if i["snippet"]["channelId"].lower() not in wl]
        pf, reach = [], None
        thr = int(self.all.get("model", {}).get("public_figure_followers", 100000))
        for chunk in [ch_ids[i:i + 50] for i in range(0, len(ch_ids), 50)]:
            c = http_get_json(API + "channels", params={"part": "snippet,statistics", "id": ",".join(sorted(set(chunk))), "key": key})
            for ch in c.get("items") or []:
                subs = int((ch.get("statistics") or {}).get("subscriberCount") or 0)
                reach = max(reach or 0, subs)
                if subs >= thr:
                    pf.append("yt:" + (ch["snippet"].get("customUrl") or ch["snippet"]["title"]))
        return SearchResult("youtube", count=len(ch_ids), reach_max=reach, public_figures=sorted(set(pf))[:10], note=f"search.list q={q[:60]}")
