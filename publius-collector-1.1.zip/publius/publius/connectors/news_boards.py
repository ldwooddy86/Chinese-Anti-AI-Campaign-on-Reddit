"""GDELT (keyless): the cross-medium breakout lane (US-sourced mainstream coverage of a phrase) and a flashpoint salience
series. China hot lists: the Baidu and Toutiao trending boards (public JSON), filtered to entries about the United
States — a read of what Chinese domestic aggregators are surfacing about America. Weibo's board is refused: its
hot-search endpoint answers only to a logged-in cookie, and PUBLIUS never reads behind a login."""
from __future__ import annotations

import json
import time
from typing import Optional

from ..analysis.lexicon import match_all
from ..util import HttpError, day, http_get, http_get_json, now, sha1
from .base import Connector, SearchResult, Stats, register

GDELT = "https://api.gdeltproject.org/api/v2/doc/doc"
STATE_DOMAINS = ["rt.com", "sputnikglobe.com", "tass.com", "cgtn.com", "globaltimes.cn", "news.cn", "xinhuanet.com", "chinadaily.com.cn", "people.cn", "presstv.ir",
                 "tasnimnews.com", "farsnews.ir", "irna.ir", "mehrnews.com", "tehrantimes.com", "news-pravda.com", "southfront.press", "strategic-culture.su"]


@register
class Gdelt(Connector):
    platform = "gdelt"
    label = "GDELT DOC 2.0 (news; cross-medium breakout)"
    breakout_lane = True

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        """Salience: 7-day volume timeline (% of monitored US coverage) for each active flashpoint's anchor terms."""
        st = Stats()
        if not self.cfg.get("salience", True):
            return st
        from ..analysis.features import flashpoints
        for f in flashpoints():
            if f.get("status") not in ("active", "scheduled"):
                continue
            terms = " OR ".join(f'"{a}"' for a in f.get("anchors", [])[:4])
            if not terms:
                continue
            try:
                r = json.loads(http_get(GDELT, params={"query": f"({terms}) sourcecountry:US", "mode": "timelinevol", "format": "json", "timespan": "14d"}, timeout=40).decode("utf-8", "replace") or "{}")
                for series in r.get("timeline") or []:
                    for pt in series.get("data") or []:
                        d = str(pt.get("date", ""))[:8]
                        if len(d) == 8:
                            self.store.set_salience(f["id"], f"{d[:4]}-{d[4:6]}-{d[6:]}", float(pt.get("value") or 0.0), "gdelt")
                st.sources += 1
            except (HttpError, ValueError) as e:
                st.errors.append(f"{f['id']}: {e}")
        return st

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        """US mainstream coverage (Breakout Scale level 4). Only articles first seen AFTER the foreign post count, so a
        state outlet quoting a US wire story is not mistaken for the US press picking up the state outlet."""
        if kind != "phrase":
            return SearchResult("gdelt", ok=False, note="GDELT matches article text: phrase queries only")
        excl = " ".join(f"-domain:{d}" for d in STATE_DOMAINS[:10])
        q = (f'"{query}"' if kind == "phrase" else query) + f" sourcecountry:US sourcelang:english {excl}"
        span = "7d" if not since else f"{max(1, min(7, int((now() - since) / 86400) + 1))}d"
        raw = http_get(GDELT, params={"query": q, "mode": "artlist", "maxrecords": 75, "format": "json", "timespan": span}, timeout=40).decode("utf-8", "replace")
        try:
            arts = (json.loads(raw) or {}).get("articles") or []
        except ValueError:
            return SearchResult("gdelt", ok=False, note=raw[:120])
        if since:
            from ..util import parse_iso as _pi
            def seen(a):
                v = str(a.get("seendate", ""))
                return _pi(f"{v[:4]}-{v[4:6]}-{v[6:8]}T{v[9:11]}:{v[11:13]}:{v[13:15]}Z") if len(v) >= 15 else None
            arts = [a for a in arts if (seen(a) or 0) >= since]
        doms = sorted({a.get("domain", "") for a in arts})
        return SearchResult("gdelt", count=len(arts), note="US outlets: " + ", ".join(doms[:8]))


US_WORDS = ["美国", "美方", "特朗普", "华盛顿", "白宫", "美军", "美股", "美联储"]
BOARDS = ("baidu", "toutiao")                 # public boards only
REFUSED_BOARDS = {"weibo": "Weibo's hot-search endpoint needs a logged-in cookie; PUBLIUS never reads behind a login"}


@register
class CnHotlist(Connector):
    platform = "cn_hotlist"
    label = "China hot lists (Baidu / Toutiao)"

    def board(self, name: str) -> list[dict]:
        if name == "baidu":
            r = http_get_json("https://top.baidu.com/api/board", params={"platform": "wise", "tab": "realtime"})
            cards = ((r.get("data") or {}).get("cards") or [])
            out = []
            for c in cards:
                for grp in c.get("content") or []:
                    items = grp.get("content") if isinstance(grp, dict) and isinstance(grp.get("content"), list) else [grp]
                    for it in items:
                        if isinstance(it, dict) and (it.get("word") or it.get("query")):
                            out.append({"title": it.get("word") or it.get("query"), "desc": it.get("desc", ""), "url": it.get("url") or it.get("rawUrl") or "", "heat": int(it.get("hotScore") or 0)})
            return out
        if name == "toutiao":
            r = http_get_json("https://www.toutiao.com/hot-event/hot-board/", params={"origin": "toutiao_pc"})
            return [{"title": d.get("Title", ""), "desc": "", "url": d.get("Url", ""), "heat": int(d.get("HotValue") or 0)} for d in r.get("data") or []]
        if name in REFUSED_BOARDS:
            raise HttpError(403, "refused: " + REFUSED_BOARDS[name])
        raise HttpError(400, f"unknown board {name}")

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        boards = set(self.cfg.get("boards", list(BOARDS))) & set(BOARDS)

        def one(src: dict):
            name = src["handle"]
            if name not in boards:
                return 0, None
            n = 0
            for rank, it in enumerate(self.board(name), 1):
                text = (it["title"] or "") + " " + (it["desc"] or "")
                if not any(w in text for w in US_WORDS) and not match_all(text, "zh").get("us_anchor"):
                    continue
                # one post per (board, title, day): a trending entry is re-observed, not re-posted
                if self.emit(src, sha1(name, it["title"], day(now())), now(), it["desc"] or it["title"], url=it["url"], title=it["title"], metrics={"views": it["heat"], "rank": rank}):
                    n += 1
            return n, now()
        return self.run_sources(one, max_sources)
