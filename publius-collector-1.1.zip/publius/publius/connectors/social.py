"""Bluesky (AT Protocol), the Mastodon API family (Mastodon, Truth Social, Gab) and Reddit.

Bluesky author feeds are public; post search needs an app password (the public AppView refuses unauthenticated search).
Truth Social and Gab expose Mastodon-compatible APIs but block cloud IP ranges and restrict automated access in their
terms: they are off by default, need the operator's own token, and are the operator's call to enable.
Reddit is a breakout lane only (no watchlist accounts post there): /api/info?url= counts submissions linking a URL."""
from __future__ import annotations

import base64
import time
from typing import Optional

from ..analysis.lexicon import match_all
from ..util import HttpError, http_get_json, http_post_form, http_post_json, now, parse_iso
from .base import Connector, SearchResult, Stats, register


def _vm(texts) -> int:
    n = 0
    for t in texts:
        ev = match_all(t or "", "en")
        if ev.get("violence_endorse") or ev.get("mobilization_call"):
            n += 1
    return n


@register
class Bluesky(Connector):
    platform = "bluesky"
    label = "Bluesky (AT Protocol)"
    breakout_lane = True
    search_requires = ("app_password",)
    PUBLIC = "https://public.api.bsky.app/xrpc/"

    def search_ready(self) -> tuple[bool, str]:
        ok, why = super().search_ready()
        if ok and ":" not in str(self.cfg.get("app_password", "")):
            return False, "bluesky.app_password must be 'handle:app-password'"
        return ok, why

    def _session(self) -> tuple[str, dict]:
        ap = str(self.cfg.get("app_password", "")).strip()
        if ":" not in ap:
            raise HttpError(401, "bluesky.app_password must be 'handle:app-password' for search")
        tok = getattr(self, "_tok", None)
        if tok and tok[1] > time.time():
            return "https://bsky.social/xrpc/", {"Authorization": f"Bearer {tok[0]}"}
        ident, pw = ap.split(":", 1)
        r = http_post_json("https://bsky.social/xrpc/com.atproto.server.createSession", {"identifier": ident.lstrip("@"), "password": pw})
        self._tok = (r["accessJwt"], time.time() + 3000)
        return "https://bsky.social/xrpc/", {"Authorization": f"Bearer {r['accessJwt']}"}

    def watch_sources(self) -> list[dict]:
        extra = [{"id": f"bluesky:{h.lower()}", "handle": h, "platform": "bluesky", "country": "", "category": "media"} for h in self.cfg.get("handles", [])]
        return super().watch_sources() + [e for e in extra if self.store.source(e["id"])]

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            r = http_get_json(self.PUBLIC + "app.bsky.feed.getAuthorFeed", params={"actor": src["handle"], "limit": 50, "filter": "posts_no_replies"})
            n, newest = 0, None
            for f in r.get("feed") or []:
                p = f.get("post") or {}
                if (f.get("reason") or {}).get("$type", "").endswith("reasonRepost"):
                    continue
                rec = p.get("record") or {}
                ts = parse_iso(rec.get("createdAt", "")) or now()
                newest = max(newest or 0, ts)
                emb = p.get("embed") or {}
                ext = ((emb.get("external") or {}).get("uri"),) if emb.get("external") else ()
                media = {"video": 1} if str(emb.get("$type", "")).endswith("video#view") else ({"photo": len(emb.get("images") or [])} if emb.get("images") else {})
                rkey = str(p.get("uri", "")).rsplit("/", 1)[-1]
                if self.emit(src, p.get("uri", rkey), ts, rec.get("text", ""), url=f"https://bsky.app/profile/{src['handle']}/post/{rkey}", media=media,
                             metrics={"likes": p.get("likeCount"), "shares": p.get("repostCount"), "replies": p.get("replyCount")}, extra_urls=tuple(x for x in ext if x)):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)

    def search(self, query: str, kind: str = "url", since: Optional[int] = None) -> SearchResult:
        try:
            base, auth = self._session()
        except HttpError as e:
            return SearchResult("bluesky", ok=False, note=str(e))
        params = {"q": query if kind != "phrase" else f"\"{query}\"", "limit": 100, "sort": "latest"}
        if since:
            params["since"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(since))
        if kind == "url":
            params = {"q": query, "url": query, "limit": 100, "sort": "latest"}
            if since:
                params["since"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(since))
        r = http_get_json(base + "app.bsky.feed.searchPosts", headers=auth, params=params)
        posts = r.get("posts") or []
        wl = {s["handle"].lower() for s in self.store.sources(platform="bluesky")}
        posts = [p for p in posts if (p.get("author") or {}).get("handle", "").lower() not in wl]
        dids = sorted({(p.get("author") or {}).get("did") for p in posts if (p.get("author") or {}).get("did")})
        thr = int(self.all.get("model", {}).get("public_figure_followers", 100000))
        pf, reach = [], None
        for i in range(0, len(dids), 25):
            pr = http_get_json(base + "app.bsky.actor.getProfiles", headers=auth, params={"actors": dids[i:i + 25]})
            for prof in pr.get("profiles") or []:
                fc = int(prof.get("followersCount") or 0)
                reach = max(reach or 0, fc)
                if fc >= thr:
                    pf.append("@" + prof.get("handle", ""))
        return SearchResult("bluesky", count=len(posts), reach_max=reach, public_figures=sorted(set(pf))[:10],
                            violent_or_mobilising=_vm((p.get("record") or {}).get("text", "") for p in posts), note=f"{kind}:{query[:60]}")


class _MastodonFamily(Connector):
    """Shared Mastodon-API logic. instance(s) come from config; watchlist handles are user@instance."""
    breakout_lane = True
    search_requires = ("token",)
    default_instance = "mastodon.social"

    def _inst_tok(self) -> tuple[str, str]:
        insts = self.cfg.get("instances") or [self.cfg.get("instance") or self.default_instance]
        return insts[0], str(self.cfg.get("token", "")).strip()

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        inst0, tok = self._inst_tok()
        h = {"Authorization": f"Bearer {tok}"} if tok else {}

        def one(src: dict):
            acct = src["handle"].lstrip("@")
            user, inst = (acct.split("@", 1) + [inst0])[:2]
            a = http_get_json(f"https://{inst}/api/v1/accounts/lookup", headers=h, params={"acct": user})
            self.store.set_source_status(src["id"], "live", "", followers=a.get("followers_count"))
            r = http_get_json(f"https://{inst}/api/v1/accounts/{a['id']}/statuses", headers=h, params={"limit": 40, "exclude_replies": "true", "exclude_reblogs": "true"})
            n, newest = 0, None
            for s in r:
                ts = parse_iso(s.get("created_at", "")) or now()
                newest = max(newest or 0, ts)
                card = (s.get("card") or {}).get("url")
                media = {"video": 1} if any(m.get("type") in ("video", "gifv") for m in s.get("media_attachments") or []) else ({"photo": 1} if s.get("media_attachments") else {})
                if self.emit(src, s.get("uri") or s.get("id"), ts, s.get("content", ""), url=s.get("url", ""), media=media,
                             metrics={"likes": s.get("favourites_count"), "shares": s.get("reblogs_count"), "replies": s.get("replies_count")}, extra_urls=((card,) if card else ())):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)

    def search(self, query: str, kind: str = "url", since: Optional[int] = None) -> SearchResult:
        inst, tok = self._inst_tok()
        if not tok:
            return SearchResult(self.platform, ok=False, note=f"{self.platform}.token needed for status search")
        r = http_get_json(f"https://{inst}/api/v2/search", headers={"Authorization": f"Bearer {tok}"}, params={"q": query, "type": "statuses", "limit": 40, "resolve": "false"})
        sts = r.get("statuses") or []
        if since:
            sts = [s for s in sts if (parse_iso(s.get("created_at", "")) or 0) >= since]
        thr = int(self.all.get("model", {}).get("public_figure_followers", 100000))
        pf = sorted({"@" + (s.get("account") or {}).get("acct", "") for s in sts if int((s.get("account") or {}).get("followers_count") or 0) >= thr})
        reach = max([int((s.get("account") or {}).get("followers_count") or 0) for s in sts] or [0]) or None
        return SearchResult(self.platform, count=len(sts), reach_max=reach, public_figures=pf[:10], violent_or_mobilising=_vm(s.get("content", "") for s in sts), note=f"{kind}:{query[:60]}")


@register
class Mastodon(_MastodonFamily):
    platform = "mastodon"
    label = "Mastodon / fediverse"


@register
class TruthSocial(_MastodonFamily):
    platform = "truthsocial"
    label = "Truth Social (Mastodon-compatible API, opt-in)"
    requires = ("token",)
    default_instance = "truthsocial.com"

    def _inst_tok(self):
        return "truthsocial.com", str(self.cfg.get("token", "")).strip()


@register
class Gab(_MastodonFamily):
    platform = "gab"
    label = "Gab (Mastodon-derived API, opt-in)"
    requires = ("token",)
    default_instance = "gab.com"

    def _inst_tok(self):
        return "gab.com", str(self.cfg.get("token", "")).strip()


@register
class Reddit(Connector):
    platform = "reddit"
    label = "Reddit (OAuth; breakout lane)"
    requires = ("client_id", "client_secret")
    breakout_lane = True

    def _token(self) -> str:
        tok = getattr(self, "_tok", None)
        if tok and tok[1] > time.time():
            return tok[0]
        basic = base64.b64encode(f"{self.cfg['client_id']}:{self.cfg['client_secret']}".encode()).decode()
        r = http_post_form("https://www.reddit.com/api/v1/access_token", {"grant_type": "client_credentials"}, headers={"Authorization": f"Basic {basic}", "User-Agent": self.cfg.get("user_agent", "publius/1.0")})
        self._tok = (r.get("access_token", ""), time.time() + int(r.get("expires_in", 3600)) - 60)
        return self._tok[0]

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        return Stats()

    def search(self, query: str, kind: str = "url", since: Optional[int] = None) -> SearchResult:
        h = {"Authorization": f"Bearer {self._token()}", "User-Agent": self.cfg.get("user_agent", "publius/1.0")}
        if kind == "url":
            # /api/info matches the exact submitted URL string, so try the common spellings of the canonical form
            from urllib.parse import urlsplit, urlunsplit
            u = urlsplit(query)
            variants = [query, urlunsplit((u.scheme, "www." + u.netloc, u.path, u.query, "")), query.rstrip("/") + "/", urlunsplit((u.scheme, "www." + u.netloc, u.path.rstrip("/") + "/", u.query, ""))]
            kids, seen = [], set()
            for v in variants:
                r = http_get_json("https://oauth.reddit.com/api/info", headers=h, params={"url": v, "limit": 100})
                for c in ((r.get("data") or {}).get("children") or []):
                    d = c.get("data") or {}
                    if d.get("name") not in seen:
                        seen.add(d.get("name")); kids.append(d)
        elif kind == "phrase":
            r = http_get_json("https://oauth.reddit.com/search", headers=h, params={"q": f"\"{query}\"", "sort": "new", "t": "week", "limit": 100, "raw_json": 1})
            kids = [c.get("data") or {} for c in ((r.get("data") or {}).get("children") or [])]
        else:
            return SearchResult("reddit", ok=False, note="hashtags are not a Reddit construct")
        if since:
            kids = [k for k in kids if int(k.get("created_utc") or 0) >= since]
        # posts on user profiles are counted but never named: only public subreddits appear in the note
        subs = sorted({k.get("subreddit_name_prefixed", "") for k in kids if k.get("subreddit_type") != "user" and not str(k.get("subreddit_name_prefixed", "")).startswith("u/")})
        reach = max([int(k.get("subreddit_subscribers") or 0) for k in kids] or [0]) or None
        return SearchResult("reddit", count=len(kids), reach_max=reach, public_figures=[], violent_or_mobilising=_vm((k.get("title", "") + " " + k.get("selftext", "")) for k in kids),
                            note=f"{kind}; subreddits: {', '.join(subs[:5])}")
