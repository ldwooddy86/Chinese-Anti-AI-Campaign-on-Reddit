"""X (Twitter) API v2 under pay-per-use pricing (reads $0.005 per post, $0.010 per user; recent counts $0.005 per request;
capped at 3M post reads a month — see docs.x.com). A daily budget governor stops the lane before it overspends.

Collection resolves each watchlist handle to its stable numeric id once (handles rotate — ISD found 80% of one pro-Iran
network renamed during the war) and then pulls timelines since the last seen post id, highest-priority categories first.
Breakout uses the cheap recent-counts endpoint; a paid post pull for public-figure detection only runs when counts pass
the pickup threshold and the budget allows."""
from __future__ import annotations

import json
import time
from typing import Optional

from ..util import HttpError, day, http_get_json, now, parse_iso, sha1
from .base import Connector, SearchResult, Stats, register

API = "https://api.x.com/2/"
PRICE = {"post": 0.005, "user": 0.010, "counts": 0.005}


@register
class XApi(Connector):
    platform = "x"
    label = "X (API v2, pay-per-use)"
    requires = ("bearer_token",)
    breakout_lane = True

    def _h(self) -> dict:
        return {"Authorization": f"Bearer {self.cfg['bearer_token']}"}

    def _budget_left(self) -> float:
        return float(self.cfg.get("daily_budget_usd", 5.0)) - self.store.spend_today(day(now()), "x")

    def _spend(self, usd: float, units: int = 1) -> None:
        self.store.add_spend(day(now()), "x", usd, units)

    def _user_ids(self, sources: list[dict]) -> dict[str, dict]:
        """Resolve handles to ids in batches of 100 (cached in the store's kv)."""
        cache = json.loads(self.store.kv_get("x_user_ids", "{}") or "{}")
        need = [s["handle"] for s in sources if s["handle"].lower() not in cache]
        for i in range(0, len(need), 100):
            if self._budget_left() < PRICE["user"] * len(need[i:i + 100]):
                break
            batch = need[i:i + 100]
            r = http_get_json(API + "users/by", headers=self._h(), params={"usernames": ",".join(batch), "user.fields": "public_metrics,created_at"})
            self._spend(PRICE["user"] * len(r.get("data") or []), len(r.get("data") or []))
            for u in r.get("data") or []:
                cache[u["username"].lower()] = {"id": u["id"], "followers": (u.get("public_metrics") or {}).get("followers_count")}
            for e in r.get("errors") or []:
                v = str(e.get("value", "")).lower()
                if v:
                    cache[v] = {"id": None, "error": e.get("title") or e.get("detail", "")[:80]}
        self.store.kv_set("x_user_ids", json.dumps(cache))
        return cache

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        st = Stats()
        prio = {c: i for i, c in enumerate(self.cfg.get("priority", ["media", "aggregator", "gov"]))}
        srcs = sorted(self.watch_sources(), key=lambda s: (prio.get(s.get("category"), 9), -(s.get("followers") or 0), s.get("last_run") or 0))
        if max_sources:
            srcs = srcs[:max_sources]
        ids = self._user_ids(srcs)
        per = int(self.cfg.get("max_results", 20))
        for s in srcs:
            if self._budget_left() < PRICE["post"] * per:
                st.errors.append(f"daily budget reached (${self.cfg.get('daily_budget_usd')}); {len(srcs) - st.sources} sources deferred")
                break
            info = ids.get(s["handle"].lower()) or {}
            if not info.get("id"):
                self.store.set_source_status(s["id"], "not_found", info.get("error", "handle did not resolve")); continue
            st.sources += 1
            try:
                params = {"max_results": max(5, min(100, per)), "tweet.fields": "created_at,public_metrics,entities,attachments,referenced_tweets", "exclude": "retweets"}
                if s.get("cursor"):
                    params["since_id"] = s["cursor"]
                r = http_get_json(API + f"users/{info['id']}/tweets", headers=self._h(), params=params)
                data = r.get("data") or []
                self._spend(PRICE["post"] * len(data), len(data))
                n, newest, top = 0, None, s.get("cursor")
                for t in data:
                    ts = parse_iso(t.get("created_at", "")) or now()
                    newest = max(newest or 0, ts)
                    top = t["id"] if not top or int(t["id"]) > int(top) else top
                    pm = t.get("public_metrics") or {}
                    urls = [u.get("expanded_url") for u in ((t.get("entities") or {}).get("urls") or []) if u.get("expanded_url")]
                    media = {"photo": 1} if (t.get("attachments") or {}).get("media_keys") else {}
                    if self.emit(s, t["id"], ts, t.get("text", ""), url=f"https://x.com/{s['handle']}/status/{t['id']}", media=media,
                                 metrics={"views": pm.get("impression_count"), "likes": pm.get("like_count"), "shares": pm.get("retweet_count", 0) + pm.get("quote_count", 0), "replies": pm.get("reply_count")},
                                 extra_urls=tuple(urls)):
                        n += 1
                if info.get("followers"):
                    self.store.set_source_status(s["id"], "live", "", followers=info["followers"])
                self.store.source_ok(s["id"], top, n, newest)
                st.items += n
            except HttpError as e:
                self.store.source_error(s["id"], str(e)); st.errors.append(f"{s['handle']}: {e}")
        return st

    def search(self, query: str, kind: str = "url", since: Optional[int] = None, source_handle: Optional[str] = None) -> SearchResult:
        if self._budget_left() < PRICE["counts"]:
            return SearchResult("x", ok=False, note="daily budget reached")
        q = (f'url:"{query}"' if kind == "url" else (query if kind == "hashtag" else f'"{query}"')) + " -is:retweet lang:en"
        if source_handle:
            q += f" -from:{source_handle.lstrip('@')}"      # the originating account's own reposts are not a breakout
        params = {"query": q, "granularity": "day"}
        if since:
            params["start_time"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(max(since, now() - 6 * 86400)))
        r = http_get_json(API + "tweets/counts/recent", headers=self._h(), params=params)
        self._spend(PRICE["counts"])
        total = int((r.get("meta") or {}).get("total_tweet_count") or 0)
        res = SearchResult("x", count=total, cost_usd=0.0, note=q[:80])
        k = int(self.all.get("model", {}).get("breakout_min_pickups", 3))
        if total >= k and self._budget_left() > 1.0:
            thr = int(self.all.get("model", {}).get("public_figure_followers", 100000))
            s = http_get_json(API + "tweets/search/recent", headers=self._h(), params={"query": q, "max_results": 50, "expansions": "author_id", "user.fields": "public_metrics,username", "tweet.fields": "text"})
            users = (s.get("includes") or {}).get("users") or []
            self._spend(PRICE["post"] * len(s.get("data") or []) + PRICE["user"] * len(users))
            wl = {x["handle"].lower() for x in self.store.sources(platform="x")}
            from ..analysis.lexicon import match_all
            vm = 0
            for t in s.get("data") or []:
                ev = match_all(t.get("text", ""), "en")
                if ev.get("violence_endorse") or ev.get("mobilization_call"):
                    vm += 1
            reach = 0
            for u in users:
                f = (u.get("public_metrics") or {}).get("followers_count") or 0
                if u.get("username", "").lower() in wl:
                    continue
                reach = max(reach, f)
                if f >= thr:
                    res.public_figures.append("@" + u["username"])
            res.reach_max, res.violent_or_mobilising = reach or None, vm
            res.public_figures = sorted(set(res.public_figures))[:10]
        return res
