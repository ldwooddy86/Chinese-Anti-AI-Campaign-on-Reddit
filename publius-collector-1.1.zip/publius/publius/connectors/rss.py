"""RSS/Atom: state-media websites, MFA statement feeds, the Pravda aggregator network, Odysee and other feed-publishing
platforms. Keyless. For aggregator feeds the upstream channels each item names (t.me/<x>, max.ru/<x>) are recorded as
provenance so the laundering graph can be drawn."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Optional

from ..util import HttpError, clean_text, http_get, parse_iso, sha1
from .base import Connector, Stats, register

NS = {"atom": "http://www.w3.org/2005/Atom", "media": "http://search.yahoo.com/mrss/", "content": "http://purl.org/rss/1.0/modules/content/",
      "dc": "http://purl.org/dc/elements/1.1/", "yt": "http://www.youtube.com/xml/schemas/2015"}
UPSTREAM_RX = re.compile(r"https?://(?:t\.me|max\.ru)/(?!addlist|share|joinchat|\+|s/)([A-Za-z0-9_]{4,64})", re.I)


_BAD_AMP = re.compile(rb"&(?!(?:[A-Za-z]{2,8}|#[0-9]{1,6}|#x[0-9A-Fa-f]{1,6});)")
_CTRL = re.compile(rb"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _lenient_root(raw: bytes):
    """Official feeds (mid.ru, fmprc) are often malformed XML: repair bare ampersands and control bytes, then retry;
    as a last resort rebuild a minimal RSS document from the <item> blocks."""
    fixed = _BAD_AMP.sub(b"&amp;", _CTRL.sub(b" ", raw))
    try:
        return ET.fromstring(fixed)
    except ET.ParseError:
        items = re.findall(rb"(?is)<item\b.*?</item>", fixed)
        title = re.search(rb"(?is)<title>(.*?)</title>", fixed)
        out = [b"<rss><channel><title>", (title.group(1) if title else b"feed"), b"</title>"]
        for it in items:
            t = re.search(rb"(?is)<title>(.*?)</title>", it); l = re.search(rb"(?is)<link>(.*?)</link>", it)
            d = re.search(rb"(?is)<description>(.*?)</description>", it); pd = re.search(rb"(?is)<pubDate>(.*?)</pubDate>", it)
            esc = lambda m: re.sub(rb"[<>&]", b" ", re.sub(rb"(?is)<!\[CDATA\[|\]\]>", b"", m.group(1))) if m else b""
            out.append(b"<item><title>" + esc(t) + b"</title><link>" + esc(l).strip() + b"</link><description>" + esc(d) + b"</description><pubDate>" + esc(pd) + b"</pubDate></item>")
        out.append(b"</channel></rss>")
        return ET.fromstring(b"".join(out))


def parse_feed(raw: bytes) -> tuple[str, list[dict]]:
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        root = _lenient_root(raw)
    title = root.findtext("channel/title") or root.findtext("atom:title", namespaces=NS) or ""
    out = []
    entries = root.findall("channel/item") or root.findall("atom:entry", NS)
    for e in entries[:120]:
        atom = e.tag.endswith("entry")
        t = (e.findtext("atom:title", namespaces=NS) if atom else e.findtext("title")) or ""
        if atom:
            link = next((l.get("href") for l in e.findall("atom:link", NS) if l.get("rel") in (None, "alternate")), "")
        else:
            link = e.findtext("link") or ""
        body = e.findtext("content:encoded", namespaces=NS) or e.findtext("description") or ""
        if atom and not body:
            body = e.findtext("atom:content", namespaces=NS) or e.findtext("atom:summary", namespaces=NS) or (e.findtext("media:group/media:description", namespaces=NS) or "")
        when = e.findtext("pubDate") or e.findtext("dc:date", namespaces=NS) or (e.findtext("atom:published", namespaces=NS) or e.findtext("atom:updated", namespaces=NS) if atom else "")
        guid = e.findtext("guid") or (e.findtext("atom:id", namespaces=NS) if atom else "") or link
        media = {}
        if e.findall("media:content", NS) or e.find("enclosure") is not None or e.findall("media:group", NS):
            kinds = [m.get("medium") or m.get("type") or "" for m in e.findall("media:content", NS)]
            enc = e.find("enclosure")
            if enc is not None:
                kinds.append(enc.get("type") or "")
            if any("video" in k for k in kinds) or e.find("yt:videoId", NS) is not None:
                media["video"] = 1
            elif kinds:
                media["photo"] = 1
        views = None
        st = e.find("media:group/media:community/media:statistics", NS)
        if st is not None and st.get("views", "").isdigit():
            views = int(st.get("views"))
        ups = sorted({m.lower() for m in UPSTREAM_RX.findall(body or "")})
        out.append({"guid": guid, "title": clean_text(t, 400), "link": link.strip(), "body": body, "ts": parse_iso(when or ""), "media": media, "views": views, "upstream": ups})
    return clean_text(title, 200), out


@register
class Rss(Connector):
    platform = "rss"
    label = "Websites & feeds (RSS/Atom)"

    def fetch(self, url: str) -> tuple[str, list[dict]]:
        raw = http_get(url, headers={"Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5"}, browser=True)
        return parse_feed(raw)

    def verify(self, sources: list[dict]) -> list[dict]:
        import time
        res = []
        for s in sources:
            try:
                title, items = self.fetch(s["handle"])
                last = max([i["ts"] or 0 for i in items] or [0]) or None
                age = (time.time() - last) / 86400 if last else None
                st = "live" if age is not None and age <= 14 else ("stale" if last else "empty")
                note = f"{len(items)} items; newest {age:.1f} d ago" if age is not None else f"{len(items)} items, undated"
                self.store.set_source_status(s["id"], st, note, last_post_ts=last)
                res.append({"id": s["id"], "status": st, "note": note, "title": title})
            except (HttpError, ET.ParseError) as e:
                st = "unreachable" if isinstance(e, HttpError) and e.status == 0 else "error"
                note = (str(e)[:160] + " — host not reachable from this network; many .ir hosts block US IP space") if st == "unreachable" else str(e)[:200]
                self.store.set_source_status(s["id"], st, note)
                res.append({"id": s["id"], "status": st, "note": note})
        return res

    def watch_sources(self) -> list[dict]:
        # hosts that were unreachable at the last verify are retried by `publius verify`, not every cycle
        return [s for s in super().watch_sources() if s.get("status") != "unreachable"]

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            _, items = self.fetch(src["handle"])
            n, newest = 0, None
            for it in items:
                newest = max(newest or 0, it["ts"] or 0)
                text = clean_text(it["body"])
                if self.emit(src, sha1(it["guid"]), it["ts"], text, url=it["link"], title=it["title"], media=it["media"],
                             metrics={"views": it["views"]} if it["views"] is not None else None, extra_urls=(), upstream=it["upstream"]):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Odysee(Rss):
    """Odysee publishes RSS per channel (https://odysee.com/$/rss/@channel:claim). RT and other state outlets mirror video there."""
    platform = "odysee"
    label = "Odysee (channel RSS)"

    def watch_sources(self):
        return [dict(s, handle=s["handle"] if s["handle"].startswith("http") else f"https://odysee.com/$/rss/{s['handle']}") for s in super().watch_sources()]
