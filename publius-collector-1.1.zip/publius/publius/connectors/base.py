"""Connector contract. Every connector READS public content only: no posting, reacting, joining, following or DMs.

A connector may implement:
  collect()  pull new posts from the watchlist sources on its platform
  verify()   check that watchlist handles exist, are public and active (status, followers, last post)
  search()   a US-audience breakout lane: how often a URL or phrase appears there (aggregate counts only)
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from ..store import Post, Store
from ..util import clean_text, extract_entities, guess_lang, now, sha1

log = logging.getLogger("publius.connector")


@dataclass
class Stats:
    items: int = 0
    sources: int = 0
    errors: list = field(default_factory=list)


@dataclass
class SearchResult:
    """Aggregate result of a breakout query in one lane. `public_figures` only lists accounts at or above the
    public-figure follower threshold; private individuals are never recorded, only counted."""
    lane: str
    count: int = 0
    reach_max: Optional[int] = None
    public_figures: list = field(default_factory=list)
    violent_or_mobilising: int = 0
    ok: bool = True
    note: str = ""
    cost_usd: float = 0.0


class Connector:
    platform = "base"
    label = "base"
    requires: tuple = ()             # config keys that must be non-empty for the connector to run
    breakout_lane = False            # implements search() for US-audience breakout measurement

    def __init__(self, section: dict, cfg: dict, store: Store):
        self.cfg = section or {}
        self.all = cfg
        self.store = store

    # ------------------------------------------------------------------ readiness
    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled"))

    def ready(self) -> tuple[bool, str]:
        missing = [k for k in self.requires if not str(self.cfg.get(k, "")).strip()]
        if missing:
            return False, "missing " + ", ".join(f"{self.platform}.{k}" for k in missing)
        return True, "ok"

    search_requires: tuple = ()      # extra credentials breakout search needs beyond collection (e.g. a search API key)

    def search_ready(self) -> tuple[bool, str]:
        if not self.breakout_lane:
            return False, "not a breakout lane"
        ok, why = self.ready()
        if not ok:
            return ok, why
        missing = [k for k in self.search_requires if not str(self.cfg.get(k, "")).strip()]
        if missing:
            return False, "search needs " + ", ".join(f"{self.platform}.{k}" for k in missing)
        return True, "ok"

    def watch_sources(self) -> list[dict]:
        return [s for s in self.store.sources(platform=self.platform, enabled_only=True) if s.get("status") not in ("dead",)]

    # ------------------------------------------------------------------ emission
    def emit(self, src: dict, native_id: str, ts: Optional[int], text: str, url: str = "", title: str = "", media: Optional[dict] = None,
             metrics: Optional[dict] = None, fwd_from: str = "", extra_urls: tuple = (), upstream: Optional[list] = None) -> bool:
        body = clean_text(text)
        ttl = clean_text(title, 400)
        full = (ttl + "\n" + body).strip() if ttl and ttl not in body else body
        ents = extract_entities(full, extra_urls)
        p = Post(id=sha1(self.platform, src["id"], native_id), source_id=src["id"], ts=int(ts or now()), text=body, title=ttl, url=url,
                 lang=guess_lang(full), platform=self.platform, country=src.get("country", ""), category=src.get("category", ""),
                 urls=ents["urls"], domains=ents["domains"], hashtags=ents["hashtags"], mentions=ents["mentions"], media=media or {},
                 metrics={k: v for k, v in (metrics or {}).items() if v is not None}, fwd_from=fwd_from, upstream=upstream or [])
        return self.store.add_post(p)

    # ------------------------------------------------------------------ contract
    def collect(self, max_sources: Optional[int] = None) -> Stats:  # pragma: no cover - abstract
        raise NotImplementedError

    def verify(self, sources: list[dict]) -> list[dict]:
        return []

    def search(self, query: str, kind: str = "url", since: Optional[int] = None) -> SearchResult:
        return SearchResult(lane=self.platform, ok=False, note="not a breakout lane")

    # ------------------------------------------------------------------ helpers
    def run_sources(self, fn, max_sources: Optional[int] = None) -> Stats:
        st = Stats()
        srcs = self.watch_sources()
        srcs.sort(key=lambda s: (s.get("last_run") or 0))           # least-recently-polled first (fair rotation)
        if max_sources:
            srcs = srcs[:max_sources]
        for s in srcs:
            st.sources += 1
            try:
                r = fn(s)
                n, newest = r[0], r[1]
                cursor = r[2] if len(r) > 2 else None
                self.store.source_ok(s["id"], None if cursor is None else str(cursor), n, newest)
                st.items += n
            except Exception as e:  # one bad source never stops the lane
                self.store.source_error(s["id"], str(e))
                st.errors.append(f"{s['id']}: {e}")
                log.debug("source %s failed: %s", s["id"], e)
        return st


REGISTRY: dict[str, type] = {}


def register(cls):
    REGISTRY[cls.platform] = cls
    return cls


def sleep_jitter(sec: float) -> None:
    time.sleep(sec)
