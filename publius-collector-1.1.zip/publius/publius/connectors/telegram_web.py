"""Telegram public web preview (t.me/s/<channel>) — no account, no API key.

Reads the public preview Telegram itself serves for broadcast channels that allow it. Gives text, links, forwards,
views, reactions, media kinds and the channel's subscriber count. Channels with previews disabled redirect to
t.me/<channel>; those need the user-session connector (connectors/telegram_user.py)."""
from __future__ import annotations

import html
import re
from typing import Optional

from ..util import HttpError, clean_text, http_request, parse_count, parse_iso
from .base import Connector, Stats, register

MSG_SPLIT = "tgme_widget_message_wrap js-widget_message_wrap"
RX_POST = re.compile(r'data-post="([^"/]+)/(\d+)"')
RX_TEXT = re.compile(r'<div class="tgme_widget_message_text js-message_text"[^>]*>(.*?)</div>\s*(?:<div class="tgme_widget_message_(?:reactions|footer)|<div class="tgme_widget_message_link_preview|<a class="tgme_widget_message_link_preview|$)', re.S)
RX_VIEWS = re.compile(r'<span class="tgme_widget_message_views">([^<]+)</span>')
RX_TIME = re.compile(r'<time datetime="([^"]+)" class="time"')
RX_FWD_HREF = re.compile(r'tgme_widget_message_forwarded_from_name"[^>]*?href="https?://t\.me/([A-Za-z0-9_]+)')
RX_REACT = re.compile(r'<span class="tgme_reaction">.*?</i>([0-9.,KkMm]+)</span>', re.S)
RX_HREF = re.compile(r'href="(https?://[^"]+)"')
RX_SUBS = re.compile(r'<span class="counter_value">([^<]+)</span>\s*<span class="counter_type">(?:subscribers|subscriber|members)</span>')
RX_TITLE = re.compile(r'<meta property="og:title" content="([^"]*)"')
RX_EXTRA = re.compile(r'<div class="tgme_page_extra">\s*([^<]+?)\s*(?:subscribers|subscriber|members)')
RX_LINKPREV = re.compile(r'class="tgme_widget_message_link_preview" href="([^"]+)"')


def parse_preview(page: str, handle: str) -> dict:
    """Parse a t.me/s page into {title, subscribers, messages:[{id, ts, text, urls, views, reactions, fwd, media}]}."""
    out = {"title": html.unescape((RX_TITLE.search(page) or [None, ""])[1] or ""), "subscribers": None, "messages": []}
    m = RX_SUBS.search(page)
    if m:
        out["subscribers"] = parse_count(m.group(1))
    for block in page.split(MSG_SPLIT)[1:]:
        pm = RX_POST.search(block)
        if not pm:
            continue
        mid = int(pm.group(2))
        tm = RX_TIME.search(block)
        txt = ""
        tmatch = RX_TEXT.search(block)
        if tmatch:
            txt = tmatch.group(1)
        urls = [u for u in RX_HREF.findall(txt) if "t.me/" + handle.lower() not in u.lower()]
        lp = RX_LINKPREV.search(block)
        if lp:
            urls.append(html.unescape(lp.group(1)))
        fwd = ""
        fh = RX_FWD_HREF.search(block)
        if fh:                      # only public channels have a t.me link; a forwarded private user's display name is never kept
            fwd = fh.group(1)
        reactions = sum(parse_count(x) or 0 for x in RX_REACT.findall(block))
        media = {}
        if "tgme_widget_message_photo_wrap" in block:
            media["photo"] = block.count("tgme_widget_message_photo_wrap")
        if "tgme_widget_message_video_player" in block or "tgme_widget_message_roundvideo" in block:
            media["video"] = max(1, block.count("tgme_widget_message_video_player"))
        vm = RX_VIEWS.search(block)
        out["messages"].append({"id": mid, "ts": parse_iso(tm.group(1)) if tm else None, "text": clean_text(txt), "urls": [html.unescape(u) for u in urls],
                                "views": parse_count(vm.group(1)) if vm else None, "reactions": reactions, "fwd": fwd, "media": media})
    return out


@register
class TelegramWeb(Connector):
    platform = "telegram"
    label = "Telegram (public web preview)"

    def watch_sources(self) -> list[dict]:
        # channels without a public preview go to the user-session lane; re-verify periodically with `publius verify`
        return [s for s in super().watch_sources() if s.get("status") not in ("not_found", "no_preview")]

    def fetch(self, handle: str, before: Optional[int] = None) -> tuple[Optional[dict], str]:
        url = f"https://t.me/s/{handle}" + (f"?before={before}" if before else "")
        body, _, final = http_request(url, browser=True, timeout=25)
        page = body.decode("utf-8", "replace")
        if "/s/" not in final:   # redirected to t.me/<handle>: previews disabled, private, or no such channel
            extra = RX_EXTRA.search(page)
            if extra:
                return None, f"no public preview ({extra.group(1).strip()} subscribers per t.me page)"
            return None, "no public preview / not found"
        return parse_preview(page, handle), "ok"

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            h = s["handle"]
            try:
                d, note = self.fetch(h)
            except HttpError as e:
                res.append({"id": s["id"], "status": "error", "note": str(e)}); continue
            if d is None:
                st = "no_preview" if "subscribers" in note else "not_found"
                res.append({"id": s["id"], "status": st, "note": note}); self.store.set_source_status(s["id"], st, note); continue
            last = max([m["ts"] or 0 for m in d["messages"]] or [0]) or None
            import time as _t
            age_days = (_t.time() - last) / 86400 if last else None
            st = "live" if age_days is not None and age_days <= 30 else ("stale" if last else "empty")
            note = f"{len(d['messages'])} recent posts; last {age_days:.1f} d ago" if age_days is not None else "no posts visible"
            self.store.set_source_status(s["id"], st, note, followers=d["subscribers"], last_post_ts=last, name=d["title"] or None)
            res.append({"id": s["id"], "status": st, "note": note, "followers": d["subscribers"], "last_post_ts": last, "title": d["title"]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        pages = int(self.cfg.get("pages_per_channel", 1))

        def one(src: dict) -> tuple[int, Optional[int], int]:
            h = src["handle"]
            n, newest, before = 0, None, None
            cursor = int(src.get("cursor") or 0)
            top = cursor
            for _ in range(max(1, pages)):
                d, note = self.fetch(h, before)
                if d is None:
                    self.store.set_source_status(src["id"], "no_preview", note)
                    return 0, None, cursor
                if d["subscribers"]:
                    self.store.set_source_status(src["id"], "live", src.get("status_note") or "", followers=d["subscribers"])
                msgs = d["messages"]
                if not msgs:
                    break
                for m in msgs:
                    top = max(top, m["id"])
                    if not (m["text"] or m["media"]):
                        continue
                    newest = max(newest or 0, m["ts"] or 0)
                    # existing posts are re-emitted on purpose: add_post refreshes their views (velocity snapshots)
                    if self.emit(src, str(m["id"]), m["ts"], m["text"], url=f"https://t.me/{h}/{m['id']}", media=m["media"],
                                 metrics={"views": m["views"], "likes": m["reactions"]}, fwd_from=m["fwd"], extra_urls=tuple(m["urls"])):
                        n += 1
                oldest = min(m["id"] for m in msgs)
                if oldest <= cursor + 1:
                    break
                before = oldest
            return n, newest, top

        return self.run_sources(one, max_sources)
