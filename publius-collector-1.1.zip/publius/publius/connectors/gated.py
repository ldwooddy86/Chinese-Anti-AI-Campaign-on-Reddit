"""Connectors that work once the operator holds platform-granted access. Each is complete and read-only; each states
the access condition in `ready()`.

  meta         Facebook Page public content (Page Public Content Access feature, app review) and Instagram Business
               Discovery (your own IG business account can read public metadata of other business/creator accounts)
  threads      Threads API keyword search (threads_keyword_search permission) — breakout lane
  tiktok       Research API — approved academic / not-for-profit researchers only (TikTok's eligibility rules)
  vk           VK API wall.get with a service token (Russian state media publish there)
  rutube       Rutube public JSON (keyless)
  telegram_user  Telethon user session: reads channels whose web preview is disabled
  discord      bot token; reads only servers the bot is invited to
  eitaa        Eitaa (Iran's state-promoted messenger) public channel pages; usually unreachable from US IP space
"""
from __future__ import annotations

import os
import re
import time
from typing import Optional

from ..util import HttpError, clean_text, http_get, http_get_json, http_post_form, now, parse_count, parse_iso, sha1
from .base import Connector, SearchResult, Stats, register

GRAPH = "https://graph.facebook.com/v21.0/"


@register
class Facebook(Connector):
    platform = "facebook"
    label = "Facebook Pages (Graph API, Page Public Content Access)"
    requires = ("access_token",)

    def __init__(self, section, cfg, store):
        super().__init__(cfg.get("meta", {}), cfg, store)

    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled"))

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        tok = self.cfg["access_token"]

        def one(src: dict):
            r = http_get_json(GRAPH + f"{src['handle']}/posts", params={"access_token": tok, "fields": "id,message,created_time,permalink_url,attachments{type,url},shares", "limit": 25})
            n, newest = 0, None
            for p in r.get("data") or []:
                ts = parse_iso(p.get("created_time", "")) or now()
                newest = max(newest or 0, ts)
                att = ((p.get("attachments") or {}).get("data") or [{}])[0]
                media = {"video": 1} if "video" in str(att.get("type", "")) else ({"photo": 1} if att else {})
                if self.emit(src, p["id"], ts, p.get("message", ""), url=p.get("permalink_url", ""), media=media, metrics={"shares": (p.get("shares") or {}).get("count")}, extra_urls=((att.get("url"),) if att.get("url") else ())):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Instagram(Connector):
    platform = "instagram"
    label = "Instagram (Graph API Business Discovery)"
    requires = ("access_token", "ig_business_id")

    def __init__(self, section, cfg, store):
        super().__init__(cfg.get("meta", {}), cfg, store)

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        tok, me = self.cfg["access_token"], self.cfg["ig_business_id"]

        def one(src: dict):
            fields = f"business_discovery.username({src['handle']}){{followers_count,media.limit(25){{id,caption,timestamp,permalink,media_type,like_count,comments_count}}}}"
            r = http_get_json(GRAPH + me, params={"fields": fields, "access_token": tok})
            bd = r.get("business_discovery") or {}
            if bd.get("followers_count"):
                self.store.set_source_status(src["id"], "live", "", followers=bd["followers_count"])
            n, newest = 0, None
            for m in (bd.get("media") or {}).get("data") or []:
                ts = parse_iso(m.get("timestamp", "")) or now()
                newest = max(newest or 0, ts)
                if self.emit(src, m["id"], ts, m.get("caption", ""), url=m.get("permalink", ""), media={"video": 1} if m.get("media_type") in ("VIDEO", "REELS") else {"photo": 1},
                             metrics={"likes": m.get("like_count"), "replies": m.get("comments_count")}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Threads(Connector):
    platform = "threads"
    label = "Threads (keyword search; breakout lane)"
    requires = ("access_token",)
    breakout_lane = True

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        return Stats()

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        if kind == "url":
            return SearchResult("threads", ok=False, note="keyword search does not match URLs")
        params = {"q": query, "search_type": "RECENT", "fields": "id,text,timestamp,username", "access_token": self.cfg["access_token"], "limit": 100}
        if since:
            params["since"] = int(since)
        r = http_get_json("https://graph.threads.net/v1.0/keyword_search", params=params)
        data = r.get("data") or []
        from .social import _vm
        return SearchResult("threads", count=len(data), violent_or_mobilising=_vm(d.get("text", "") for d in data), note=f"{kind}:{query[:60]}")


@register
class TikTokResearch(Connector):
    platform = "tiktok"
    label = "TikTok Research API (approved researchers only)"
    requires = ("client_key", "client_secret")
    breakout_lane = True

    def _token(self) -> str:
        tok = getattr(self, "_tok", None)
        if tok and tok[1] > time.time():
            return tok[0]
        r = http_post_form("https://open.tiktokapis.com/v2/oauth/token/", {"client_key": self.cfg["client_key"], "client_secret": self.cfg["client_secret"], "grant_type": "client_credentials"})
        self._tok = (r["access_token"], time.time() + int(r.get("expires_in", 7200)) - 60)
        return self._tok[0]

    def _query(self, cond: dict, days: int = 7) -> list[dict]:
        from ..util import http_post_json
        end = time.strftime("%Y%m%d", time.gmtime()); start = time.strftime("%Y%m%d", time.gmtime(time.time() - days * 86400))
        r = http_post_json("https://open.tiktokapis.com/v2/research/video/query/?fields=id,video_description,create_time,username,view_count,like_count,share_count,comment_count",
                           {"query": cond, "start_date": start, "end_date": end, "max_count": 100}, headers={"Authorization": f"Bearer {self._token()}"})
        return ((r.get("data") or {}).get("videos")) or []

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            vids = self._query({"and": [{"operation": "EQ", "field_name": "username", "field_values": [src["handle"]]}]})
            n, newest = 0, None
            for v in vids:
                ts = int(v.get("create_time") or now()); newest = max(newest or 0, ts)
                if self.emit(src, str(v["id"]), ts, v.get("video_description", ""), url=f"https://www.tiktok.com/@{src['handle']}/video/{v['id']}", media={"video": 1},
                             metrics={"views": v.get("view_count"), "likes": v.get("like_count"), "shares": v.get("share_count"), "replies": v.get("comment_count")}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        if kind == "url":
            return SearchResult("tiktok", ok=False, note="keyword search does not match URLs")
        vids = self._query({"and": [{"operation": "IN", "field_name": "keyword", "field_values": [query[:100]]}, {"operation": "EQ", "field_name": "region_code", "field_values": ["US"]}]})
        return SearchResult("tiktok", count=len(vids), reach_max=max([int(v.get("view_count") or 0) for v in vids] or [0]) or None, note=f"{kind}:{query[:60]}")


@register
class VK(Connector):
    platform = "vk"
    label = "VK (wall.get, service token)"
    requires = ("service_token",)

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        tok = self.cfg["service_token"]

        def one(src: dict):
            r = http_get_json("https://api.vk.com/method/wall.get", params={"domain": src["handle"], "count": 50, "access_token": tok, "v": "5.199"})
            if r.get("error"):
                raise HttpError(400, r["error"].get("error_msg", "vk error"))
            n, newest = 0, None
            for p in (r.get("response") or {}).get("items") or []:
                ts = int(p.get("date") or now()); newest = max(newest or 0, ts)
                links = tuple(a["link"]["url"] for a in p.get("attachments") or [] if a.get("type") == "link")
                media = {"video": 1} if any(a.get("type") == "video" for a in p.get("attachments") or []) else ({"photo": 1} if any(a.get("type") == "photo" for a in p.get("attachments") or []) else {})
                if self.emit(src, str(p["id"]), ts, p.get("text", ""), url=f"https://vk.com/wall{p.get('owner_id')}_{p['id']}", media=media,
                             metrics={"views": (p.get("views") or {}).get("count"), "likes": (p.get("likes") or {}).get("count"), "shares": (p.get("reposts") or {}).get("count")}, extra_urls=links):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Rutube(Connector):
    platform = "rutube"
    label = "Rutube (public JSON)"

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            r = http_get_json(f"https://rutube.ru/api/video/person/{src['handle']}/", params={"page": 1})
            n, newest = 0, None
            for v in r.get("results") or []:
                ts = parse_iso(v.get("publication_ts") or v.get("created_ts") or "") or now(); newest = max(newest or 0, ts)
                if self.emit(src, v["id"], ts, v.get("description", ""), url=v.get("video_url", ""), title=v.get("title", ""), media={"video": 1}, metrics={"views": v.get("hits")}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class TelegramUser(Connector):
    platform = "telegram_user"
    label = "Telegram (user session via Telethon)"
    requires = ("api_id", "api_hash")

    def __init__(self, section, cfg, store):
        super().__init__(cfg.get("telegram", {}), cfg, store)

    def watch_sources(self) -> list[dict]:
        # only channels whose public preview is unavailable; the web connector covers the rest for free
        return [s for s in self.store.sources(platform="telegram", enabled_only=True) if s.get("status") in ("no_preview",)]

    def client(self):
        from telethon import TelegramClient  # optional dependency
        return TelegramClient(os.path.join(self.all["general"]["data_dir"], self.cfg.get("session", "publius_user")), int(self.cfg["api_id"]), str(self.cfg["api_hash"]))

    async def login(self) -> None:
        c = self.client(); await c.start(); await c.disconnect()

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        import asyncio
        return asyncio.run(self._collect(max_sources))

    async def _collect(self, max_sources):
        st = Stats()
        c = self.client(); await c.connect()
        try:
            if not await c.is_user_authorized():
                st.errors.append("Telegram session not authorised: run `python -m publius login telegram`"); return st
            srcs = self.watch_sources()[: max_sources or None]
            for s in srcs:
                st.sources += 1
                try:
                    ent = await c.get_entity(s["handle"])
                    from telethon.tl.types import Channel
                    if not (isinstance(ent, Channel) and getattr(ent, "broadcast", False)):
                        raise ValueError("refused: not a broadcast channel (a group is its members' conversation)")
                    msgs = await c.get_messages(ent, limit=int(self.cfg.get("max_messages_per_channel", 100)), min_id=int(s.get("cursor") or 0))
                    n, newest, top = 0, None, int(s.get("cursor") or 0)
                    for m in msgs:
                        top = max(top, m.id)
                        if not m.message:
                            continue
                        ts = int(m.date.timestamp()); newest = max(newest or 0, ts)
                        urls = tuple(e.url for e in (m.entities or []) if getattr(e, "url", None))
                        if self.emit(dict(s, id=s["id"]), str(m.id), ts, m.message, url=f"https://t.me/{s['handle']}/{m.id}", media={"video": 1} if m.video else ({"photo": 1} if m.photo else {}),
                                     metrics={"views": getattr(m, "views", None), "shares": getattr(m, "forwards", None)}, extra_urls=urls):
                            n += 1
                    self.store.source_ok(s["id"], str(top), n, newest); st.items += n
                except Exception as e:
                    self.store.source_error(s["id"], str(e)); st.errors.append(f"{s['handle']}: {e}")
        finally:
            await c.disconnect()
        return st


@register
class DiscordBot(Connector):
    """Reads only Discord channels that are on the watchlist (platform 'discord', handle = channel id) with documented
    attribution, and only announcement channels (type 5), where an outlet or office broadcasts. A chat channel is its
    members' conversation and is refused even when listed. It never adds sources on its own and never profiles members."""
    platform = "discord"
    label = "Discord (bot; invited servers, watchlisted channels only)"
    requires = ("token",)

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            hdr = {"Authorization": f"Bot {self.cfg['token']}"}
            ch = http_get_json(f"https://discord.com/api/v10/channels/{src['handle']}", headers=hdr)
            if int(ch.get("type", -1)) != 5:
                raise HttpError(403, "refused: not an announcement channel (a chat channel is its members' conversation)")
            r = http_get_json(f"https://discord.com/api/v10/channels/{src['handle']}/messages", headers=hdr, params={"limit": 50})
            n, newest = 0, None
            for m in r:
                ts = parse_iso(m.get("timestamp", "")) or now(); newest = max(newest or 0, ts)
                if self.emit(src, m["id"], ts, m.get("content", ""), url=f"https://discord.com/channels/@me/{src['handle']}/{m['id']}"):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Eitaa(Connector):
    platform = "eitaa"
    label = "Eitaa (Iranian messenger, public pages)"

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            page = http_get(f"https://eitaa.com/{src['handle']}", browser=True, timeout=20).decode("utf-8", "replace")
            n, newest = 0, None
            for mid, body, when in re.findall(r'data-post="[^/]+/(\d+)".*?<div class="etme_widget_message_text[^"]*"[^>]*>(.*?)</div>.*?<time datetime="([^"]+)"', page, re.S):
                ts = parse_iso(when) or now(); newest = max(newest or 0, ts)
                if self.emit(src, mid, ts, body, url=f"https://eitaa.com/{src['handle']}/{mid}"):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)
