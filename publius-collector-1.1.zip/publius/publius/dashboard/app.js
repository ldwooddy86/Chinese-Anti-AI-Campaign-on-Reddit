/* PUBLIUS dashboard. Renders a snapshot produced by the collector (live, same-origin API) or embedded in the page
   (static export). Every data string is written as a DOM text node; nothing from the data is parsed as HTML. */
(function () {
  "use strict";

  // ------------------------------------------------------------------ state
  const S = {
    snap: null, live: false, token: "", tab: "brief",
    f: { country: "ALL", cat: "all", platform: "all", hours: 168, q: "", sevMin: 0, flag: "any", narr: "any", sort: "risk", unverified: false, op: "any" },
    practice: {},
    srcPage: 0, srcF: { country: "ALL", cat: "all", platform: "all", status: "any", q: "" },
  };
  const COUNTRIES = [["RU", "Russia"], ["CN", "China"], ["IR", "Iran"]];
  const CNAME = { RU: "Russia", CN: "China", IR: "Iran" };
  const SEVNAME = ["not US-domestic", "divisive framing", "delegitimising", "mobilising / dehumanising", "violence"];
  const PLATNAME = { telegram: "Telegram", rss: "Web / RSS", youtube: "YouTube", x: "X", facebook: "Facebook", instagram: "Instagram", tiktok: "TikTok", bluesky: "Bluesky",
    mastodon: "Mastodon", truthsocial: "Truth Social", gab: "Gab", reddit: "Reddit", threads: "Threads", vk: "VK", rutube: "Rutube", odysee: "Odysee", cn_hotlist: "CN hot lists",
    gdelt: "GDELT", eitaa: "Eitaa", discord: "Discord", rumble: "Rumble", telegram_user: "Telegram (session)" };
  const CATNAME = { gov: "Government / diplomatic", media: "State media", aggregator: "Aggregator", domestic_aggregator: "Domestic aggregator" };
  const FEAT = { us_domestic: "US-domestic subject", wedge_n: "wedge issues", outgroup_n: "partisan out-group terms", moral_emotional_n: "moral-emotional words", negative_n: "negative words",
    debunked: "known falsehood", conspiracy: "conspiracy framing", delegit: "delegitimising", mob_call: "call to action", violence: "violent language", video: "video",
    flashpoint: "live US flashpoint", lang_en: "language (non-English penalty)", log_followers: "audience size", platform_reach: "platform US reach", tier_aggregator: "aggregator tier",
    gov: "diplomatic account", velocity_z: "early engagement vs baseline", echo: "echo across sources", cross_country: "RU/CN/IR convergence", platforms_seen: "extra platforms", early_pickup: "US pickups so far" };

  // ------------------------------------------------------------------ dom helpers
  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === "class") e.className = v;
      else if (k === "text") e.textContent = v;
      else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
      else if (k === "style" && typeof v === "object") Object.assign(e.style, v);
      else if (k === "href") { const u = safeUrl(v); if (u) e.setAttribute("href", u); }
      else e.setAttribute(k, v === true ? "" : String(v));
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      e.appendChild(kid instanceof Node ? kid : document.createTextNode(String(kid)));
    }
    return e;
  }
  // only absolute http(s) links become clickable; javascript:, data: and anything unparsable render as inert text
  function safeUrl(u) {
    try { const x = new URL(String(u)); return x.protocol === "http:" || x.protocol === "https:" ? x.href : null; } catch (e) { return null; }
  }
  // the same switch as the Unrest Watch filter, for the other views that list individual posts
  function unvToggle(hidden) {
    if (!hidden && !S.f.unverified) return null;
    return h("label", { class: "fgroup small unv-toggle" }, h("input", { type: "checkbox", checked: S.f.unverified, onchange: (e) => { S.f.unverified = e.target.checked; renderView(); } }),
      " Include individuals whose state-media affiliation is unverified" + (hidden ? " (" + hidden + " hidden)" : ""));
  }
  // exercise mode: a copy of the store run through simulated lanes; every simulated value carries a SIM chip
  const EX = () => (S.snap && S.snap.meta && S.snap.meta.exercise) || null;
  const simChip = (title) => h("span", { class: "chip sim", title: title || "Simulated in this exercise" }, "SIM");
  const opChip = (o) => o ? h("span", { class: "chip op" + (o.disagree ? " disagree" : ""), title: (o.disagree ? "Second opinion differs from the rule severity by 2+ levels. " : "Second opinion. ") + (o.rationale || "") },
    (o.disagree ? "≠ " : "") + "2nd opinion S" + o.sev) : null;
  const labelChip = (l) => l ? h("span", { class: "chip lab", title: "Outcome label (" + l.source + ")" + (l.note ? ": " + l.note : "") }, "label B" + l.level + " · " + l.source) : null;
  const svgNS = "http://www.w3.org/2000/svg";
  function s(tag, attrs, ...kids) {
    const e = document.createElementNS(svgNS, tag);
    if (attrs) for (const k in attrs) { if (attrs[k] != null) e.setAttribute(k, String(attrs[k])); }
    for (const kid of kids.flat()) { if (kid) e.appendChild(kid instanceof Node ? kid : document.createTextNode(String(kid))); }
    return e;
  }
  const $ = (id) => document.getElementById(id);
  const fmt = (n) => n == null ? "—" : (Math.abs(n) >= 1e6 ? (n / 1e6).toFixed(1) + "M" : Math.abs(n) >= 1e4 ? (n / 1e3).toFixed(0) + "k" : Math.abs(n) >= 1e3 ? (n / 1e3).toFixed(1) + "k" : String(Math.round(n)));
  const pct = (p, d) => p == null ? "—" : (p * 100 < 0.1 && p > 0 ? "<0.1%" : (p * 100).toFixed(d == null ? (p < 0.1 ? 1 : 0) : d) + "%");
  const utc = (ts) => ts ? new Date(ts * 1000).toISOString().replace("T", " ").slice(0, 16) + "Z" : "—";
  const now = () => Math.floor(Date.now() / 1000);
  function ago(ts) {
    if (!ts) return "—";
    const d = (genTs() || now()) - ts;
    if (d < 3600) return Math.max(1, Math.round(d / 60)) + "m ago";
    if (d < 86400) return Math.round(d / 3600) + "h ago";
    return Math.round(d / 86400) + "d ago";
  }
  function genTs() { const g = S.snap && S.snap.meta && S.snap.meta.generated; return g ? Math.floor(Date.parse(g) / 1000) : null; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } }

  // ------------------------------------------------------------------ chips
  const ccChip = (c) => h("span", { class: "chip cc-" + c, title: CNAME[c] || c }, h("span", { class: "sw" }), c || "?");
  const sevChip = (v, withName) => h("span", { class: "chip sev sev-" + (v || 0), title: "Severity S" + (v || 0) + ": " + SEVNAME[v || 0] }, "S" + (v || 0) + (withName ? " · " + SEVNAME[v || 0] : ""));
  const flagChip = (f, capped) => f ? h("span", { class: "chip flag-" + f, title: capped ? "Capped at WATCH: individual source, affiliation not re-verified" : "" }, (f === "ALERT" ? "▲ " : "● ") + f + (capped ? "*" : "")) : null;
  const gradeChip = (g) => g ? h("span", { class: "chip grade", title: "Admiralty grade of the attribution" }, g) : null;
  function refLink(id) {
    const r = (S.snap.refs || {})[id];
    if (!r) return h("span", { class: "mono" }, id);
    return h("a", { href: r.url, target: "_blank", rel: "noopener noreferrer", title: r.publisher + " — " + r.title + " (" + r.date + ")" }, id);
  }
  const refList = (ids) => h("span", { class: "refs" }, (ids || []).map((id, i) => [i ? " · " : "", refLink(id)]));
  function narrName(id) { const d = (S.snap.narratives.defs || []).find((n) => n.id === id); return d ? d.name : id; }
  function fpTitle(id) { const f = (S.snap.flashpoints || []).find((x) => x.id === id); return f ? f.title : id; }

  function highlight(text, ev) {
    const terms = new Set();
    for (const k in (ev || {})) for (const t of ev[k] || []) if (t && t.length >= 3) terms.add(t.toLowerCase());
    const list = [...terms].sort((a, b) => b.length - a.length).map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const frag = document.createDocumentFragment();
    if (!list.length) { frag.appendChild(document.createTextNode(text)); return frag; }
    const rx = new RegExp("(" + list.join("|") + ")", "gi");
    let last = 0, m;
    while ((m = rx.exec(text))) {
      if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
      frag.appendChild(h("mark", null, m[0]));
      last = m.index + m[0].length;
      if (m[0].length === 0) rx.lastIndex++;
    }
    if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
    return frag;
  }

  // ------------------------------------------------------------------ tooltip
  const tip = () => $("tip");
  function showTip(evt, lines) {
    const t = tip();
    t.textContent = "";
    lines.forEach((l, i) => t.appendChild(h("div", { style: i === 0 ? { fontWeight: 600 } : null }, l)));
    t.hidden = false;
    const x = Math.min(window.innerWidth - t.offsetWidth - 8, evt.clientX + 14), y = Math.min(window.innerHeight - t.offsetHeight - 8, evt.clientY + 14);
    t.style.left = x + "px"; t.style.top = y + "px";
  }
  const hideTip = () => { tip().hidden = true; };

  // ------------------------------------------------------------------ data access
  const P = (id) => S.snap.posts[id];
  function allPosts() { return Object.values(S.snap.posts); }
  function passFilters(p, opts) {
    const f = S.f, o = opts || {};
    if (f.country !== "ALL" && p.country !== f.country) return false;
    if (f.cat !== "all" && p.cat !== f.cat) return false;
    if (f.platform !== "all" && p.platform !== f.platform) return false;
    const g = genTs() || now();
    if (f.hours && p.ts < g - f.hours * 3600) return false;
    if (o.unrest || o.attrib) {
      if (!f.unverified && p.unverified) return false;
    }
    if (o.unrest) {
      if ((p.sev || 0) < f.sevMin) return false;
      if (f.flag !== "any" && (p.flag || "none") !== f.flag) return false;
      if (f.narr !== "any" && !(p.narr || []).includes(f.narr)) return false;
      if (f.op === "disagree" && !(p.llm && p.llm.disagree)) return false;
      if (f.op === "agree" && !(p.llm && !p.llm.disagree)) return false;
      if (f.op === "none" && p.llm) return false;
    }
    if (f.q) {
      const q = f.q.toLowerCase();
      if (!((p.text || "").toLowerCase().includes(q) || (p.title || "").toLowerCase().includes(q) || (p.name || "").toLowerCase().includes(q) || (p.handle || "").toLowerCase().includes(q))) return false;
    }
    return true;
  }

  // ------------------------------------------------------------------ post card
  function probRow(p) {
    if (p.p3 == null) return null;
    const scale = (v) => Math.max(0, Math.min(100, Math.sqrt(v) * 100));
    const ref = S.snap.meta.model.ref_p3;
    return h("div", { class: "prob", title: "Probability this item reaches Breakout Scale level 3 or higher (two or more US-audience platforms) within 7 days; bar is the 80% credible interval on a square-root scale; gold tick = reference post" },
      h("span", { class: "pv" }, pct(p.p3, 1)),
      h("div", { class: "ci" }, h("span", { class: "rng", style: { left: scale(p.p3_lo) + "%", width: Math.max(1, scale(p.p3_hi) - scale(p.p3_lo)) + "%" } }),
        h("span", { class: "ref", style: { left: scale(ref) + "%" } }), h("span", { class: "pt", style: { left: "calc(" + scale(p.p3) + "% - 1px)" } })),
      h("span", { class: "muted" }, "80% CrI " + pct(p.p3_lo, 1) + "–" + pct(p.p3_hi, 1) + " · " + p.word + " · " + (p.rr != null ? p.rr.toFixed(1) + "× ref" : "")));
  }
  function postCard(p, opts) {
    const o = opts || {};
    const body = (p.title && !(p.text || "").startsWith(p.title) ? p.title + "\n" : "") + (p.text || "");
    const narr = (p.narr || []).map((n) => h("span", { class: "chip narr", title: narrName(n) }, n + " " + narrName(n)));
    const fps = (p.flash || []).map((f) => h("span", { class: "chip fp", title: fpTitle(f) }, f + " " + fpTitle(f).split(":")[0].slice(0, 38)));
    return h("article", { class: "post sev-" + (p.sev || 0) },
      h("div", { class: "post-head" },
        h("div", { class: "who" }, flagChip(p.flag, p.capped), p.flag && p.sim ? simChip("Flag driven in part by simulated pickups observed so far") : null, sevChip(p.sev, o.sevName), opChip(p.llm), ccChip(p.country), h("span", { class: "name" }, p.name),
          p.unverified ? h("span", { class: "chip", title: "Hamilton listed this individual as a state-media affiliate in Nov 2023; current affiliation not re-verified" }, "affiliation unverified") : null,
          h("span", { class: "meta" }, (PLATNAME[p.platform] || p.platform) + (p.handle && !/^https?:/.test(p.handle) && !/^UC[\w-]{22}$/.test(p.handle) ? " · " + p.handle : "") + " · " + (CATNAME[p.cat] || p.cat)), gradeChip(p.grade)),
        h("span", { class: "meta muted small", title: utc(p.ts) }, ago(p.ts))),
      h("div", { class: "post-text" + (o.full ? "" : " clamp") }, highlight(body, p.ev)),
      (narr.length || fps.length) ? h("div", { class: "chips" }, narr, fps) : null,
      o.noProb ? null : probRow(p),
      h("div", { class: "post-foot" },
        h("span", null, p.metrics && p.metrics.views != null ? fmt(p.metrics.views) + " views" : "", p.metrics && p.metrics.likes ? " · " + fmt(p.metrics.likes) + " reactions" : "",
          p.breakout && p.breakout.level ? " · breakout level " + p.breakout.level + " so far" : "",
          p.breakout && p.breakout.projected ? " · projected " + p.breakout.projected.level + " at 7 d" : "", p.sim ? [" ", simChip()] : null, p.label ? [" ", labelChip(p.label)] : null),
        h("span", { class: "chips" }, p.url ? h("a", { href: p.url, target: "_blank", rel: "noopener noreferrer" }, "Open original ↗") : null,
          h("button", { class: "btn", onclick: () => openPost(p.id) }, "Details"))));
  }

  // ------------------------------------------------------------------ drawer
  function openPost(id) {
    const p = P(id); if (!p) return;
    const body = $("drawer-body"); body.textContent = "";
    body.appendChild(h("h2", { id: "drawer-title" }, p.name));
    body.appendChild(postCard(p, { full: true, sevName: true }));
    const lv = p.p || {};
    const tbl = h("table", null, h("thead", null, h("tr", null, h("th", null, "Breakout level reached"), h("th", { class: "num" }, "P(B ≥ k)"))),
      h("tbody", null, ["2", "3", "4", "5", "6"].map((k) => h("tr", null, h("td", null, "≥ " + k + " — " + LADDER[+k - 1][1]), h("td", { class: "num" }, pct(lv[k], 2))))));
    body.appendChild(h("div", { class: "panel" }, h("h3", null, "Breakout probabilities (Nimmo scale, 7-day horizon)"), h("div", { class: "tablewrap" }, tbl),
      h("p", { class: "note" }, "Predictive probabilities integrate parameter uncertainty (probit approximation). Model: " + S.snap.meta.model.version + (S.snap.meta.model.calibrated ? " (calibrated)" : " (prior only — not yet calibrated on outcomes)") + ".")));
    const c = p.contrib || [];
    if (c.length) {
      const mx = Math.max(0.5, ...c.map((x) => Math.abs(x[1])));
      body.appendChild(h("div", { class: "panel" }, h("h3", null, "What moves the estimate (log-odds contributions)"),
        h("div", { class: "contrib" }, c.map(([k, v]) => h("div", { class: "row" }, h("span", null, FEAT[k] || k),
          h("span", { class: "axis" }, h("span", { class: "z" }), h("span", { class: "b " + (v >= 0 ? "pos" : "neg"), style: v >= 0 ? { left: "50%", width: (v / mx * 50) + "%" } : { left: (50 + v / mx * 50) + "%", width: (-v / mx * 50) + "%" } })),
          h("span", { class: "num" }, (v >= 0 ? "+" : "") + v.toFixed(2))))),
        h("p", { class: "note" }, "Positive bars raise the odds of US breakout, negative bars lower them. The reference post (English state media, 100k followers, on a platform with X's US reach) sits at zero.")));
    }
    const kv = h("dl", { class: "kv" });
    const add = (k, v) => { kv.appendChild(h("dt", null, k)); kv.appendChild(h("dd", null, v)); };
    add("Published", utc(p.ts)); add("Source", [p.name, " (", p.src, ")"]); add("Severity rule", p.sev_rule || "—");
    add("Topics", Object.keys(p.ev || {}).filter((k) => k.startsWith("topic:")).map((k) => k.slice(6)).join(", ") || "—");
    add("Evidence terms", Object.entries(p.ev || {}).filter(([k]) => !k.startsWith("topic:")).map(([k, v]) => k + ": " + v.join(", ")).join(" · ") || "—");
    add("Countries mentioned", (p.countries || []).join(", ") || "—");
    add("Diffusion", p.diff && p.diff.cluster_size ? `cluster of ${p.diff.cluster_size} posts · ${p.diff.echo_sources || 0} other sources · ${(p.diff.cluster_countries || []).join("/")}` : "no echo in window");
    add("Upstream (aggregator provenance)", (p.upstream || []).join(", ") || "—");
    add("Links", (p.urls || []).length ? h("span", null, p.urls.map((u, i) => [i ? " · " : "", h("a", { href: u, target: "_blank", rel: "noopener noreferrer" }, u.replace(/^https?:\/\//, "").slice(0, 70))])) : "—");
    add("Breakout checks", p.breakout && p.breakout.level ? `level ${p.breakout.level} after ${p.breakout.checks} check(s); ${(p.breakout.why && p.breakout.why.reasons || []).join("; ") || "no pickups"}` : (p.breakout && p.breakout.projected ? "first check not yet due" : "not selected for measurement"));
    const pk = pickupPanel(p); if (pk) body.appendChild(pk);
    const op = opinionPanel(p); if (op) body.appendChild(op);
    body.appendChild(h("div", { class: "panel" }, h("h3", null, "Record"), kv));
    if (p.label) body.appendChild(h("div", { class: "panel" }, h("h3", null, "Outcome label"), h("p", null, labelChip(p.label), " ", LADDER[p.label.level - 1][1], p.label.note ? " · " + p.label.note : "")));
    if (S.live || EX()) body.appendChild(labelForm(p));
    $("drawer").hidden = false;
    $("drawer-close").focus();
  }
  function labelForm(p) {
    const practice = !S.live;
    const prev = S.practice[p.id];
    const sel = h("select", { id: "lbl-level" }, LADDER.map(([n, name]) => h("option", { value: n, selected: prev ? +n === prev.level : false }, n + " — " + name)));
    const note = h("input", { type: "text", id: "lbl-note", placeholder: "note (optional)", value: prev ? prev.note : "" });
    const msg = h("span", { class: "note" }, prev ? "Practice label kept in this page: B" + prev.level + "." : "");
    return h("div", { class: "panel" }, h("h3", null, "Record the observed outcome"),
      h("p", { class: "note" }, practice ? "Exercise: a label entered here stays in this page and is not saved anywhere. On a live collector it becomes ground truth for calibration and outranks the automatic label."
        : "Your label is ground truth for calibration and outranks the automatic label."),
      h("div", { class: "chips" }, sel, note, h("button", { class: "btn primary", onclick: async () => {
        if (practice) { S.practice[p.id] = { level: +sel.value, note: note.value }; msg.textContent = "Practice label kept in this page: B" + sel.value + "."; return; }
        try {
          const r = await fetch("/api/label", { method: "POST", headers: { "Content-Type": "application/json", "x-publius-token": S.token }, body: JSON.stringify({ post_id: p.id, level: +sel.value, note: note.value }) });
          msg.textContent = r.ok ? "Saved." : "Not saved: " + (await r.text());
        } catch (e) { msg.textContent = "Not saved: " + e; }
      } }, practice ? "Keep practice label" : "Save label"), msg));
  }

  // per-lane pickups: small multiples of counts at each check, with the level threshold; projected checks drawn hollow
  const LANE_NAME = { x: "X", reddit: "Reddit", bluesky: "Bluesky", threads: "Threads", youtube: "YouTube", tiktok: "TikTok", truthsocial: "Truth Social", mastodon: "Mastodon", gab: "Gab", gdelt: "US news (GDELT)" };
  function pickupPanel(p) {
    const obs = (S.snap.observations || {})[p.id] || [];
    const b = p.breakout || {};
    if (!obs.length && !b.projected) return null;
    const gen = genTs() || now();
    const k = ((S.snap.meta.config || {}).model || {}).breakout_min_pickups || 3;
    const byLane = {};
    obs.forEach((o) => { (byLane[o.lane] = byLane[o.lane] || []).push(o); });
    const lanes = Object.keys(byLane).sort((a, c) => Math.max(...byLane[c].map((o) => o.count)) - Math.max(...byLane[a].map((o) => o.count)));
    const HRS = [1, 6, 24, 72, 168];
    const hx = (hrs, W) => 8 + (W - 16) * Math.log(Math.max(0.5, hrs) / 0.5) / Math.log(200 / 0.5);
    const mini = (lane) => {
      const pts = byLane[lane].map((o) => ({ h: (o.ts - p.ts) / 3600, c: o.count, proj: o.ts > gen, pf: o.pf || [], vm: o.vm || 0 })).sort((a, c) => a.h - c.h);
      const W = 170, H = 74, T = 8, B = 16, top = Math.max(k + 1, ...pts.map((d) => d.c));
      const y = (v) => T + (H - T - B) * (1 - v / top);
      const g = s("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart mini", role: "img", "aria-label": (LANE_NAME[lane] || lane) + " pickups by check" });
      g.appendChild(s("line", { x1: 8, x2: W - 8, y1: y(0), y2: y(0), class: "grid-line" }));
      if (lane !== "gdelt") { g.appendChild(s("line", { x1: 8, x2: W - 8, y1: y(k), y2: y(k), class: "thr" })); g.appendChild(s("text", { x: W - 8, y: y(k) - 3, "text-anchor": "end", class: "tiny" }, "≥" + k)); }
      HRS.forEach((hh) => g.appendChild(s("text", { x: hx(hh, W), y: H - 3, "text-anchor": "middle", class: "tiny" }, hh < 24 ? hh + "h" : hh / 24 + "d")));
      const seg = (arr, cls) => { if (arr.length < 2) return; g.appendChild(s("path", { d: arr.map((d, i) => (i ? "L" : "M") + hx(d.h, W).toFixed(1) + " " + y(d.c).toFixed(1)).join(""), class: cls })); };
      const done = pts.filter((d) => !d.proj), proj = pts.filter((d) => d.proj);
      seg(done, "ln"); seg(done.slice(-1).concat(proj), "ln proj");
      pts.forEach((d) => {
        const c = s("circle", { cx: hx(d.h, W), cy: y(d.c), r: 4, class: d.proj ? "pt proj" : "pt" });
        c.addEventListener("mousemove", (e) => showTip(e, [(LANE_NAME[lane] || lane) + " · " + (d.h < 24 ? d.h.toFixed(1) + " h" : (d.h / 24).toFixed(1) + " d") + " after posting" + (d.proj ? " (projected)" : ""),
          d.c + (lane === "gdelt" ? " US news articles" : " posts carrying it"), d.pf.length ? "public figures: " + d.pf.join(", ") : "", d.vm ? d.vm + " violent or mobilising" : ""].filter(Boolean)));
        c.addEventListener("mouseleave", hideTip);
        g.appendChild(c);
      });
      const last = pts.filter((d) => !d.proj).slice(-1)[0], fin = pts.slice(-1)[0];
      return h("div", { class: "mini-cell" }, h("div", { class: "mini-head" }, h("strong", null, LANE_NAME[lane] || lane), h("span", { class: "num" }, (last ? last.c : "–") + (fin && fin.proj ? " → " + fin.c : ""))), g);
    };
    const reasons = (b.why && b.why.reasons) || [];
    const pr = b.projected || null;
    const rows = lanes.map((lane) => {
      const all = byLane[lane], sofar = all.filter((o) => o.ts <= gen);
      const cur = sofar.length ? Math.max(...sofar.map((o) => o.count)) : null, fin = Math.max(...all.map((o) => o.count));
      const pf = [...new Set(all.flatMap((o) => o.pf || []))], vm = Math.max(0, ...all.map((o) => o.vm || 0)), reach = Math.max(0, ...all.map((o) => o.reach || 0));
      return h("tr", null, h("td", null, LANE_NAME[lane] || lane), h("td", { class: "num" }, cur == null ? "–" : cur), pr ? h("td", { class: "num" }, fin) : null,
        h("td", { class: "num" }, reach ? fmt(reach) : "–"), h("td", { class: "small" }, pf.join(", ") || "–"), h("td", { class: "num" }, vm || "–"));
    });
    return h("div", { class: "panel" },
      h("div", { class: "panel-head" }, h("h3", null, "Pickups in US-audience lanes"), p.sim ? simChip("Counts in this panel are simulated") : null),
      h("p", { class: "small" }, "Level " + (b.level || "–") + " so far after " + (b.checks || 0) + " check(s)" + (pr ? " · projected level " + pr.level + " at 7 days" : "") + (b.measurable ? " · measurable (2+ social lanes answered)" : "") + ".",
        reasons.length ? " " + reasons.join("; ") + "." : ""),
      b.inject ? h("p", { class: "warnbox" }, "Exercise inject: " + b.inject + ".") : null,
      lanes.length ? h("div", { class: "mini-grid" }, lanes.slice(0, 10).map(mini)) : null,
      lanes.length ? h("div", { class: "tablewrap" }, h("table", { class: "wrap-th" }, h("thead", null, h("tr", null, h("th", null, "Lane"), h("th", { class: "num" }, "So far"), pr ? h("th", { class: "num" }, "At 7 days") : null,
        h("th", { class: "num" }, "Largest reach"), h("th", null, "Public figures (≥ 100k)"), h("th", { class: "num" }, "Violent / mobilising"))), h("tbody", null, rows))) : null,
      h("p", { class: "note" }, "Counts of posts or articles carrying the item in each lane, checked at 1 h, 6 h, 24 h, 72 h and 7 days; hollow points are checks after the snapshot time. Accounts under 100,000 followers are counted, never named."));
  }
  function opinionPanel(p) {
    const o = p.llm; if (!o) return null;
    return h("div", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Second opinion"), h("span", { class: "note" }, o.model || "")),
      h("div", { class: "chips" }, h("span", { class: "small muted" }, "Rule"), sevChip(p.sev, true), h("span", { class: "small muted" }, "Second opinion"), sevChip(o.sev, true)),
      o.disagree ? h("p", { class: "warnbox" }, "The two readings differ by two or more levels. The rule severity still drives the score; the second opinion is advisory until an analyst labels the post.") : null,
      h("p", null, o.rationale || "—"),
      h("dl", { class: "kv" }, h("dt", null, "Narrative"), h("dd", null, o.narrative || "—"), h("dt", null, "US-domestic subject"), h("dd", null, o.us_domestic ? "yes" : "no"),
        h("dt", null, "Call to action"), h("dd", null, o.cta && (o.cta.present === "True" || o.cta.present === "true" || o.cta.what) ? [o.cta.what, o.cta.when, o.cta.where].filter(Boolean).join(" · ") : "none"),
        h("dt", null, "Targets a group"), h("dd", null, o.targets_group ? "yes" : "no")));
  }
  function closeDrawer() { $("drawer").hidden = true; }

  // ------------------------------------------------------------------ charts
  // Charts are drawn at the width they will occupy, so SVG text keeps its nominal size on every screen.
  function avail(frac) {
    const w = ($("view") && $("view").clientWidth) || 900;
    return Math.max(280, Math.round((window.innerWidth <= 980 ? w : w * frac) - 36));
  }
  function stackedDays(byDay, frac) {
    const days = Object.keys(byDay || {}).sort().slice(-14);
    if (!days.length) return h("div", { class: "empty" }, "No posts in window.");
    const W = avail(frac || 0.38), H = 190, L = 34, B = 24, T = 8, R = 8;
    const tot = days.map((d) => COUNTRIES.reduce((a, [c]) => a + (byDay[d][c] || 0), 0));
    const max = Math.max(1, ...tot);
    const nice = Math.pow(10, Math.floor(Math.log10(max))); const top = Math.ceil(max / nice) * nice;
    const bw = (W - L - R) / days.length;
    const y = (v) => T + (H - T - B) * (1 - v / top);
    const g = s("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart", role: "img", "aria-label": "Posts per day by country" });
    for (let i = 0; i <= 4; i++) { const v = top * i / 4; g.appendChild(s("line", { x1: L, x2: W - R, y1: y(v), y2: y(v), class: "grid-line" })); g.appendChild(s("text", { x: L - 6, y: y(v) + 4, "text-anchor": "end" }, fmt(v))); }
    days.forEach((d, i) => {
      let acc = 0;
      const x = L + i * bw + 3, w = Math.max(2, bw - 6);
      COUNTRIES.forEach(([c]) => {
        const v = byDay[d][c] || 0; if (!v) return;
        const y1 = y(acc + v), y0 = y(acc);
        const r = s("rect", { x, y: y1 + 1, width: w, height: Math.max(0, y0 - y1 - 2), rx: 2, class: "dot-" + c });
        r.addEventListener("mousemove", (e) => showTip(e, [d, CNAME[c] + ": " + v + " posts", "all countries: " + tot[i]]));
        r.addEventListener("mouseleave", hideTip);
        g.appendChild(r); acc += v;
      });
      if (days.length <= 10 || i % 2 === 0) g.appendChild(s("text", { x: x + w / 2, y: H - 6, "text-anchor": "middle" }, d.slice(5)));
    });
    return h("div", null, g, legend());
  }
  const legend = () => h("div", { class: "legend" }, COUNTRIES.map(([c, n]) => h("span", null, h("span", { class: "sw " + c }), n)));

  function riskScatter(posts) {
    const pts = posts.filter((p) => p.p3 != null);
    if (!pts.length) return h("div", { class: "empty" }, "Nothing scored yet.");
    const W = avail(1), H = 260, L = 96, B = 30, T = 16, R = 12;
    const lo = Math.log10(0.0005), hi = Math.log10(0.6);
    const x = (p) => L + (W - L - R) * (Math.log10(Math.max(0.0005, Math.min(0.6, p))) - lo) / (hi - lo);
    const rowH = (H - T - B) / 5;
    const y = (sev, j) => T + (4 - sev) * rowH + rowH / 2 + j;
    const g = s("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart", role: "img", "aria-label": "Breakout probability against severity" });
    for (let sv = 0; sv <= 4; sv++) {
      g.appendChild(s("line", { x1: L, x2: W - R, y1: T + (4 - sv) * rowH, y2: T + (4 - sv) * rowH, class: "grid-line" }));
      g.appendChild(s("text", { x: L - 8, y: y(sv, 4), "text-anchor": "end" }, "S" + sv + " " + ["off-topic", "divisive", "delegit.", "mobilising", "violence"][sv]));
    }
    [0.001, 0.003, 0.01, 0.03, 0.1, 0.3].forEach((v) => { g.appendChild(s("line", { x1: x(v), x2: x(v), y1: T, y2: H - B, class: "grid-line" })); g.appendChild(s("text", { x: x(v), y: H - 10, "text-anchor": "middle" }, pct(v, v < 0.01 ? 1 : 0))); });
    const ref = S.snap.meta.model.ref_p3;
    g.appendChild(s("line", { x1: x(ref), x2: x(ref), y1: T, y2: H - B, stroke: "var(--brass)", "stroke-dasharray": "3 3" }));
    g.appendChild(s("text", { x: x(ref) + 4, y: T - 4 }, "reference post " + pct(ref, 1)));
    const seed = (id) => { let a = 0; for (let i = 0; i < id.length; i++) a = (a * 31 + id.charCodeAt(i)) % 997; return (a / 997 - 0.5) * rowH * 0.7; };
    pts.sort((a, b) => (a.risk || 0) - (b.risk || 0)).forEach((p) => {
      const c = s("circle", { cx: x(p.p3), cy: y(p.sev || 0, seed(p.id)), r: p.flag ? 5 : 3.2, class: "dot-" + p.country, stroke: "var(--surface)", "stroke-width": 1.5, style: "cursor:pointer" });
      c.addEventListener("mousemove", (e) => showTip(e, [p.name, "P(B≥3) " + pct(p.p3, 1) + " · S" + p.sev + (p.flag ? " · " + p.flag : ""), (p.title || p.text || "").slice(0, 110)]));
      c.addEventListener("mouseleave", hideTip);
      c.addEventListener("click", () => openPost(p.id));
      g.appendChild(c);
    });
    const lg = legend();
    lg.appendChild(h("span", { class: "muted" }, "x: P(multi-platform US breakout within 7 days), log scale · larger dots are flagged"));
    return h("div", null, g, lg);
  }

  function sparkline(series) {
    if (!series || series.length < 2) return h("span", { class: "muted small" }, "no salience series yet");
    const W = 220, H = 36, max = Math.max(1e-9, ...series.map((d) => d[1]));
    const xs = (i) => (i / (series.length - 1)) * W, ys = (v) => H - 3 - (H - 6) * v / max;
    let line = "", area = `M0 ${H}`;
    series.forEach(([_, v], i) => { line += (i ? "L" : "M") + xs(i).toFixed(1) + " " + ys(v).toFixed(1); area += "L" + xs(i).toFixed(1) + " " + ys(v).toFixed(1); });
    area += `L${W} ${H}Z`;
    const g = s("svg", { viewBox: `0 0 ${W} ${H}`, class: "spark", preserveAspectRatio: "none", role: "img", "aria-label": "US news salience, last 14 days" }, s("path", { d: area, class: "a" }), s("path", { d: line, class: "l" }));
    const last = series[series.length - 1];
    g.appendChild(s("circle", { cx: xs(series.length - 1), cy: ys(last[1]), r: 2.5, fill: "var(--ink)" }));
    return g;
  }

  function rankList(items, opts) {
    const o = opts || {};
    if (!items || !items.length) return h("div", { class: "empty" }, "Nothing in this slice.");
    const max = Math.max(...items.map((d) => d[1]));
    return h("ol", { class: "rank" }, items.slice(0, o.n || 15).map(([k, v]) => {
      const lab = o.link && /^https?:/.test(k) ? h("a", { href: k, target: "_blank", rel: "noopener noreferrer", title: k }, k.replace(/^https?:\/\//, "").slice(0, 80)) : k;
      return h("li", { class: o.onPick ? "linkish" : null, onclick: o.onPick ? () => o.onPick(k) : null }, h("span", { class: "lab", title: String(k) }, lab), h("span", { class: "val" }, fmt(v)),
        h("span", { class: "track" }, h("span", { class: "fill", style: { width: (100 * v / max).toFixed(1) + "%" } })));
    }));
  }

  // ------------------------------------------------------------------ filters bar
  function filterBar(which) {
    const bar = $("filters"); bar.textContent = ""; bar.hidden = !which;
    if (!which) return;
    const seg = (label, key, opts) => h("div", { class: "fgroup" }, h("span", null, label), h("div", { class: "seg", role: "group", "aria-label": label },
      opts.map(([v, t, cc]) => h("button", { "aria-pressed": String(S.f[key] === v), onclick: () => { S.f[key] = v; render(); } }, cc ? h("span", { class: "sw " + cc, style: { width: "8px", height: "8px", borderRadius: "2px", display: "inline-block" } }) : null, t))));
    bar.appendChild(seg("Country", "country", [["ALL", "All"], ["RU", "Russia", "RU"], ["CN", "China", "CN"], ["IR", "Iran", "IR"]]));
    bar.appendChild(h("div", { class: "fgroup" }, h("span", null, "Category"), h("select", { id: "f-cat", onchange: (e) => { S.f.cat = e.target.value; render(); } },
      [["all", "All"], ["media", "State media"], ["gov", "Government / diplomatic"], ["aggregator", "Aggregators"], ["domestic_aggregator", "Domestic aggregators"]].map(([v, t]) => h("option", { value: v, selected: S.f.cat === v }, t)))));
    const plats = Object.keys(S.snap.hist.platform || {}).sort();
    bar.appendChild(h("div", { class: "fgroup" }, h("span", null, "Platform"), h("select", { id: "f-plat", onchange: (e) => { S.f.platform = e.target.value; render(); } },
      [["all", "All"]].concat(plats.map((p) => [p, PLATNAME[p] || p])).map(([v, t]) => h("option", { value: v, selected: S.f.platform === v }, t)))));
    bar.appendChild(seg("Window", "hours", [[24, "24 h"], [72, "3 d"], [168, "7 d"]]));
    if (which === "search" || which === "unrest") {
      const inp = h("input", { type: "search", id: "f-q", placeholder: "Search text, outlet or handle", value: S.f.q });
      inp.addEventListener("input", debounce(() => { S.f.q = inp.value.trim(); renderView(); }, 250));
      bar.appendChild(h("div", { class: "fgroup" }, h("span", null, "Text"), inp));
    }
  }
  function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

  // ------------------------------------------------------------------ views
  const LADDER = [["1", "one platform, no breakout"], ["2", "pickup on one US platform"], ["3", "pickups on 2+ platforms"], ["4", "US mainstream news"], ["5", "public-figure amplification"], ["6", "policy response or calls to violence"]];

  function vBrief(v) {
    const b = S.snap.brief || {};
    const posts = allPosts().filter((p) => passFilters(p));
    const flagged = posts.filter((p) => p.flag);
    const dom = posts.filter((p) => (p.sev || 0) >= 1).length;
    const m = S.snap.meta;
    v.appendChild(h("section", { class: "panel flat" },
      h("div", { class: "section-head" }, h("h2", null, "Bottom line"), h("span", { class: "note" }, "Analyst assessment as of " + (b.as_of || "—") + " · data through " + utc(genTs()))),
      h("p", { class: "bluf" }, b.bluf || "No assessment written yet."),
      EX() ? h("p", { class: "note" }, "Exercise: this assessment and its figures come from the real collection, before any simulated input. The tiles, queue and chart below include the simulated pickups.") : null));
    v.appendChild(h("div", { class: "kpis" },
      kpi(fmt(m.posts_in_window), "posts from watchlist sources, last " + m.window_days + " days"),
      kpi(fmt((S.snap.sources || []).filter((x) => x.status === "live").length), "watchlist accounts verified live"),
      kpi(String(flagged.filter((p) => p.flag === "ALERT").length), ["ALERT: severity ≥ S3 and P(B≥3) ≥ 20%", EX() ? [" ", simChip("Includes simulated pickups")] : null], "alert"),
      kpi(String(flagged.filter((p) => p.flag === "WATCH").length), ["WATCH: severe content with elevated breakout lift", EX() ? [" ", simChip("Includes simulated pickups")] : null], "watch"),
      kpi((b.figures && b.figures.domestic_pct) || (posts.length ? pct(dom / posts.length) : "—"), "of posts in the window address US domestic affairs")));
    const kjs = (b.kjs || []).map((k) => h("div", { class: "kj" }, h("span", { class: "id" }, k.id), h("div", null, h("p", null, k.text), h("div", { class: "conf" }, k.confidence + " confidence"), refList(k.refs))));
    v.appendChild(h("div", { class: "cols" },
      h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Key judgments")), kjs.length ? kjs : h("div", { class: "empty" }, "—")),
      h("div", { style: { display: "grid", gap: "16px", alignContent: "start" } },
        h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Volume by day"), h("span", { class: "note" }, "posts per UTC day")), stackedDays(S.snap.hist.by_day, 0.38),
          m.collection_started ? h("p", { class: "note" }, "Collection began " + utc(m.collection_started) + "; days before it are covered only as far back as each channel's public history reaches.") : null),
        h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Top of the Unrest Watch")),
          (flagged.length ? flagged : posts.filter((p) => p.risk)).filter((p) => !p.unverified).sort((a, c) => (c.risk || 0) - (a.risk || 0)).slice(0, 4).map((p) => postCard(p, { noProb: false })),
          h("button", { class: "btn", onclick: () => go("unrest") }, "Open the full queue")))));
    v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Where risk sits"), h("span", { class: "note" }, "each dot is a post; click for detail · individuals with unverified affiliation excluded")), riskScatter(posts.filter((p) => !p.unverified))));
    const ind = S.snap.indicators || [];
    const ops = (S.snap.operations || []).map((o) => {
      const mine = ind.filter((r) => r.op_id === o.id);
      const lanesReady = (S.snap.lanes || []).some((l) => l.breakout_lane && l.enabled && (l.breakout_ready != null ? l.breakout_ready : l.ready) && l.platform !== "gdelt");
      const hasInd = Object.values(o.indicators || {}).some((v) => (v || []).length);
      return h("div", { class: "op" }, h("div", { class: "chips" }, ccChip(o.country), h("strong", null, o.name), gradeChip(o.grade), h("span", { class: "muted small" }, o.status)),
        h("p", { class: "small" }, o.summary),
        hasInd ? (mine.length ? h("div", { class: "chips" }, EX() ? simChip("Indicator counts are simulated") : null, mine.sort((a, c) => c.count - a.count).map((r) => h("span", { class: "chip", title: (r.note || "") + " · last sweep " + utc(r.ts) }, r.indicator + " · " + (PLATNAME[r.lane] || r.lane) + ": " + r.count + (r.public_figures.length ? " · " + r.public_figures.join(", ") : ""))))
          : h("p", { class: "note" }, lanesReady ? "Indicators queued for the next sweep." : "Indicators (" + Object.values(o.indicators).flat().join(", ") + ") are counted in US lanes once Bluesky, X or Reddit keys are added.")) : null,
        refList(o.evidence));
    });
    v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Known covert operations in play"), h("span", { class: "note" }, "no stable handles: tracked as indicators (hashtags, domains, phrases)")), ops));
  }
  const kpi = (val, label, cls) => h("div", { class: "kpi " + (cls || "") }, h("span", { class: "v" }, val), h("span", { class: "l" }, label));

  function panelKey() {
    const f = S.f;
    if (f.platform !== "all") return `${f.country}|all|${f.platform}`;
    return `${f.country}|${f.cat}|all`;
  }
  function vOverview(v) {
    const pan = (S.snap.panels || {})[panelKey()] || (S.snap.panels || {})[S.f.country + "|all|all"] || {};
    const posts = allPosts().filter((p) => passFilters(p));
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Messaging overview"),
      h("p", { class: "lede" }, "The Hamilton 2.0 view: what the tracked accounts said, where, and what they pointed to, for the slice selected above.")));
    if (S.f.hours !== 168) v.appendChild(h("p", { class: "note" }, "Ranked panels cover the full " + S.snap.meta.window_days + "-day window; the window control narrows the post lists."));
    const topPosts = (pan.top_posts || []).map(P).filter(Boolean).filter((p) => passFilters(p)).slice(0, 8);
    const accounts = (pan.top_accounts || []).slice(0, 15);
    v.appendChild(h("div", { class: "grid" },
      h("section", { class: "panel" }, h("h3", null, "Key phrases"), rankList(pan.key_phrases, { onPick: (k) => { S.f.q = k; go("search"); } })),
      h("section", { class: "panel" }, h("h3", null, "Hashtags"), rankList(pan.hashtags, { onPick: (k) => { S.f.q = k; go("search"); } })),
      h("section", { class: "panel" }, h("h3", null, "Countries mentioned"), rankList(pan.countries)),
      h("section", { class: "panel" }, h("h3", null, "Domains linked"), rankList(pan.domains)),
      h("section", { class: "panel" }, h("h3", null, "URLs shared"), rankList(pan.urls, { link: true, n: 12 })),
      h("section", { class: "panel" }, h("h3", null, "Accounts mentioned"), h("p", { class: "warnbox" }, "Being mentioned by a state account does not mean the mentioned account is supported, targeted or connected."), rankList(pan.mentions))));
    v.appendChild(h("div", { class: "cols" },
      h("section", { class: "panel" }, h("h3", null, "Most-engaged posts"), topPosts.length ? h("div", { class: "posts" }, topPosts.map((p) => postCard(p))) : h("div", { class: "empty" }, "No posts in this slice.")),
      h("section", { class: "panel" }, h("h3", null, "Most active accounts"), accounts.length ? h("div", { class: "tablewrap" }, h("table", null,
        h("thead", null, h("tr", null, h("th", null, "Account"), h("th", null, ""), h("th", { class: "num" }, "Posts"), h("th", { class: "num" }, "Followers"))),
        h("tbody", null, accounts.map((a) => h("tr", null, h("td", null, a.name, h("div", { class: "muted small" }, (PLATNAME[a.platform] || a.platform) + " · " + (CATNAME[a.category] || a.category))),
          h("td", null, ccChip(a.country)), h("td", { class: "num" }, a.posts), h("td", { class: "num" }, fmt(a.followers))))))) : h("div", { class: "empty" }, "—"))));
    v.appendChild(h("p", { class: "note" }, "Posts in this slice: " + posts.length + " of the " + Object.keys(S.snap.posts).length + " carried in this snapshot."));
  }

  function vSearch(v) {
    const res = allPosts().filter((p) => passFilters(p)).sort((a, b) => b.ts - a.ts);
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Search"), h("span", { class: "note" }, res.length + " matching posts" + (res.length > 150 ? " · showing the newest 150" : ""))));
    if (S.live) {
      const btn = h("button", { class: "btn", onclick: async () => {
        btn.disabled = true; btn.textContent = "Searching the full store…";
        try {
          const r = await fetch("/api/search?q=" + encodeURIComponent(S.f.q) + "&country=" + (S.f.country === "ALL" ? "" : S.f.country) + "&platform=" + (S.f.platform === "all" ? "" : S.f.platform), { headers: { "x-publius-token": S.token } });
          const d = await r.json(); (d.posts || []).forEach((p) => { S.snap.posts[p.id] = p; }); renderView();
        } catch (e) { btn.textContent = "Search failed: " + e; }
      } }, "Search the full 30-day store");
      v.appendChild(btn);
    }
    v.appendChild(h("div", { class: "posts" }, res.slice(0, 150).map((p) => postCard(p))));
    if (!res.length) v.appendChild(h("div", { class: "empty" }, "No posts match. Clear the text box or widen the window."));
  }

  function vTrends(v) {
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Trends"), h("p", { class: "lede" }, "Rising terms use the log-odds ratio with an informative Dirichlet prior (Monroe, Colaresi & Quinn 2008): a term ranks high only when the current window over-uses it beyond chance. " + (S.snap.meta.trend_note || ""))));
    const tr = S.snap.trending || [];
    const maxz = Math.max(1, ...tr.map((t) => Math.abs(t.z)));
    v.appendChild(h("div", { class: "cols" },
      h("section", { class: "panel" }, h("h3", null, "Rising now"), tr.length ? h("ol", { class: "rank" }, tr.slice(0, 30).map((t) => h("li", { class: "linkish", onclick: () => { S.f.q = t.term; go("search"); } },
        h("span", { class: "lab" }, t.term), h("span", { class: "val" }, "z " + t.z.toFixed(1) + " · " + t.current + " vs " + t.baseline),
        h("span", { class: "track" }, h("span", { class: "fill", style: { width: (100 * Math.max(0, t.z) / maxz) + "%" } }))))) : h("div", { class: "empty" }, "Not enough baseline yet.")),
      h("section", { class: "panel" }, h("h3", null, "Posts per day"), stackedDays(S.snap.hist.by_day, 0.38),
        h("h3", null, "Severity mix"), rankList(Object.entries(S.snap.hist.severity || {}).sort().map(([k, n]) => ["S" + k + " " + SEVNAME[+k], n])),
        h("h3", null, "Platform mix"), rankList(Object.entries(S.snap.hist.platform || {}).sort((a, b) => b[1] - a[1]).map(([k, n]) => [PLATNAME[k] || k, n])))));
    const dist = S.snap.distinctive || {};
    v.appendChild(h("div", { class: "grid" }, COUNTRIES.map(([c, n]) => h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Distinctively " + n), ccChip(c)),
      (dist[c] || []).length ? h("ol", { class: "rank" }, dist[c].slice(0, 12).map((t) => h("li", null, h("span", { class: "lab" }, t.term), h("span", { class: "val" }, "z " + t.z.toFixed(1))))) : h("div", { class: "empty" }, "—")))));
  }

  function vUnrest(v) {
    const ids = new Set([...(S.snap.queue || []), ...(S.snap.top_risk || []), ...allPosts().filter((p) => p.llm).map((p) => p.id)]);
    const pool = [...ids].map(P).filter(Boolean);
    let posts = pool.filter((p) => passFilters(p, { unrest: true }));
    const hiddenUnverified = S.f.unverified ? 0 : pool.filter((p) => p.unverified && passFilters(Object.assign({}, p, { unverified: false }), { unrest: true })).length;
    const sorters = { risk: (a, b) => (b.risk || 0) - (a.risk || 0), p3: (a, b) => (b.p3 || 0) - (a.p3 || 0), ts: (a, b) => b.ts - a.ts, sev: (a, b) => (b.sev || 0) - (a.sev || 0) || (b.p3 || 0) - (a.p3 || 0) };
    posts.sort(sorters[S.f.sort] || sorters.risk);
    const m = S.snap.meta.model;
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Unrest Watch"),
      h("p", { class: "lede" }, "Posts ranked by the chance that they break out across US-audience platforms (Breakout Scale level 3+, within 7 days) weighted by how severe the content is. Probability and severity are shown separately: a likely-but-mild post and a severe-but-contained post are different problems.")));
    v.appendChild(h("div", { class: "warnbox" }, "How to read a card: P(B≥3) is the predictive probability with its 80% credible interval and the ICD-203 word; '× ref' is the lift over an ordinary English state-media post (" + pct(m.ref_p3, 1) + "). " +
      (m.calibrated ? "The model is calibrated on observed outcomes (" + m.version + ")." : "The model is running on literature-derived priors and has not yet been calibrated on observed outcomes, so treat absolute probabilities as ordinal until `publius calibrate` succeeds.") +
      " Single foreign posts rarely move US behaviour on their own (Eady et al. 2023; Bail et al. 2020); the risk they carry is amplification of live domestic flashpoints."));
    const ctl = h("div", { class: "filters", style: { borderBottom: "0", paddingBlock: "0" } },
      h("div", { class: "fgroup" }, h("span", null, "Sort"), h("select", { id: "u-sort", onchange: (e) => { S.f.sort = e.target.value; renderView(); } }, [["risk", "Risk index"], ["p3", "Breakout probability"], ["sev", "Severity"], ["ts", "Newest"]].map(([k, t]) => h("option", { value: k, selected: S.f.sort === k }, t)))),
      h("div", { class: "fgroup" }, h("span", null, "Severity ≥"), h("select", { id: "u-sev", onchange: (e) => { S.f.sevMin = +e.target.value; renderView(); } }, [0, 1, 2, 3, 4].map((k) => h("option", { value: k, selected: S.f.sevMin === k }, "S" + k)))),
      h("div", { class: "fgroup" }, h("span", null, "Flag"), h("select", { id: "u-flag", onchange: (e) => { S.f.flag = e.target.value; renderView(); } }, [["any", "Any"], ["ALERT", "ALERT"], ["WATCH", "WATCH"], ["none", "Unflagged"]].map(([k, t]) => h("option", { value: k, selected: S.f.flag === k }, t)))),
      h("div", { class: "fgroup" }, h("span", null, "Narrative"), h("select", { id: "u-narr", onchange: (e) => { S.f.narr = e.target.value; renderView(); } }, [["any", "Any"]].concat((S.snap.narratives.defs || []).map((n) => [n.id, n.id + " " + n.name])).map(([k, t]) => h("option", { value: k, selected: S.f.narr === k }, t)))),
      h("div", { class: "fgroup" }, h("span", null, "2nd opinion"), h("select", { id: "u-op", onchange: (e) => { S.f.op = e.target.value; renderView(); } }, [["any", "Any"], ["disagree", "Disagrees by 2+"], ["agree", "Within 1 level"], ["none", "Not reviewed"]].map(([k, t]) => h("option", { value: k, selected: S.f.op === k }, t)))),
      h("label", { class: "fgroup small", for: "u-unv" }, h("input", { type: "checkbox", id: "u-unv", checked: S.f.unverified, onchange: (e) => { S.f.unverified = e.target.checked; renderView(); } }),
        " Include individuals whose state-media affiliation is unverified" + (hiddenUnverified ? " (" + hiddenUnverified + " hidden)" : "")));
    v.appendChild(ctl);
    v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Probability × severity"), h("span", { class: "note" }, posts.length + " posts in this queue")), riskScatter(posts)));
    v.appendChild(h("div", { class: "posts" }, posts.slice(0, 120).map((p) => postCard(p, { sevName: true }))));
    if (!posts.length) v.appendChild(h("div", { class: "empty" }, "No posts meet these filters."));
  }

  function vNarratives(v) {
    const N = S.snap.narratives || {};
    const counts = N.counts || {}, conv = N.convergence || {};
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "US-directed narratives"), h("p", { class: "lede" }, "Fourteen recurring framings of America used by the three states. Divisive narratives work on division inside the US; the others frame the US from outside. Convergence counts the days on which two or three of the states pushed the same narrative above their own average at once.")));
    const rows = (N.defs || []).map((d) => {
      const c = counts[d.id] || {};
      const tot = (k) => Object.values(c[k] || {}).reduce((a, b) => a + b, 0);
      const vals = COUNTRIES.map(([k]) => tot(k));
      const cv = Object.values(conv[d.id] || {});
      return { d, vals, total: vals.reduce((a, b) => a + b, 0), conv2: cv.filter((x) => x >= 2).length, conv3: cv.filter((x) => x >= 3).length };
    }).sort((a, b) => b.total - a.total);
    const mx = Math.max(1, ...rows.flatMap((r) => r.vals));
    v.appendChild(h("div", { class: "tablewrap" }, h("table", null,
      h("thead", null, h("tr", null, h("th", null, "Narrative"), h("th", null, "Type"), COUNTRIES.map(([c, n]) => h("th", null, n)), h("th", { class: "num" }, "Total"), h("th", { class: "num" }, "Days 2+ states"), h("th", { class: "num" }, "Days all 3"), h("th", null, ""))),
      h("tbody", null, rows.map((r) => h("tr", null, h("td", null, h("strong", null, r.d.id + " "), r.d.name), h("td", null, r.d.divisive ? h("span", { class: "chip" }, "divisive") : h("span", { class: "muted small" }, "external")),
        r.vals.map((val, i) => h("td", { style: { minWidth: "120px" } }, h("div", { style: { display: "flex", alignItems: "center", gap: "6px" } }, h("span", { class: "num", style: { width: "34px", textAlign: "right" } }, val),
          h("span", { style: { flex: "1", height: "6px", background: "var(--bar-soft)", borderRadius: "3px", position: "relative", overflow: "hidden" } }, h("span", { class: "sw " + COUNTRIES[i][0], style: { position: "absolute", left: 0, top: 0, bottom: 0, width: (100 * val / mx) + "%" } }))))),
        h("td", { class: "num" }, r.total), h("td", { class: "num" }, r.conv2), h("td", { class: "num" }, r.conv3),
        h("td", null, r.total ? h("button", { class: "btn", onclick: () => { S.f.narr = r.d.id; S.f.sevMin = 0; S.f.flag = "any"; go("unrest"); } }, "Posts") : null)))))));
    v.appendChild(legend());
  }

  function vBreakout(v) {
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Breakout measurement"), h("p", { class: "lede" }, "Ben Nimmo's Breakout Scale (Brookings, 2020) is the outcome the model predicts and the thing the collector measures. A post is checked at 1 h, 6 h, 24 h, 72 h and 7 days in every US-audience lane that has credentials, and each lane returns counts only.")));
    v.appendChild(h("div", { class: "ladder" }, LADDER.map(([n, t], i) => h("div", { class: "step", style: { minHeight: (54 + i * 18) + "px" } }, h("b", null, n), h("span", null, t)))));
    const lanes = (S.snap.lanes || []).filter((l) => l.breakout_lane);
    v.appendChild(h("section", { class: "panel" }, h("h3", null, "Breakout lanes"), h("div", { class: "tablewrap" }, h("table", null,
      h("thead", null, h("tr", null, h("th", null, "Lane"), h("th", null, "Enabled"), h("th", null, "Ready"), h("th", null, "Needs"))),
      h("tbody", null, lanes.map((l) => { const rd = l.breakout_ready != null ? l.breakout_ready : l.ready; return h("tr", null, h("td", null, l.label), h("td", null, l.enabled ? "yes" : "no"),
        h("td", null, l.simulated ? simChip("Answers are simulated in this exercise") : rd && l.enabled ? h("span", { class: "chip st-live" }, "ready") : h("span", { class: "chip st-stale" }, "not configured")),
        h("td", { class: "small" }, l.simulated ? "live use needs: " + (l.real_why || "—").replace(/^search needs |^missing /, "") : rd ? (l.enabled ? "—" : "enable in config.toml") : (l.breakout_why || l.why))); })))),
      h("p", { class: "note" }, "Privacy rail: lanes return aggregate counts; an account is named only when it is at or above the public-figure threshold (" + fmt((S.snap.meta.config.model || {}).public_figure_followers || 100000) + " followers). Private individuals are counted, never recorded.")));
    const ex = EX();
    const checkedAll = allPosts().filter((p) => p.breakout && (p.breakout.level || p.breakout.projected));
    const lvKey = (p) => (p.breakout.projected ? p.breakout.projected.level : p.breakout.level) || 0;
    const checked = checkedAll.filter((p) => S.f.unverified || !p.unverified).sort((a, b) => (lvKey(b) - lvKey(a)) || ((b.breakout.level || 0) - (a.breakout.level || 0)) || (b.risk || 0) - (a.risk || 0));
    const L = S.snap.labels || {};
    const mix = {}, mixP = {};
    checkedAll.forEach((p) => { if (p.breakout.level) mix[p.breakout.level] = (mix[p.breakout.level] || 0) + 1; if (p.breakout.projected) mixP[p.breakout.projected.level] = (mixP[p.breakout.projected.level] || 0) + 1; });
    const byLv = L.by_level || {};
    v.appendChild(h("div", { class: "grid" },
      h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Measured posts by level"), ex ? simChip() : null),
        rankList(LADDER.map(([n, t]) => [n + " · " + t, mix[n] || 0]).filter((r) => r[1] > 0)),
        Object.keys(mixP).length ? [h("h3", null, "Projected at 7 days"), rankList(LADDER.map(([n, t]) => [n + " · " + t, mixP[n] || 0]).filter((r) => r[1] > 0))] : null,
        h("p", { class: "note" }, "Posts carried in this snapshot. Posts meeting the check rule are always measured; a 5% audit sample of all others is measured too, so calibration can weight outcomes by 1 / P(measured).")),
      h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Outcome labels"), ex ? simChip("Auto-labels follow the simulated checks") : null),
        h("div", { class: "kpis two" }, kpi(fmt(L.total || 0), "labelled posts"), kpi(fmt((L.by_source || {}).analyst || 0), "analyst labels"), kpi(fmt((L.by_source || {}).auto || 0), "auto-labels at the 7-day horizon"), kpi(fmt(L.censored || 0), "censored: fewer than two social lanes answered")),
        Object.keys(byLv).length ? rankList(Object.keys(byLv).sort().map((k2) => ["B" + k2 + " · " + LADDER[+k2 - 1][1], byLv[k2]])) : h("div", { class: "empty" }, "No labels yet. Auto-labels arrive once measured posts pass the 7-day horizon."))));
    if (ex && (ex.injects || []).length) v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Exercise injects"), simChip("Scripted outcomes")),
      h("p", { class: "small" }, "Scripted outcomes fixed for these posts so every level of the scale appears. Every other measured post is one draw from the simulation truth (seed " + ex.seed + ")."),
      h("div", { class: "tablewrap" }, h("table", null, h("thead", null, h("tr", null, h("th", { class: "num" }, "Level"), h("th", null, "Post"), h("th", null, "Scenario"))),
        h("tbody", null, ex.injects.map((i) => { const p = P(i.post_id); return h("tr", { class: "clickable", onclick: () => openPost(i.post_id) }, h("td", { class: "num" }, i.level), h("td", null, p ? [ccChip(p.country), " ", p.name, h("div", { class: "muted small" }, (p.title || p.text || "").slice(0, 110))] : i.post_id), h("td", { class: "small" }, i.scenario)); }))))));
    v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Measured posts"), ex ? simChip() : null), unvToggle(checkedAll.length - checked.length), checked.length ? h("div", { class: "tablewrap" }, h("table", null,
      h("thead", null, h("tr", null, h("th", { class: "num" }, "So far"), ex ? h("th", { class: "num" }, "At 7 d") : null, h("th", null, "Post"), h("th", null, "Lanes with pickup"), h("th", { class: "num" }, "Checks"), h("th", { class: "num" }, "P(B≥3) now"), h("th", null, "Label"))),
      h("tbody", null, checked.slice(0, S.allMeasured ? 1000 : 50).map((p) => h("tr", { class: "clickable", onclick: () => openPost(p.id) }, h("td", { class: "num" }, p.breakout.level || "–"), ex ? h("td", { class: "num" }, p.breakout.projected ? p.breakout.projected.level : "–") : null,
        h("td", null, ccChip(p.country), " ", p.name, p.flag ? [" ", flagChip(p.flag, p.capped)] : null, h("div", { class: "muted small" }, (p.title || p.text || "").slice(0, 120))),
        h("td", { class: "small" }, ((p.breakout.why || {}).reasons || []).join("; ") || (p.breakout.checks ? "none" : "first check not yet due")), h("td", { class: "num" }, p.breakout.checks || 0), h("td", { class: "num" }, pct(p.p3, 1)),
        h("td", null, labelChip(p.label) || h("span", { class: "muted small" }, "–"))))))) : null,
      checked.length > 50 ? h("button", { class: "btn", onclick: () => { S.allMeasured = !S.allMeasured; renderView(); } }, S.allMeasured ? "Show the first 50" : "Show all " + checked.length + " measured posts") : null,
      checked.length ? null : h("div", { class: "empty" }, "No breakout checks recorded yet. Add at least two lanes (Bluesky app password, Reddit OAuth, X budget, YouTube key) so level 3 is measurable; GDELT alone can only register level 4.")));
  }

  function vCoordination(v) {
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Coordination & laundering"), h("p", { class: "lede" }, "Where the same item moves across outlets, countries and platforms. Echo clusters join posts that share a story link or near-duplicate text (MinHash, Jaccard ≥ 0.6) within 72 hours. Homepage, profile, messenger, donation and footer links are ignored, and so are the boilerplate lines a channel adds to every post, because they identify the poster rather than the story.")));
    const echoC = (S.snap.echo || []).filter((e) => S.f.country === "ALL" || e.countries.includes(S.f.country));
    const echo = echoC.filter((e) => S.f.unverified || !e.unverified_only);
    v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Echo clusters"), h("span", { class: "note" }, echo.filter((e) => e.countries.length >= 2).length + " cross-country")), unvToggle(echoC.length - echo.length),
      echo.length ? h("div", { class: "tablewrap" }, h("table", null,
        h("thead", null, h("tr", null, h("th", null, "Lead item"), h("th", null, "States"), h("th", { class: "num" }, "Sources"), h("th", { class: "num" }, "Posts"), h("th", null, "Platforms"), h("th", null, "Span"))),
        h("tbody", null, echo.slice(0, 80).map((e) => h("tr", { class: "clickable", onclick: () => openPost(e.lead) }, h("td", null, e.title), h("td", null, e.countries.map((c) => [ccChip(c), " "])),
          h("td", { class: "num" }, e.sources), h("td", { class: "num" }, e.posts), h("td", { class: "small" }, e.platforms.map((p) => PLATNAME[p] || p).join(", ")), h("td", { class: "small" }, ago(e.first) + " → " + ago(e.last))))))) : h("div", { class: "empty" }, "No multi-source clusters in window.")));
    const co = S.snap.coordination || {};
    v.appendChild(h("section", { class: "panel" }, h("h3", null, "Coordinated link sharing"),
      h("p", { class: "note" }, co.window_s ? `Rapid-share window estimated from this corpus: ${co.window_s} s (fastest decile of inter-source share gaps, as in CooRnet). Pairs that co-shared at least three distinct URLs inside it:` : "Not enough shared links to estimate a window."),
      (co.networks || []).length ? h("div", { class: "tablewrap" }, h("table", null, h("thead", null, h("tr", null, h("th", { class: "num" }, "Size"), h("th", null, "Sources"))),
        h("tbody", null, co.networks.slice(0, 30).map((n) => h("tr", null, h("td", { class: "num" }, n.size), h("td", { class: "small" }, n.sources.join(" · "))))))) : h("div", { class: "empty" }, "No coordinated pairs above threshold in this window.")));
    const prov = S.snap.provenance || [];
    v.appendChild(h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Aggregator provenance"), h("span", { class: "note" }, "what the laundering aggregators say they lifted, and from whom")),
      h("p", { class: "warnbox" }, "An upstream channel appears here because an aggregator named it. That is evidence about the aggregator, not about the upstream: channels marked 'not attributed' may be independent, foreign or American, and are never scored."),
      prov.length ? h("div", { class: "tablewrap" }, h("table", null, h("thead", null, h("tr", null, h("th", null, "Aggregator"), h("th", null, "Upstream channel"), h("th", { class: "num" }, "Items"), h("th", null, "Status"))),
        h("tbody", null, prov.slice(0, 60).map((r) => h("tr", null, h("td", { class: "small" }, r.aggregator.replace(/^rss:https?:\/\//, "")), h("td", { class: "mono" }, r.upstream), h("td", { class: "num" }, r.items),
          h("td", null, r.watchlisted ? h("span", { class: "chip st-live" }, "watchlisted") : h("span", { class: "chip" }, "not attributed"))))))) : h("div", { class: "empty" }, "No aggregator items in window.")));
  }

  function vFlashpoints(v) {
    const sal = {};
    for (const r of S.snap.salience || []) (sal[r.flashpoint] = sal[r.flashpoint] || []).push([r.day, r.volume]);
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "US flashpoints"), h("p", { class: "lede" }, "Live domestic grievances that foreign content attaches to. Coupling a post to an active flashpoint is one of the strongest terms in the breakout model. Salience is GDELT's share of monitored US coverage mentioning the flashpoint's anchor terms.")));
    const fpsAll = S.snap.flashpoints || [];
    v.appendChild(unvToggle(S.f.unverified ? 0 : fpsAll.reduce((a, f) => a + (f.n_linked_unverified || 0), 0)) || document.createTextNode(""));
    v.appendChild(h("div", { class: "grid" }, fpsAll.map((f) => {
      const linked = (f.linked || []).concat(S.f.unverified ? (f.linked_unverified || []) : []).map(P).filter(Boolean).sort((a, b) => (b.risk || 0) - (a.risk || 0));
      const nLinked = (f.n_linked || 0) + (S.f.unverified ? (f.n_linked_unverified || 0) : 0);
      const series = (sal[f.id] || []).sort();
      return h("section", { class: "panel" },
        h("div", { class: "panel-head" }, h("h3", null, f.id + " · " + f.category.replace("_", " ")), h("span", { class: "chip " + (f.status === "active" ? "st-live" : "st-stale") }, f.status)),
        h("strong", null, f.title), h("p", { class: "small" }, f.summary),
        h("div", null, h("div", { class: "note" }, "US news salience (GDELT, 14 d)"), sparkline(series)),
        h("p", { class: "small" }, h("strong", { class: "num" }, String(nLinked)), " foreign-state posts coupled in window", linked.length ? ": top " + Math.min(3, linked.length) + " below" : ""),
        linked.slice(0, 3).map((p) => h("div", { class: "small", style: { cursor: "pointer" }, onclick: () => openPost(p.id) }, ccChip(p.country), " ", sevChip(p.sev), " ", h("span", null, (p.title || p.text || "").slice(0, 120)))),
        h("div", { class: "note" }, "Window " + f.start + " → " + f.end + " · "), refList(f.refs));
    })));
  }

  function vSources(v) {
    const F = S.srcF;
    const all = S.snap.sources || [];
    const rows = all.filter((r) => (F.country === "ALL" || r.country === F.country) && (F.cat === "all" || r.cat === F.cat) && (F.platform === "all" || r.platform === F.platform) &&
      (F.status === "any" || r.status === F.status) && (!F.q || (r.name + " " + r.handle).toLowerCase().includes(F.q.toLowerCase())));
    const per = 60, pages = Math.max(1, Math.ceil(rows.length / per));
    S.srcPage = Math.min(S.srcPage, pages - 1);
    const st = {}; all.forEach((r) => { st[r.status] = (st[r.status] || 0) + 1; });
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Watchlist"), h("p", { class: "lede" }, all.length + " platform accounts across " + new Set(all.map((r) => r.entity)).size + " entities: the published Hamilton 2.0 list (ASD, Nov 2023) plus a graded aggregator tier. Telegram and feed status is live-verified; X, Facebook and Instagram handles verify once their keys are added.")));
    v.appendChild(h("div", { class: "kpis" }, Object.entries(st).sort((a, b) => b[1] - a[1]).map(([k, n]) => kpi(String(n), k.replace("_", " ")))));
    const selp = (label, key, opts) => h("div", { class: "fgroup" }, h("span", null, label), h("select", { onchange: (e) => { F[key] = e.target.value; S.srcPage = 0; renderView(); } }, opts.map(([k, t]) => h("option", { value: k, selected: F[key] === k }, t))));
    const q = h("input", { type: "search", placeholder: "Name or handle", value: F.q });
    q.addEventListener("input", debounce(() => { F.q = q.value.trim(); S.srcPage = 0; renderView(); }, 250));
    v.appendChild(h("div", { class: "filters", style: { borderBottom: "0" } },
      selp("Country", "country", [["ALL", "All"], ["RU", "Russia"], ["CN", "China"], ["IR", "Iran"]]),
      selp("Category", "cat", [["all", "All"], ["media", "State media"], ["gov", "Government"], ["aggregator", "Aggregator"], ["domestic_aggregator", "Domestic aggregator"]]),
      selp("Platform", "platform", [["all", "All"]].concat([...new Set(all.map((r) => r.platform))].sort().map((p) => [p, PLATNAME[p] || p]))),
      selp("Status", "status", [["any", "Any"]].concat(Object.keys(st).sort().map((k) => [k, k.replace("_", " ")]))), h("div", { class: "fgroup" }, h("span", null, "Find"), q)));
    const slice = rows.slice(S.srcPage * per, (S.srcPage + 1) * per);
    const link = (r) => {
      const hnd = r.handle;
      const url = r.platform === "telegram" ? "https://t.me/" + hnd : r.platform === "x" ? "https://x.com/" + hnd : r.platform === "youtube" ? (hnd.startsWith("UC") ? "https://www.youtube.com/channel/" + hnd : "https://www.youtube.com/@" + hnd) :
        r.platform === "facebook" ? "https://www.facebook.com/" + hnd : r.platform === "instagram" ? "https://www.instagram.com/" + hnd : r.platform === "rumble" ? "https://rumble.com/" + hnd : /^https?:/.test(hnd) ? hnd : null;
      return url ? h("a", { href: url, target: "_blank", rel: "noopener noreferrer" }, hnd.replace(/^https?:\/\//, "").slice(0, 48)) : hnd;
    };
    v.appendChild(h("div", { class: "tablewrap" }, h("table", null,
      h("thead", null, h("tr", null, h("th", null, "Entity"), h("th", null, ""), h("th", null, "Platform"), h("th", null, "Handle"), h("th", null, "Category"), h("th", null, "Grade"), h("th", null, "Status"), h("th", { class: "num" }, "Followers"), h("th", null, "Last post"), h("th", null, "Evidence"))),
      h("tbody", null, slice.map((r) => h("tr", null, h("td", null, r.name, r.affil_verified === false ? h("div", { class: "muted small" }, "individual · affiliation to re-verify") : null), h("td", null, ccChip(r.country)),
        h("td", null, PLATNAME[r.platform] || r.platform), h("td", { class: "small" }, link(r)), h("td", { class: "small" }, CATNAME[r.cat] || r.cat), h("td", null, gradeChip(r.grade)),
        h("td", null, h("span", { class: "chip st-" + r.status, title: r.note }, r.status.replace("_", " "))), h("td", { class: "num" }, fmt(r.followers)), h("td", { class: "small" }, r.last_post ? ago(r.last_post) : "—"), h("td", null, refList(r.evidence))))))));
    v.appendChild(h("div", { class: "pager" }, rows.length + " rows · page " + (S.srcPage + 1) + " of " + pages,
      h("button", { disabled: S.srcPage <= 0, onclick: () => { S.srcPage--; renderView(); } }, "Previous"), h("button", { disabled: S.srcPage >= pages - 1, onclick: () => { S.srcPage++; renderView(); } }, "Next")));
  }

  function vPlatforms(v) {
    const pl = (S.snap.platforms || {}).platforms || [];
    const lanes = {}; (S.snap.lanes || []).forEach((l) => { lanes[l.platform] = l; });
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "US platforms and access"), h("p", { class: "lede" }, "Every social platform with meaningful US use, its reach (Pew 2025), and the lawful route PUBLIUS uses to read it. Where no lawful route exists the slot is kept and the content is tracked through links that surface elsewhere.")));
    const mx = 0.84;
    v.appendChild(h("div", { class: "tablewrap" }, h("table", null,
      h("thead", null, h("tr", null, h("th", null, "Platform"), h("th", null, "US adults using"), h("th", { class: "num" }, "News users"), h("th", null, "Role"), h("th", null, "Access"), h("th", null, "Connector"), h("th", null, "What it takes"))),
      h("tbody", null, pl.map((p) => { const l = lanes[p.connector] || {}; return h("tr", null, h("td", null, h("strong", null, p.name), p.watch_note ? h("div", { class: "muted small" }, p.watch_note) : null),
        h("td", { style: { minWidth: "130px" } }, p.us_reach != null ? h("div", { style: { display: "flex", gap: "6px", alignItems: "center" } }, h("span", { class: "num", style: { width: "36px" } }, pct(p.us_reach)),
          h("span", { style: { flex: 1, height: "6px", background: "var(--bar-soft)", borderRadius: "3px", overflow: "hidden" } }, h("span", { style: { display: "block", height: "100%", width: (100 * p.us_reach / mx) + "%", background: "var(--bar)" } }))) : h("span", { class: "muted" }, "n/a")),
        h("td", { class: "num" }, p.news_reach != null ? pct(p.news_reach) : "—"), h("td", null, p.role), h("td", null, h("span", { class: "chip" }, p.access)),
        h("td", null, p.connector ? (l.simulated ? simChip("Breakout answers simulated in this exercise; " + (l.real_why || "")) : l.enabled && l.ready ? h("span", { class: "chip st-live" }, "on") : h("span", { class: "chip st-stale", title: l.why || "" }, l.enabled ? "needs keys" : "off")) : h("span", { class: "chip st-dead" }, "no lawful API")),
        h("td", { class: "small" }, p.requirement)); })))));
    v.appendChild(h("p", { class: "note" }, (S.snap.platforms._meta || {}).reach_source || ""));
    v.appendChild(healthPanel());
  }
  function healthPanel() {
    const runs = S.snap.runs || [], last = {}, tot = {};
    runs.forEach((r) => { if (!last[r.connector] || r.started > last[r.connector].started) last[r.connector] = r; const t = (tot[r.connector] = tot[r.connector] || { runs: 0, items: 0, errors: 0 }); t.runs++; t.items += r.items || 0; t.errors += r.errors || 0; });
    const ex = EX(), searches = (ex && ex.counts && ex.counts.searches) || {};
    const mode = (l) => { const en = l.simulated ? l.real_enabled : l.enabled, rd = l.simulated ? l.real_ready : l.ready;
      return !en ? h("span", { class: "chip" }, "off") : rd ? h("span", { class: "chip st-live" }, "on") : h("span", { class: "chip st-stale", title: l.real_why || l.why }, "needs keys"); };
    const lanes = (S.snap.lanes || []).slice().sort((a, b) => (b.enabled - a.enabled) || ((last[b.platform] ? 1 : 0) - (last[a.platform] ? 1 : 0)) || a.label.localeCompare(b.label));
    const spend = S.snap.spend || [];
    return h("section", { class: "panel" }, h("div", { class: "panel-head" }, h("h3", null, "Collection health"), h("span", { class: "note" }, "state is the real collection; last " + runs.length + " runs recorded")),
      h("div", { class: "tablewrap" }, h("table", null, h("thead", null, h("tr", null, h("th", null, "Lane"), h("th", null, "State"), h("th", { class: "num" }, "Sources live / listed"), h("th", null, "Last run"), h("th", { class: "num" }, "Items (recent runs)"), h("th", { class: "num" }, "Errors"), h("th", null, "Breakout"))),
        h("tbody", null, lanes.map((l) => { const r = last[l.platform], t = tot[l.platform];
          return h("tr", null, h("td", null, l.label), h("td", null, mode(l)), h("td", { class: "num" }, l.sources ? (l.live_sources || 0) + " / " + l.sources : "–"),
            h("td", { class: "small" }, r ? ago(r.started) + (r.note ? " · " + r.note.slice(0, 60) : "") : "–"), h("td", { class: "num" }, t ? fmt(t.items) : "–"), h("td", { class: "num" }, t ? t.errors : "–"),
            h("td", { class: "small" }, !l.breakout_lane ? "–" : l.simulated ? [simChip("Breakout answers simulated in this exercise"), " " + fmt(searches[l.platform] || 0) + " searches"] : l.breakout_ready && l.enabled ? "ready" : (l.breakout_why || "not ready"))); })))),
      spend.length ? h("div", null, h("h3", null, "API spend"), ex ? simChip("X spend here counts the simulated calls") : null,
        rankList(spend.map((r) => [r.day + " · " + (PLATNAME[r.lane] || r.lane) + " · " + fmt(r.units) + " calls", r.usd]).slice(-10)),
        h("p", { class: "note" }, "US dollars. X runs pay-per-use under x.daily_budget_usd (default $5 a day); the lane stops when the day's budget is spent.")) : null);
  }

  function vModel(v) {
    const m = S.snap.meta.model;
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "The breakout model"), h("span", { class: "chip " + (m.calibrated ? "st-live" : "st-stale") }, m.calibrated ? "calibrated · " + m.version : "prior only · " + m.version)));
    v.appendChild(h("div", { class: "panel" }, h("p", null, "Outcome: the Breakout Scale level B a post reaches in US-audience lanes within 7 days. Model: proportional-odds (cumulative logit), P(B ≥ k | x) = logistic(η − θk) with η = β·x (McCullagh 1980). Coefficients carry Gaussian priors; predictions integrate over them with the probit approximation (MacKay 1992) and report an 80% credible interval. The unrest risk index multiplies P(B ≥ 3) by a severity weight (S1 1, S2 2, S3 4, S4 8) and rescales to 0–100."),
      h("p", null, "Calibration: posts meeting the check rule are always measured and a random 5% of all others is audited, so each observed outcome carries weight 1 / P(checked) (Horvitz–Thompson). `publius calibrate` fits the MAP under the priors, reports a time-ordered backtest (Brier, log loss, ECE, AUC) against the prior model, and switches the dashboard to the fitted version only when there are ≥ 200 labelled posts including ≥ 10 at level 3+."),
      (m.calibrated || S.snap.calibration) ? null : h("p", { class: "note" }, "No calibration yet. Until then, rankings are meaningful and absolute probabilities are analyst priors.")));
    const cal = S.snap.calibration, ex = EX(), fit = (cal && cal.fit) || null, truth = ex && ex.truth;
    if (cal) v.appendChild(calPanel(cal, ex));
    v.appendChild(h("div", { class: "tablewrap" }, h("table", null,
      h("thead", null, h("tr", null, h("th", null, "Term"), h("th", { class: "num" }, "Prior β"), h("th", { class: "num" }, "sd"), h("th", { class: "num" }, "Odds ×"),
        fit ? h("th", { class: "num" }, "Fitted β ± sd") : null, truth ? h("th", { class: "num" }, "Simulation truth") : null, h("th", null, "Basis"), h("th", null, "Note"))),
      h("tbody", null, (m.beta || []).map((b) => { const fb = fit && fit.beta ? fit.beta[b.name] : null, fs = fit && fit.beta_sd ? fit.beta_sd[b.name] : null, tb = truth ? truth.beta[b.name] : null;
        return h("tr", null, h("td", null, FEAT[b.name] || b.name, h("div", { class: "muted small mono" }, b.name)), h("td", { class: "num" }, b.prior_mean.toFixed(3)), h("td", { class: "num" }, b.prior_sd.toFixed(3)),
          h("td", { class: "num" }, Math.exp(b.prior_mean).toFixed(2)),
          fit ? h("td", { class: "num nowrap" }, fb == null ? "–" : [fb.toFixed(2) + " ± " + (fs || 0).toFixed(2), " ", h("span", { class: "shift " + (fb > b.prior_mean + 0.05 ? "up" : fb < b.prior_mean - 0.05 ? "down" : "flat"), "aria-hidden": "true" }, fb > b.prior_mean + 0.05 ? "▲" : fb < b.prior_mean - 0.05 ? "▼" : "•")]) : null,
          truth ? h("td", { class: "num" }, tb == null ? "–" : tb.toFixed(2)) : null,
          h("td", null, b.basis === "analyst" ? h("span", { class: "chip" }, "analyst prior") : refLink(b.basis)), h("td", { class: "small" }, b.note)); })))));
    const br = m.base_rates || {};
    const fbr = fit && fit.theta ? Object.fromEntries(Object.entries(fit.theta).map(([k, t]) => [k, 1 / (1 + Math.exp(t))])) : null;
    const tbr = truth ? truth.base_rates : null;
    v.appendChild(h("div", { class: "grid" },
      h("section", { class: "panel" }, h("h3", null, "Reference-post base rates"), h("div", { class: "tablewrap" }, h("table", null,
        h("thead", null, h("tr", null, h("th", null, "Level reached"), h("th", { class: "num" }, "Prior"), fbr ? h("th", { class: "num" }, "Fitted") : null, tbr ? h("th", { class: "num" }, "Truth") : null)),
        h("tbody", null, Object.keys(br).sort().map((k) => h("tr", null, h("td", null, "B ≥ " + k + " · " + LADDER[+k - 1][1]), h("td", { class: "num" }, pct(br[k], 2)), fbr ? h("td", { class: "num" }, pct(fbr[k], 2)) : null, tbr ? h("td", { class: "num" }, pct(tbr[k], 2)) : null))))),
        h("p", { class: "note" }, "For an English state-media post with 100k followers on a platform with X's US reach and no US-domestic content. " + (fbr ? "The fitted column is what the last calibration found; priors shrink it toward the analyst values." : "Calibration replaces the priors."))),
      h("section", { class: "panel" }, h("h3", null, "Probability words (ICD-203)"), h("ol", { class: "rank" }, [["almost no chance", "< 5%"], ["very unlikely", "5–20%"], ["unlikely", "20–45%"], ["roughly even chance", "45–55%"], ["likely", "55–80%"], ["very likely", "80–95%"], ["almost certain", "≥ 95%"]].map(([w, r]) => h("li", null, h("span", { class: "lab" }, w), h("span", { class: "val" }, r))))),
      h("section", { class: "panel" }, h("h3", null, "Flags"), h("p", { class: "small" }, "ALERT: severity ≥ S3 and P(B≥3) ≥ 20%. WATCH: severity ≥ S3 with lift ≥ 2× reference, or S2 with lift ≥ 5×, or any S4. Individuals whose state-media affiliation has not been re-verified are capped at WATCH."),
        h("h3", null, "Severity ladder"), h("ol", { class: "rank" }, SEVNAME.map((n, i) => h("li", null, h("span", { class: "lab" }, sevChip(i), " ", n)))))));
  }

  function calPanel(cal, ex) {
    const ok = cal.status === "ok";
    const head = h("div", { class: "panel-head" }, h("h3", null, "Calibration"),
      h("span", { class: "chips" }, ex ? simChip("Fitted on simulated outcomes") : null, h("span", { class: "chip " + (ok ? (cal.applied ? "st-live" : "st-stale") : "st-stale") }, ok ? (cal.applied ? "applied · " + cal.version : "dry run · not applied") : "insufficient data")));
    const kids = [head];
    if (!ok) {
      kids.push(h("p", null, cal.message || "Not enough labelled outcomes yet."));
    } else {
      const bt = cal.backtest && cal.backtest.b3;
      kids.push(h("div", { class: "kpis" }, kpi(fmt(cal.n), "labelled posts used"), kpi(String(cal.positives_b3), "at level 3 or higher"), kpi(String(cal.effective_n), "effective sample size (Kish)"),
        cal.backtest ? kpi(cal.backtest.train_n + " / " + cal.backtest.test_n, "train / test posts (time-ordered)") : kpi("–", "no backtest: too few later posts")));
      if (bt) {
        const rows = [["Brier score", "brier", "lower"], ["Brier skill vs base rate", "brier_skill", "higher"], ["Log loss", "logloss", "lower"], ["Expected calibration error", "ece", "lower"], ["AUC (ranking)", "auc", "higher"]];
        kids.push(h("div", { class: "cols" },
          h("div", null, h("h3", null, "Backtest on later posts, P(B ≥ 3)"), h("div", { class: "tablewrap" }, h("table", null, h("thead", null, h("tr", null, h("th", null, "Metric"), h("th", { class: "num" }, "Fitted"), h("th", { class: "num" }, "Prior"), h("th", null, ""))),
            h("tbody", null, rows.map(([t, k2, dir]) => { const a = bt.fitted[k2], b2 = bt.prior[k2]; const better = a != null && b2 != null && (dir === "lower" ? a < b2 : a > b2);
              return h("tr", null, h("td", null, t), h("td", { class: "num" }, a == null ? "–" : a), h("td", { class: "num" }, b2 == null ? "–" : b2), h("td", { class: "small" }, a == null || b2 == null ? "" : better ? "fitted better" : "prior better")); })))),
            h("p", { class: "note" }, "Test posts come after every training post" + (cal.gap_s ? ", with a " + Math.round(cal.gap_s / 86400) + "-day gap so no outcome window overlaps" : "") + ". Weighted by 1 / P(measured).")),
          h("div", null, h("h3", null, "Reliability"), reliabilityChart([{ name: "Fitted", pts: bt.fitted.reliability || [], cls: "fit" }, { name: "Prior", pts: bt.prior.reliability || [], cls: "pri" }]))));
      } else if (cal.in_sample && cal.in_sample.b3) {
        kids.push(h("h3", null, "Reliability (in sample)"), reliabilityChart([{ name: "Fitted", pts: cal.in_sample.b3.reliability || [], cls: "fit" }]));
      }
    }
    const cnt = cal.counts || {};
    kids.push(h("div", { class: "cols" },
      h("div", null, h("h3", null, "Labels by level"), rankList(Object.keys(cnt).sort().filter((k2) => cnt[k2]).map((k2) => ["B" + k2 + " · " + LADDER[+k2 - 1][1], cnt[k2]]))),
      h("div", null, h("h3", null, "Left out"), Object.keys(cal.excluded || {}).length ? rankList(Object.entries(cal.excluded)) : h("p", { class: "small muted" }, "Nothing excluded: every label came from a measured post first scored within 6 hours, with two or more social lanes answering."))));
    if (ex) kids.push(h("p", { class: "note" }, (ex.notes || []).filter((n) => /calibration|backtest/i.test(n)).join(" ")));
    return h("section", { class: "panel" }, kids);
  }
  function reliabilityChart(series) {
    const all = series.flatMap((sr) => sr.pts);
    if (!all.length) return h("div", { class: "empty" }, "No bins to draw.");
    const W = Math.min(avail(0.5), 520), H = 250, L = 46, B = 38, T = 10, R = 14;
    const mx = Math.min(1, Math.max(0.02, ...all.map((d) => Math.max(d.p_mean, d.obs_rate))) * 1.12);
    const sx = (v) => L + (W - L - R) * Math.sqrt(Math.max(0, v) / mx), sy = (v) => T + (H - T - B) * (1 - Math.sqrt(Math.max(0, v) / mx));
    const g = s("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart rel", role: "img", "aria-label": "Predicted against observed share reaching level 3 or higher" });
    [0.01, 0.05, 0.1, 0.2, 0.4, 0.6, 1].filter((t) => t <= mx).forEach((t) => {
      g.appendChild(s("line", { x1: sx(t), x2: sx(t), y1: T, y2: H - B, class: "grid-line" })); g.appendChild(s("line", { x1: L, x2: W - R, y1: sy(t), y2: sy(t), class: "grid-line" }));
      g.appendChild(s("text", { x: sx(t), y: H - B + 14, "text-anchor": "middle" }, pct(t, 0))); g.appendChild(s("text", { x: L - 6, y: sy(t) + 4, "text-anchor": "end" }, pct(t, 0)));
    });
    g.appendChild(s("line", { x1: L, x2: W - R, y1: sy(0), y2: sy(0), class: "grid-line" })); g.appendChild(s("line", { x1: sx(0), x2: sx(0), y1: T, y2: H - B, class: "grid-line" }));
    g.appendChild(s("line", { x1: sx(0), y1: sy(0), x2: sx(mx), y2: sy(mx), class: "diag" }));
    g.appendChild(s("text", { x: (L + W - R) / 2, y: H - 4, "text-anchor": "middle", class: "axis-title" }, "predicted P(B ≥ 3), square-root scale"));
    series.forEach((sr) => {
      const pts = sr.pts.slice().sort((a, b) => a.p_mean - b.p_mean);
      if (pts.length > 1) g.appendChild(s("path", { d: pts.map((d, i) => (i ? "L" : "M") + sx(d.p_mean).toFixed(1) + " " + sy(d.obs_rate).toFixed(1)).join(""), class: "rel-line " + sr.cls }));
      pts.forEach((d) => {
        const r = Math.max(4, Math.min(9, 3 + Math.sqrt(d.n)));
        const m = sr.cls === "pri" ? s("rect", { x: sx(d.p_mean) - r * 0.8, y: sy(d.obs_rate) - r * 0.8, width: r * 1.6, height: r * 1.6, class: "rel-pt " + sr.cls }) : s("circle", { cx: sx(d.p_mean), cy: sy(d.obs_rate), r, class: "rel-pt " + sr.cls });
        m.addEventListener("mousemove", (e) => showTip(e, [sr.name + " model", "predicted " + pct(d.p_mean, 1) + " · observed " + pct(d.obs_rate, 1), d.n + " posts (weight " + d.weight + ")"]));
        m.addEventListener("mouseleave", hideTip);
        g.appendChild(m);
      });
    });
    return h("div", null, g, h("div", { class: "legend" }, series.map((sr) => h("span", null, h("span", { class: "key " + sr.cls }), sr.name)), h("span", null, h("span", { class: "key diag" }), "perfect calibration"),
      h("span", { class: "muted" }, "y: observed share at B ≥ 3 · marker size: posts in the bin")));
  }

  function vMethod(v) {
    v.appendChild(h("div", { class: "section-head" }, h("h2", null, "Method, rails and sources")));
    v.appendChild(h("div", { class: "grid" },
      h("section", { class: "panel" }, h("h3", null, "What goes on the watchlist"), h("p", { class: "small" }, "Overt accounts that openly represent the Russian, Chinese or Iranian government, diplomatic corps or state media (the Hamilton 2.0 inclusion rule), plus aggregators whose state linkage or state amplification is documented and graded. Nobody enters the list because of what they post."),
        h("p", { class: "small" }, "Individuals Hamilton listed as state-media affiliates in November 2023 are kept but flagged until their affiliation is re-verified; their posts can reach WATCH but not ALERT.")),
      h("section", { class: "panel" }, h("h3", null, "What never happens"), h("p", { class: "small" }, "No posting, liking, following, joining or messaging on any platform. No logging in as anyone else, no self-bots, no scraping behind a login or a bot wall. No profiles of US persons: breakout lanes return counts, and only public figures above the follower threshold are named.")),
      h("section", { class: "panel" }, h("h3", null, "The limit of the claim"), h("p", { class: "small" }, "The model estimates the chance that a foreign-state post reaches US audiences at a level associated with unrest, and how severe it is. It does not estimate whether one post causes unrest; the best evidence says direct effects of foreign posts on US attitudes and behaviour are small, and that the danger is amplification of grievances that are already live."))));
    const refs = S.snap.refs || {};
    v.appendChild(h("div", { class: "tablewrap" }, h("table", null, h("thead", null, h("tr", null, h("th", null, "Ref"), h("th", null, "Title"), h("th", null, "Publisher"), h("th", null, "Date"), h("th", null, "Grade"))),
      h("tbody", null, Object.entries(refs).map(([id, r]) => h("tr", null, h("td", { class: "mono small" }, id), h("td", null, h("a", { href: r.url, target: "_blank", rel: "noopener noreferrer" }, r.title)), h("td", { class: "small" }, r.publisher), h("td", { class: "small" }, r.date), h("td", null, gradeChip(r.grade))))))));
  }

  // ------------------------------------------------------------------ routing
  const TABS = [
    { id: "brief", label: "Brief", group: "Assessment", render: vBrief, filters: "basic" },
    { id: "overview", label: "Overview", group: "Hamilton", render: vOverview, filters: "basic" },
    { id: "search", label: "Search", group: "Hamilton", render: vSearch, filters: "search" },
    { id: "trends", label: "Trends", group: "Hamilton", render: vTrends, filters: null },
    { id: "unrest", label: "Unrest Watch", group: "Unrest", render: vUnrest, filters: "unrest", count: () => (S.snap.queue || []).length },
    { id: "narratives", label: "Narratives", group: "Unrest", render: vNarratives, filters: null },
    { id: "breakout", label: "Breakout", group: "Unrest", render: vBreakout, filters: null },
    { id: "coordination", label: "Coordination", group: "Unrest", render: vCoordination, filters: "basic" },
    { id: "flashpoints", label: "Flashpoints", group: "Unrest", render: vFlashpoints, filters: null },
    { id: "sources", label: "Watchlist", group: "Collection", render: vSources, filters: null },
    { id: "platforms", label: "Platforms", group: "Collection", render: vPlatforms, filters: null },
    { id: "model", label: "Model", group: "Collection", render: vModel, filters: null },
    { id: "method", label: "Method", group: "Collection", render: vMethod, filters: null },
  ];
  function go(id) { S.tab = id; lsSet("publius.tab", id); try { history.replaceState(null, "", "#" + id); } catch (e) { /* ignore */ } render(); window.scrollTo(0, 0); }
  function renderTabs() {
    const nav = $("tabs"); nav.textContent = "";
    const groups = [];
    TABS.forEach((t) => { let g = groups.find((x) => x.name === t.group); if (!g) { g = { name: t.group, tabs: [] }; groups.push(g); } g.tabs.push(t); });
    nav.setAttribute("role", "tablist");
    groups.forEach((g) => nav.appendChild(h("div", { class: "tab-group" }, h("span", { class: "tab-group-label" }, g.name),
      g.tabs.map((t) => h("button", { class: "tab", role: "tab", id: "tab-" + t.id, "aria-selected": String(S.tab === t.id), onclick: () => go(t.id) }, t.label, t.count ? h("span", { class: "count" }, String(t.count())) : null)))));
  }
  function renderView() {
    const v = $("view"); v.textContent = "";
    const t = TABS.find((x) => x.id === S.tab) || TABS[0];
    try { t.render(v); } catch (e) { v.appendChild(h("div", { class: "warnbox" }, "This view failed to render: " + e.message)); console.error(e); }
  }
  function render() {
    renderTabs();
    const t = TABS.find((x) => x.id === S.tab) || TABS[0];
    filterBar(t.filters);
    renderView();
  }
  function exerciseBand(ex) {
    const list = (t, arr) => h("div", null, h("h4", null, t), h("ul", null, (arr || []).map((x) => h("li", null, x))));
    return [h("div", { class: "ex-mark", "aria-hidden": "true" }, "EXERCISE · EXERCISE · EXERCISE"),
      h("p", null, h("strong", null, "Exercise preview. "), "The real 24 September collection, run through simulated US-audience lanes on a copy of the database. Posts, text, sources, severity, narratives, coordination, flashpoints and the brief are real. Pickup counts, public figures, indicator counts, labels, calibration and lane states are simulated and carry a ", simChip(), " mark. Flags on measured posts include simulated pickups observed so far."),
      h("details", null, h("summary", null, "What is real, what is simulated, and how"), h("div", { class: "ex-cols" }, list("Real", ex.real), list("Simulated", ex.simulated), list("How the exercise runs", ex.notes)))];
  }
  function renderStatus() {
    const m = S.snap.meta, st = $("status"); st.textContent = "";
    const ex = EX();
    let band = $("exband");
    if (ex && !band) { band = h("section", { id: "exband", class: "exband", "aria-label": "Exercise notice" }); $("app").insertBefore(band, $("rail")); }
    if (band) { band.textContent = ""; band.hidden = !ex; if (ex) exerciseBand(ex).forEach((x) => band.appendChild(x)); }
    st.appendChild(h("span", { class: "pill " + (S.live ? "live" : ex ? "exercise" : "snap") }, h("span", { class: "dot" }), S.live ? "Live collector" : ex ? "Exercise" : "Snapshot"));
    st.appendChild(h("span", { class: "pill" }, "Data through " + utc(genTs())));
    st.appendChild(h("span", { class: "pill" }, fmt(m.posts_in_window) + " posts · " + m.window_days + " days"));
    st.appendChild(h("span", { class: "pill" }, m.model.calibrated ? "Model calibrated" : "Model: priors"));
    const f = $("foot"); f.textContent = "";
    if (ex) f.appendChild(h("span", { class: "ex-mark small" }, "EXERCISE · simulated lanes · seed " + ex.seed));
    f.appendChild(h("span", null, "PUBLIUS " + m.version + " — an independent rebuild of the Hamilton 2.0 method (Alliance for Securing Democracy, now ISD-US). Not affiliated with ASD, GMF or ISD."));
    f.appendChild(h("span", null, "Generated " + m.generated));
  }

  // ------------------------------------------------------------------ boot
  async function boot() {
    const embedded = document.getElementById("publius-snapshot");
    const hash = (location.hash || "").slice(1);
    if (embedded) {
      S.snap = JSON.parse(embedded.textContent);
      S.live = false;
    } else {
      const m = /(?:^|&)k=([^&]+)/.exec(hash);
      if (m) { S.token = decodeURIComponent(m[1]); lsSet("publius.token", S.token); try { history.replaceState(null, "", location.pathname); } catch (e) { /* ignore */ } }
      S.token = S.token || lsGet("publius.token") || "";
      S.live = true;
      $("view").appendChild(h("div", { class: "empty" }, "Loading the latest snapshot from the collector…"));
      try {
        const r = await fetch("/api/snapshot?days=7", { headers: { "x-publius-token": S.token } });
        if (r.status === 401) throw new Error("the collector needs its token: open the link printed by `python -m publius serve` (it ends in #k=…)");
        S.snap = await r.json();
      } catch (e) {
        $("view").textContent = ""; $("view").appendChild(h("div", { class: "warnbox" }, "Could not load data: " + e.message)); return;
      }
    }
    const want = /^[a-z]+$/.test(hash) ? hash : (lsGet("publius.tab") || "brief");
    S.tab = TABS.some((t) => t.id === want) ? want : "brief";
    renderStatus();
    render();
    if (S.live) setInterval(async () => {
      try { const r = await fetch("/api/snapshot?days=7", { headers: { "x-publius-token": S.token } }); if (r.ok) { S.snap = await r.json(); renderStatus(); renderTabs(); } } catch (e) { /* keep last good */ }
    }, 5 * 60 * 1000);
  }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });
  document.addEventListener("click", (e) => { if (e.target === $("drawer")) closeDrawer(); });
  document.addEventListener("DOMContentLoaded", () => { $("drawer-close").addEventListener("click", closeDrawer); boot(); });
  if (document.readyState !== "loading") { $("drawer-close").addEventListener("click", closeDrawer); boot(); }
})();
