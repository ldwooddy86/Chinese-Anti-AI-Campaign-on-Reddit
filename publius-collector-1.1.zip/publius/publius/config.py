"""Configuration: config.toml over defaults, secrets overridable from the environment, and the rails enforced at load."""
from __future__ import annotations

import copy
import os
import sys
from typing import Any

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore
    except ModuleNotFoundError:
        tomllib = None  # type: ignore

LOOPBACK = {"127.0.0.1", "localhost", "::1"}

DEFAULTS: dict[str, Any] = {
    "general": {"data_dir": "./data", "interval_minutes": 30, "keep_days": 120, "watchlists": ["hamilton_base", "aggregators"], "title": "PUBLIUS"},
    "server": {"host": "127.0.0.1", "port": 8768, "token": ""},
    "model": {"public_figure_followers": 100000, "horizon_days": 7, "watch_rr": 2.0, "watch_min_severity": 3, "alert_p3": 0.20, "alert_min_severity": 3,
              "s2_watch_rr": 5.0, "breakout_min_pickups": 3, "breakout_check_hours": [1, 6, 24, 72, 168], "breakout_max_checks_per_cycle": 40,
              "breakout_min_severity": 2, "breakout_min_rr": 1.5, "audit_rate": 0.05, "breakout_min_mainstream": 2},
    "triage": {"enabled": False, "anthropic_api_key": "", "model": "claude-sonnet-5", "max_posts_per_cycle": 40, "min_rr": 1.5},
    # ---------------------------------------------------------------- collection lanes (watchlist sources)
    "telegram_web": {"enabled": True, "pages_per_channel": 1, "max_channels_per_cycle": 200},
    "telegram": {"enabled": False, "api_id": 0, "api_hash": "", "session": "publius_user", "max_messages_per_channel": 100},
    "x": {"enabled": False, "bearer_token": "", "daily_budget_usd": 5.0, "max_results": 20, "priority": ["media", "aggregator", "gov"]},
    "youtube": {"enabled": True, "api_key": "", "use_rss": True},
    "rss": {"enabled": True},
    "bluesky": {"enabled": True, "app_password": "", "handles": [], "jetstream": False},
    "mastodon": {"enabled": True, "instances": ["mastodon.social"], "token": ""},
    "truthsocial": {"enabled": False, "token": "", "note": "Mastodon-compatible API; cloud IPs are blocked; check the platform's terms before enabling"},
    "gab": {"enabled": False, "token": "", "note": "Mastodon-derived API; same caveats as Truth Social"},
    "reddit": {"enabled": False, "client_id": "", "client_secret": "", "user_agent": "publius-collector/1.1 (read-only research)"},
    "threads": {"enabled": False, "access_token": ""},
    "meta": {"enabled": False, "access_token": "", "ig_business_id": ""},
    "tiktok": {"enabled": False, "client_key": "", "client_secret": ""},
    "vk": {"enabled": False, "service_token": ""},
    "rutube": {"enabled": True},
    "odysee": {"enabled": True},
    "gdelt": {"enabled": True, "state_domains": True, "salience": True},
    "cn_hotlist": {"enabled": True, "boards": ["baidu", "toutiao"]},
    "eitaa": {"enabled": False},
    "discord": {"enabled": False, "token": "", "channels": []},
}

SECRET_KEYS = (("server", "token"), ("triage", "anthropic_api_key"), ("telegram", "api_hash"), ("x", "bearer_token"), ("youtube", "api_key"), ("bluesky", "app_password"),
               ("mastodon", "token"), ("truthsocial", "token"), ("gab", "token"), ("reddit", "client_secret"), ("threads", "access_token"), ("meta", "access_token"),
               ("tiktok", "client_secret"), ("vk", "service_token"), ("cn_hotlist", "weibo_cookie"), ("discord", "token"))   # weibo_cookie: redacted if an old config still carries one
ENV = {"PUBLIUS_TOKEN": ("server", "token"), "ANTHROPIC_API_KEY": ("triage", "anthropic_api_key"), "X_BEARER_TOKEN": ("x", "bearer_token"),
       "YOUTUBE_API_KEY": ("youtube", "api_key"), "BLUESKY_APP_PASSWORD": ("bluesky", "app_password"), "REDDIT_CLIENT_SECRET": ("reddit", "client_secret"),
       "THREADS_ACCESS_TOKEN": ("threads", "access_token"), "META_ACCESS_TOKEN": ("meta", "access_token"), "VK_SERVICE_TOKEN": ("vk", "service_token"),
       "DISCORD_BOT_TOKEN": ("discord", "token")}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def load(path: str | None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    path = path or "config.toml"
    if os.path.exists(path):
        if tomllib is None:
            sys.exit("Python 3.11+ (tomllib) or `pip install tomli` is required to read config.toml")
        with open(path, "rb") as f:
            cfg = _merge(cfg, tomllib.load(f))
    cfg["_path"] = os.path.abspath(path)
    for env, (sect, key) in ENV.items():
        if os.environ.get(env):
            cfg[sect][key] = os.environ[env]
    if cfg["server"]["host"] not in LOOPBACK:
        sys.exit(f"server.host must be loopback (127.0.0.1 / localhost); got {cfg['server']['host']!r}. PUBLIUS never listens on a network interface.")
    base = os.path.dirname(cfg["_path"])
    dd = cfg["general"]["data_dir"]
    cfg["general"]["data_dir"] = dd if os.path.isabs(dd) else os.path.normpath(os.path.join(base, dd))
    cfg["_root"] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # login-gated boards are refused whatever the config says (an old config may still list "weibo" with a cookie)
    hl = cfg.get("cn_hotlist", {})
    if "weibo" in (hl.get("boards") or []) or hl.get("weibo_cookie"):
        print("cn_hotlist: the Weibo board is refused (its endpoint needs a logged-in cookie); reading Baidu and Toutiao only.", file=sys.stderr)
        hl["boards"] = [b for b in hl.get("boards") or [] if b != "weibo"]
        hl.pop("weibo_cookie", None)
    return cfg


def redacted(cfg: dict) -> dict:
    out = copy.deepcopy(cfg)
    for sect, key in SECRET_KEYS:
        if out.get(sect, {}).get(key):
            out[sect][key] = "•••"
    out.pop("_path", None); out.pop("_root", None)
    return out
