"""Multilingual lexicon matching in one linear pass per text.

Latin-script terms are matched on word tokens (multi-word phrases, and a trailing * as a stem on the last word), which
gives exact word boundaries without regex backtracking. Terms in other scripts (Cyrillic, Arabic/Persian, CJK) are
matched as substrings, which is what inflected Russian stems and unsegmented Chinese need. Every hit carries its
character offset so callers can scope hits to sentences."""
from __future__ import annotations

import json
import os
import re
from collections import defaultdict
from functools import lru_cache
from typing import Iterable


def _jload(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return json.load(f)


LEX_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "lexicons")
LANGS = ("en", "ru", "zh", "fa")
TOKEN = re.compile(r"#?[a-z0-9]+(?:'[a-z0-9]+)*")
LATIN = re.compile(r"^[#a-z0-9 .'’*,&/-]+$")


def _norm(s: str) -> str:
    return (s or "").lower().replace("’", "'")


class PhraseMatcher:
    """terms_by_cat: {category: [term, ...]} → spans(text) = [(category, offset, matched text)]."""

    def __init__(self, terms_by_cat: dict[str, Iterable[str]]):
        self.exact: dict[tuple, set] = defaultdict(set)          # token tuple → categories
        self.stems: dict[tuple, list] = defaultdict(list)        # (preceding tokens) → [(stem prefix, category)]
        self.sub: list[tuple[str, str]] = []                     # (substring, category) for non-Latin terms
        self.maxlen = 1
        for cat, terms in terms_by_cat.items():
            for raw in terms:
                t = _norm(raw).strip()
                if not t:
                    continue
                if not LATIN.match(t):
                    # Cyrillic and Arabic-script terms: stems anchored at a word start; a trailing '!' demands the whole word.
                    # CJK terms: plain substrings (no word boundaries in the script).
                    full = t.endswith("!")
                    core = t.rstrip("!*")
                    bounded = not re.search(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]", core)
                    self.sub.append((core, cat, full, bounded))
                    continue
                stem = t.endswith("*")
                toks = TOKEN.findall(t.rstrip("*"))
                if not toks:
                    continue
                self.maxlen = max(self.maxlen, len(toks))
                if stem:
                    self.stems[tuple(toks[:-1])].append((toks[-1], cat))
                else:
                    self.exact[tuple(toks)].add(cat)

    def spans(self, text: str) -> list[tuple[str, int, str]]:
        low = _norm(text)
        out: list[tuple[str, int, str]] = []
        toks = [(m.group(0), m.start(), m.end()) for m in TOKEN.finditer(low)]
        words = [t[0] for t in toks]
        n = len(words)
        for i in range(n):
            for L in range(1, min(self.maxlen, n - i) + 1):
                cats = self.exact.get(tuple(words[i:i + L]))
                if cats:
                    frag = low[toks[i][1]:toks[i + L - 1][2]]
                    out.extend((c, toks[i][1], frag) for c in cats)
                pre = self.stems.get(tuple(words[i:i + L - 1]))
                if pre:
                    last = words[i + L - 1]
                    for stem, c in pre:
                        if last.startswith(stem):
                            out.append((c, toks[i][1], low[toks[i][1]:toks[i + L - 1][2]]))
        for s, c, full, bounded in self.sub:
            start = low.find(s)
            while start != -1:
                end = start + len(s)
                ok = not bounded or ((start == 0 or not low[start - 1].isalpha()) and (not full or end == len(low) or not low[end].isalpha()))
                if ok:
                    out.append((c, start, s))
                start = low.find(s, end)
        return out


@lru_cache(maxsize=8)
def load(lang: str) -> dict:
    fp = os.path.join(LEX_DIR, f"{lang}.json")
    return _jload(fp) if os.path.exists(fp) else {}


class Matcher:
    """One language's lexicon: phrase matcher for the categories plus exact case-sensitive tokens (US, ICE, GOP…)."""

    def __init__(self, lang: str):
        self.lang = lang
        raw = load(lang)
        flat: dict[str, list[str]] = {}
        for k, v in raw.items():
            if k.startswith("_") or k == "case_sensitive":
                continue
            if k == "topics":
                for tk, tv in v.items():
                    flat["topic:" + tk] = tv
            else:
                flat[k] = v
        self.pm = PhraseMatcher(flat)
        self.cs: dict[str, re.Pattern] = {}
        for k, terms in (raw.get("case_sensitive") or {}).items():
            self.cs[k] = re.compile("|".join(r"(?<![A-Za-z0-9])" + re.escape(t) + r"(?![A-Za-z0-9])" for t in sorted(terms, key=len, reverse=True)))

    def spans(self, text: str) -> list[tuple[str, int, str]]:
        out = self.pm.spans(text)
        for k, rx in self.cs.items():
            out.extend((k, m.start(), m.group(0)) for m in rx.finditer(text or ""))
        return out

    def match(self, text: str) -> dict[str, list[str]]:
        res: dict[str, list[str]] = {}
        for k, _, t in self.spans(text):
            res.setdefault(k, []).append(t)
        return res


@lru_cache(maxsize=8)
def matcher(lang: str) -> Matcher:
    return Matcher(lang if lang in LANGS else "en")


# "2.05 U.S. dollars", "US$", "долларов США", "دلار آمریکا": a currency, not a US subject
CURRENCY = re.compile(r"(?i)(?<![a-z])(?:u\.?s\.?|us|american)[\s-]*(?:\$|dollars?\b|cents?\b|bucks\b)|(?<![a-z])usd(?![a-z])|"
                      r"(?:доллар\w*|долл\.)\s+(?:сша|америк\w*)|دلار\s*(?:آمریکا|امریکا|آمریکایی)")


def spans_all(text: str, lang: str) -> list[tuple[str, int, str]]:
    """English lexicon always (state outlets write for US audiences in English and native posts quote English terms),
    plus the post's own lexicon when it is Russian, Chinese or Persian. A US anchor inside a currency expression is
    dropped."""
    out = matcher("en").spans(text)
    if lang in ("ru", "zh", "fa"):
        out += matcher(lang).spans(text)
    cur = [(m.start(), m.end()) for m in CURRENCY.finditer(text or "")]
    if cur:
        out = [h for h in out if h[0] != "us_anchor" or not any(a <= h[1] < b for a, b in cur)]
    return out


def match_all(text: str, lang: str) -> dict[str, list[str]]:
    res: dict[str, list[str]] = {}
    for k, _, t in spans_all(text, lang):
        res.setdefault(k, []).append(t)
    return res
