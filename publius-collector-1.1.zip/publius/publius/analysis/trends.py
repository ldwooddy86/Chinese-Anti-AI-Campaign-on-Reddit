"""Hamilton-style aggregates (top posts, accounts, key phrases, hashtags, URLs, domains, mentions, countries) and
trend detection with the log-odds ratio under an informative Dirichlet prior (Monroe, Colaresi & Quinn 2008):

  delta_w = log[(y_a + a_w) / (n_a + a0 - y_a - a_w)] - log[(y_b + a_w) / (n_b + a0 - y_b - a_w)]
  var(delta_w) ~= 1/(y_a + a_w) + 1/(y_b + a_w),   z_w = delta_w / sqrt(var)

with a_w = a0 * (y_a + y_b)/(n_a + n_b). The z-score shrinks rare terms toward zero, so 'trending' means a term the
current window over-uses relative to the baseline beyond what chance would produce, not merely a big ratio of small counts."""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from typing import Iterable

from .gazetteer import countries_in

STOP = set("""a about above after again against all am an and any are aren't as at be because been before being below between both but by can can't cannot could
couldn't did didn't do does doesn't doing don't down during each few for from further had hadn't has hasn't have haven't having he he'd he'll he's her here here's
hers herself him himself his how how's i i'd i'll i'm i've if in into is isn't it it's its itself let's me more most mustn't my myself no nor not of off on once only
or other ought our ours ourselves out over own same shan't she she'd she'll she's should shouldn't so some such than that that's the their theirs them themselves
then there there's these they they'd they'll they're they've this those through to too under until up very was wasn't we we'd we'll we're we've were weren't what
what's when when's where where's which while who who's whom why why's with won't would wouldn't you you'd you'll you're you've your yours yourself yourselves
said says say also new news via just like one two three first last year years day days week today yesterday tomorrow time will may might us amp rt read more
video photo live watch follow subscribe join channel telegram link full story report reports according told per latest update breaking""".split())
PROPER = re.compile(r"\b([A-Z][a-zA-Z'’.-]+(?:\s+(?:of|the|and|al|bin|de|van|von)?\s*[A-Z][a-zA-Z'’.-]+){0,3})\b")
WORD = re.compile(r"[a-z][a-z'-]{3,}")


def key_phrases(text: str) -> list[str]:
    """Proper-noun sequences plus salient content bigrams (English). Mirrors Hamilton's key-phrase idea without a cloud NLP call."""
    t = re.sub(r"https?://\S+|[@#]\w+", " ", text or "")
    out = []
    for m in PROPER.finditer(t):
        ph = m.group(1).strip(" .'’-")
        words = ph.split()
        if len(ph) < 3 or (len(words) == 1 and words[0].lower() in STOP):
            continue
        if words[0].lower() in STOP:
            ph = " ".join(words[1:])
        if ph and ph.lower() not in STOP:
            out.append(ph)
    low = WORD.findall(t.lower())
    content = [w for w in low if w not in STOP]
    proper_low = " | ".join(p.lower() for p in out)
    out.extend(bg for bg in (f"{a} {b}" for a, b in zip(content, content[1:])) if bg not in proper_low)
    return out


def _engagement(p: dict) -> float:
    m = p.get("metrics") or {}
    return float(m.get("views") or 0) * 0.01 + float(m.get("likes") or 0) + 2 * float(m.get("shares") or 0) + float(m.get("replies") or 0)


def hamilton_panels(posts: list[dict], top: int = 25) -> dict:
    phrases, tags, urls, doms, ments, ctry = Counter(), Counter(), Counter(), Counter(), Counter(), Counter()
    acc = defaultdict(lambda: {"posts": 0, "engagement": 0.0})
    for p in posts:
        text = (p.get("title") or "") + "\n" + (p.get("text") or "")
        if (p.get("lang") or "en") == "en":
            for k in set(key_phrases(text)):
                phrases[k] += 1
        for h in p.get("hashtags") or []:
            tags["#" + h] += 1
        for u in p.get("urls") or []:
            if "t.me/" not in u:
                urls[u] += 1
        for d in p.get("domains") or []:
            if d != "t.me":
                doms[d] += 1
        for m in p.get("mentions") or []:
            ments["@" + m] += 1
        for c in (p.get("features") or {}).get("countries") or countries_in(text):
            ctry[c] += 1
        a = acc[p["source_id"]]
        a["posts"] += 1; a["engagement"] += _engagement(p)
        a.update({"name": p.get("s_name") or p.get("source_id"), "platform": p.get("platform"), "country": p.get("country"), "category": p.get("category"), "followers": p.get("s_followers")})
    top_posts = sorted(posts, key=_engagement, reverse=True)[:top]
    return {"key_phrases": phrases.most_common(top), "hashtags": tags.most_common(top), "urls": urls.most_common(top), "domains": doms.most_common(top),
            "mentions": ments.most_common(top), "countries": ctry.most_common(top),
            "top_accounts": sorted(({"source_id": k, **v} for k, v in acc.items()), key=lambda d: (-d["posts"], -d["engagement"]))[:top],
            "top_posts": [p["id"] for p in top_posts]}


def _terms(posts: Iterable[dict]) -> Counter:
    c = Counter()
    for p in posts:
        text = (p.get("title") or "") + "\n" + (p.get("text") or "")
        if (p.get("lang") or "en") != "en":
            continue
        terms = set(key_phrases(text))
        terms.update("#" + h for h in (p.get("hashtags") or []))
        c.update(terms)
    return c


def fightin_words(current: Iterable[dict], baseline: Iterable[dict], a0: float = 500.0, min_count: int = 3, top: int = 30) -> list[dict]:
    ya, yb = _terms(current), _terms(baseline)
    na, nb = sum(ya.values()), sum(yb.values())
    if na == 0:
        return []
    tot = na + nb
    out = []
    for w in set(ya) | set(yb):
        a, b = ya.get(w, 0), yb.get(w, 0)
        if a + b < min_count:
            continue
        aw = a0 * (a + b) / tot
        d = math.log((a + aw) / (na + a0 - a - aw)) - math.log((b + aw) / (nb + a0 - b - aw)) if nb > 0 else math.log((a + aw) / (na + a0 - a - aw))
        var = 1.0 / (a + aw) + 1.0 / (b + aw)
        out.append({"term": w, "z": round(d / math.sqrt(var), 3), "current": a, "baseline": b})
    out.sort(key=lambda r: -r["z"])
    return out[:top]


def distinctive_by_country(posts: list[dict], top: int = 15) -> dict:
    by = defaultdict(list)
    for p in posts:
        by[p.get("country") or "?"].append(p)
    out = {}
    for cc, ps in by.items():
        rest = [p for p in posts if (p.get("country") or "?") != cc]
        out[cc] = fightin_words(ps, rest, top=top)
    return out


def narrative_matrix(posts: list[dict], days: list[str]) -> dict:
    """{narrative: {country: {day: n}}} plus a convergence count per narrative/day (countries above their own mean)."""
    import time as _t
    m: dict = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    for p in posts:
        d = _t.strftime("%Y-%m-%d", _t.gmtime(p["ts"]))
        for n in p.get("narratives") or []:
            m[n][p.get("country") or "?"][d] += 1
    conv = {}
    for n, byc in m.items():
        conv[n] = {}
        means = {c: (sum(v.values()) / max(1, len(days))) for c, v in byc.items()}
        for d in days:
            conv[n][d] = sum(1 for c, v in byc.items() if c in ("RU", "CN", "IR") and v.get(d, 0) > max(1.0, means[c]))
    return {"counts": {n: {c: dict(v) for c, v in byc.items()} for n, byc in m.items()}, "convergence": conv}
