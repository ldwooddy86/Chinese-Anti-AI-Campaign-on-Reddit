"""PUBLIUS command line.

  python -m publius init                 write config.toml (+ token), import the watchlists, seed verification status
  python -m publius verify [--platform telegram|rss|youtube] [--limit N]   live-check watchlist handles
  python -m publius collect [--lanes a,b]   one collection pass
  python -m publius analyse              features, coordination, scoring for the last 10 days
  python -m publius breakout             due breakout checks + auto-labels
  python -m publius triage               optional Claude second opinion on the top of the queue
  python -m publius cycle                collect → analyse → breakout (→ analyse)
  python -m publius run                  cycle every general.interval_minutes and serve the dashboard
  python -m publius serve                dashboard + API only
  python -m publius label <post_id> <level 1-6> [--note ...]
  python -m publius calibrate [--dry-run]
  python -m publius export --out DIR [--days 7]
  python -m publius exercise --out DIR [--seed N] [--opinions FILE]   simulated US lanes on a COPY of the store: a fully featured preview
  python -m publius ghostloom --out FILE [--days 7] [--from SNAPSHOT.json|EXPORT.html]   the pack GHOST LOOM's PUBLIUS tab loads
  python -m publius status | platforms | lanes
  python -m publius login telegram       one-time Telethon login (for channels without public previews)
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import sys
import time

from . import __version__
from .config import load, redacted
from .store import Store
from .util import gen_token, iso

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _cfg_store(args) -> tuple[dict, Store]:
    cfg = load(args.config)
    return cfg, Store(cfg["general"]["data_dir"])


def cmd_init(args) -> int:
    path = args.config or "config.toml"
    if not os.path.exists(path):
        shutil.copy(os.path.join(ROOT, "config.example.toml"), path)
        tok = gen_token()
        txt = open(path, encoding="utf-8").read().replace('token = ""  # set by init', f'token = "{tok}"  # set by init')
        open(path, "w", encoding="utf-8").write(txt)
        print(f"wrote {path}")
    cfg, st = _cfg_store(args)
    from .watchlist import import_watchlists
    r = import_watchlists(st, ROOT, cfg["general"]["watchlists"])
    print(json.dumps(r, indent=1))
    print(f"\nDashboard: python -m publius serve  →  http://127.0.0.1:{cfg['server']['port']}/#k={cfg['server']['token']}")
    return 0


def cmd_verify(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import lanes
    ls = lanes(cfg, st)
    plats = [args.platform] if args.platform else ["telegram", "rss", "youtube"]
    for plat in plats:
        c = ls[plat]
        srcs = st.sources(platform=plat)[: args.limit or None]
        print(f"verifying {len(srcs)} {plat} sources…", flush=True)
        res = c.verify(srcs)
        from collections import Counter
        print(plat, dict(Counter(r["status"] for r in res)))
    return 0


def cmd_collect(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import collect
    print(json.dumps(collect(cfg, st, args.lanes.split(",") if args.lanes else None), indent=1))
    return 0


def cmd_analyse(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import analyse
    print(json.dumps(analyse(cfg, st, window_days=args.days), indent=1))
    return 0


def cmd_breakout(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import breakout_cycle
    print(json.dumps(breakout_cycle(cfg, st), indent=1))
    return 0


def cmd_triage(args) -> int:
    cfg, st = _cfg_store(args)
    from .triage import run
    print(json.dumps(run(cfg, st), indent=1))
    return 0


def cmd_cycle(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import cycle
    print(json.dumps(cycle(cfg, st), indent=1, default=str))
    return 0


def _serve(cfg, st):
    from .server import Server
    srv = Server(cfg, st)
    srv.start()
    tok = cfg["server"]["token"]
    print(f"PUBLIUS {__version__} — dashboard at {srv.url}#k={tok}  (loopback only; Ctrl-C to stop)", flush=True)
    if srv.generated_token:
        print("  server.token was empty, so a token was generated for this session; run `python -m publius init` or set PUBLIUS_TOKEN to keep one.", flush=True)
    return srv


def cmd_exercise(args) -> int:
    """Run a copy of the store through simulated US lanes and export a fully featured, clearly marked preview."""
    cfg, _ = _cfg_store(args)
    from .exercise import run
    from .export import static_html
    from .pipeline import snapshot
    res = run(cfg, args.out, seed=args.seed, opinions=args.opinions)
    cfg2 = dict(cfg, general=dict(cfg["general"], data_dir=res["data_dir"]))
    snap = snapshot(cfg2, Store(res["data_dir"]), days=args.days)
    path = os.path.join(args.out, "publius-exercise.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(static_html(snap, title="PUBLIUS Exercise"))
    from .analysis.ghostloom import write_pack
    pack = write_pack(snap, os.path.join(args.out, "ghostloom-pack.json"))     # simulated inputs are left out of the pack
    print(json.dumps({"html": path, "ghostloom_pack": pack["path"], "store_copy": res["data_dir"], "calibration": res["calibration"], "counts": res["exercise"]["counts"]}, indent=1, default=str))
    return 0


def cmd_serve(args) -> int:
    cfg, st = _cfg_store(args)
    srv = _serve(cfg, st)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        srv.stop()
    return 0


def cmd_run(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import cycle
    srv = _serve(cfg, st)
    every = max(5, int(cfg["general"].get("interval_minutes", 30))) * 60
    try:
        while True:
            t0 = time.time()
            try:
                out = cycle(cfg, st)
                n = sum(v.get("items", 0) for v in out["collect"].values() if isinstance(v, dict))
                print(f"[{iso(int(time.time()))}] cycle: {n} new posts, flags {out['analyse'].get('flags')}, breakout checks {out['breakout'].get('checked')}", flush=True)
                if cfg.get("triage", {}).get("enabled"):
                    from .triage import run as triage_run
                    triage_run(cfg, st)
                st.prune(int(cfg["general"].get("keep_days", 120)))
            except Exception as e:
                logging.exception("cycle failed: %s", e)
            time.sleep(max(30, every - (time.time() - t0)))
    except KeyboardInterrupt:
        srv.stop()
    return 0


def cmd_label(args) -> int:
    cfg, st = _cfg_store(args)
    if not st.post(args.post_id):
        print("no such post"); return 1
    st.set_label(args.post_id, args.level, "analyst", args.note or "")
    print("labelled"); return 0


def cmd_calibrate(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import calibrate
    res = calibrate(cfg, st, activate=not args.dry_run)
    res.pop("params", None)
    print(json.dumps(res, indent=1, default=str))
    return 0


def cmd_export(args) -> int:
    cfg, st = _cfg_store(args)
    from .export import write
    from .pipeline import snapshot
    print(json.dumps(write(snapshot(cfg, st, days=args.days), args.out, html=not args.json_only), indent=1))
    return 0


def load_snapshot(path: str) -> dict:
    """A snapshot JSON, or the snapshot embedded in an exported dashboard (publius-dashboard.html, publius-exercise.html)."""
    with open(path, encoding="utf-8") as f:
        raw = f.read()
    if path.lower().endswith((".html", ".htm")):
        import re
        m = re.search(r'<script type="application/json" id="publius-snapshot">(.*?)</script>', raw, re.S)
        if not m:
            raise SystemExit(f"{path}: no embedded PUBLIUS snapshot")
        raw = m.group(1)
    return json.loads(raw)


def cmd_ghostloom(args) -> int:
    """Write the GHOST LOOM pack: counts and AI-seam items coded over the window, with nothing simulated in it."""
    from .analysis.ghostloom import write_pack
    if args.from_path:
        snap = load_snapshot(args.from_path)
    else:
        cfg, st = _cfg_store(args)
        from .pipeline import snapshot
        snap = snapshot(cfg, st, days=args.days)
    print(json.dumps(write_pack(snap, args.out), indent=1))
    return 0


def cmd_status(args) -> int:
    cfg, st = _cfg_store(args)
    from .pipeline import lane_status
    print(json.dumps({"version": __version__, "counts": st.counts(), "lanes": lane_status(cfg, st), "config": redacted(cfg)}, indent=1, default=str))
    return 0


def cmd_platforms(args) -> int:
    d = json.load(open(os.path.join(ROOT, "publius", "data", "platforms.json"), encoding="utf-8"))
    for p in d["platforms"]:
        reach = f"{p['us_reach'] * 100:.0f}%" if isinstance(p.get("us_reach"), (int, float)) else "n/a"
        print(f"{p['name'][:34]:34} reach {reach:>5}  role {p['role']:10} access {p['access']:9} connector {p['connector'] or '—'}")
    return 0


def cmd_login(args) -> int:
    cfg, st = _cfg_store(args)
    if args.service != "telegram":
        print("only 'telegram' needs an interactive login"); return 1
    import asyncio
    from .connectors.gated import TelegramUser
    asyncio.run(TelegramUser({}, cfg, st).login())
    print("Telegram session saved in", cfg["general"]["data_dir"])
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="publius", description="PUBLIUS — foreign state messaging monitor with a US domestic-unrest breakout model")
    ap.add_argument("--config", default=None)
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    v = sub.add_parser("verify"); v.add_argument("--platform"); v.add_argument("--limit", type=int, default=0)
    c = sub.add_parser("collect"); c.add_argument("--lanes")
    a = sub.add_parser("analyse"); a.add_argument("--days", type=int, default=10)
    sub.add_parser("breakout"); sub.add_parser("triage"); sub.add_parser("cycle"); sub.add_parser("run"); sub.add_parser("serve")
    lb = sub.add_parser("label"); lb.add_argument("post_id"); lb.add_argument("level", type=int, choices=range(1, 7)); lb.add_argument("--note")
    ca = sub.add_parser("calibrate"); ca.add_argument("--dry-run", action="store_true")
    e = sub.add_parser("export"); e.add_argument("--out", default="exports"); e.add_argument("--days", type=int, default=7); e.add_argument("--json-only", action="store_true")
    ex = sub.add_parser("exercise"); ex.add_argument("--out", default="exercise"); ex.add_argument("--days", type=int, default=7); ex.add_argument("--seed", type=int, default=20260924)
    ex.add_argument("--opinions", default=None, help="JSON file of second opinions to record, as the triage pass would")
    gp = sub.add_parser("ghostloom"); gp.add_argument("--out", default="ghostloom-pack.json"); gp.add_argument("--days", type=int, default=7)
    gp.add_argument("--from", dest="from_path", default=None, help="build from a snapshot JSON or an exported dashboard instead of the store")
    sub.add_parser("status"); sub.add_parser("platforms")
    lg = sub.add_parser("login"); lg.add_argument("service")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    return {"init": cmd_init, "verify": cmd_verify, "collect": cmd_collect, "analyse": cmd_analyse, "breakout": cmd_breakout, "triage": cmd_triage, "cycle": cmd_cycle,
            "run": cmd_run, "serve": cmd_serve, "label": cmd_label, "calibrate": cmd_calibrate, "export": cmd_export, "exercise": cmd_exercise, "ghostloom": cmd_ghostloom, "status": cmd_status, "platforms": cmd_platforms,
            "login": cmd_login}[args.cmd](args)
