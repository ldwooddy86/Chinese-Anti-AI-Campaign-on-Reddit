"""Exercise mode: every downstream feature, working, before the keys and the calendar allow it.

A COPY of the store is run through simulated US-audience lanes; the real store is never written. Nothing is collected
and no post is invented: the posts, sources, features, severity, narratives, coordination, flashpoints and the analyst
brief are the real collection. What is simulated, and marked on every screen that shows it:

  * the counts each US lane returns when a post is checked, drawn from a documented data-generating process (the
    "simulation truth", which departs from the analyst priors on purpose so calibration has something to find), plus a
    handful of scripted injects so every level of the Breakout Scale appears
  * the covert-operation indicator counts in those lanes, and the lane statuses
  * the auto-labels that follow at the 7-day horizon, and a DRY-RUN calibration on them (the active model stays the prior)

Checks are projected through each post's full 7-day horizon, so check times run past the collection date. Scores and
flags use only what had been observed by the snapshot time; the rest is shown as projected. First scoring is placed
within 30 minutes of publication, as a collector running every 30 minutes would have done. No account is ever named:
a simulated public figure is a numbered placeholder.

  python -m publius exercise --out DIR [--seed N] [--opinions FILE]
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import math
import os
import random
import sqlite3
import time
from collections import Counter
from typing import Optional

from . import pipeline, util
from . import store as store_mod
from .analysis import breakout as bo
from .analysis.model import LEVELS, Model, logit
from .connectors.base import SearchResult
from .store import Store

# lane, label, share of pickups (roughly US-reach weighted), what the real lane needs
SOCIAL = [("x", "X", 0.24, "X API bearer token (pay-per-use)"), ("reddit", "Reddit", 0.18, "Reddit OAuth app"),
          ("bluesky", "Bluesky", 0.14, "Bluesky app password"), ("threads", "Threads", 0.10, "threads_keyword_search permission"),
          ("youtube", "YouTube search", 0.10, "YouTube Data API key"), ("tiktok", "TikTok Research API", 0.09, "Research API approval"),
          ("truthsocial", "Truth Social", 0.06, "token; off by default in the real config"), ("mastodon", "Mastodon", 0.05, "instance token"),
          ("gab", "Gab", 0.04, "token; off by default in the real config")]
MAINSTREAM = ("gdelt", "GDELT (US news)", "keyless in real use; simulated here so level 4 follows the same draw")

# Simulation truth. Terms not listed keep the prior mean. Breakout is made more common than the analysts assumed, and the
# flashpoint and echo terms stronger, so a successful calibration should move those estimates towards these values.
TRUE_BETA = {"flashpoint": 0.95, "platform_reach": 0.35, "echo": 0.80, "velocity_z": 0.55, "lang_en": 1.20, "us_domestic": 0.80, "log_followers": 0.30}
TRUE_BASE_RATES = {2: 0.25, 3: 0.10, 4: 0.03, 5: 0.01, 6: 0.002}
# level, minimum rule severity of the target, platforms carrying it, hour a public figure appears, scenario
INJECT_PLAN = [(6, 3, 4, 24, "scripted: fast pickup on four platforms, US news coverage, a public figure at 24 h, then violent or mobilising replies"),
               (5, 2, 3, 6, "scripted: pickups on three platforms, then a public figure at 6 h"),
               (4, 2, 2, None, "scripted: pickups on two platforms and US news coverage within 72 h"),
               (3, 1, 2, None, "scripted: pickups on two platforms within a day"),
               (2, 1, 1, None, "scripted: pickup on one platform only")]


class Clock:
    def __init__(self):
        self.t: Optional[int] = None

    def __call__(self) -> int:
        return int(self.t) if self.t is not None else int(time.time())


@contextlib.contextmanager
def simulated_clock(clock: Clock):
    mods = (util, store_mod, bo, pipeline)
    saved = [(m, m.now) for m in mods]
    for m, _ in saved:
        m.now = clock
    try:
        yield clock
    finally:
        for m, f in saved:
            m.now = f


def _rng(seed: int, *parts) -> random.Random:
    return random.Random(int(hashlib.sha1(("|".join(map(str, (seed,) + parts))).encode()).hexdigest()[:12], 16))


def _poisson(rng: random.Random, lam: float) -> int:
    k, p, l = 0, 1.0, math.exp(-lam)
    while True:
        p *= rng.random()
        if p <= l:
            return k
        k += 1


def truth_model() -> Model:
    prior = Model()
    return Model({"version": "exercise-truth", "beta": {k: TRUE_BETA.get(k, prior.beta[k]) for k in prior.names},
                  "beta_sd": {k: 1e-6 for k in prior.names}, "theta": {str(k): -logit(TRUE_BASE_RATES[k]) for k in LEVELS},
                  "theta_sd": {str(k): 1e-6 for k in LEVELS}})


def draw_level(model: Model, x: dict, rng: random.Random) -> int:
    lv = model.predict(x)["levels"]
    u, level = rng.random(), 1
    for k in LEVELS:
        if u < lv[k]["p"]:
            level = k
    return level


class Engine:
    """Holds each checked post's simulated pickup series and answers lane searches from them."""

    def __init__(self, seed: int, clock: Clock, k: int = 3):
        self.seed, self.clock, self.k = seed, clock, k
        self.series: dict[str, dict] = {}
        self.ts: dict[str, int] = {}
        self.index: dict[tuple, str] = {}
        self.searches: Counter = Counter()
        self.figures = 0

    def plan(self, post: dict, level: int, carry_n: Optional[int] = None, pf_h: Optional[int] = None, fast: bool = False) -> None:
        pid, rng, k = post["id"], _rng(self.seed, "series", post["id"]), self.k
        names, weights = [s[0] for s in SOCIAL], [s[2] for s in SOCIAL]
        n_carry = carry_n if carry_n is not None else 0 if level <= 1 else 1 if level == 2 else min(6, 2 + _poisson(rng, 0.8))
        carry, pool, wts = [], list(names), list(weights)
        while len(carry) < n_carry:
            pick = rng.choices(range(len(pool)), weights=wts)[0]
            carry.append(pool.pop(pick)); wts.pop(pick)
        lanes = {}
        for lane in names:
            if lane in carry:
                final = k + int(rng.expovariate(1.0 / (5 + 12 * max(0, level - 2))))
                reach = int(math.exp(rng.gauss(math.log(9000), 1.1)))
            else:
                final = min(k - 1, _poisson(rng, 0.45))
                reach = int(math.exp(rng.gauss(math.log(1500), 1.0))) if final else None
            tau = math.exp(rng.gauss(math.log(3.0 if fast else 10.0), 0.4 if fast else 0.6))
            lanes[lane] = {"final": final, "tau": tau, "reach": min(reach, 99_000) if reach else None, "pf": [], "pf_h": None, "vm": 0}
        lanes["gdelt"] = {"final": (2 + _poisson(rng, 2.0)) if level >= 4 else (1 if rng.random() < 0.12 else 0), "tau": math.exp(rng.gauss(math.log(30.0), 0.4)),
                          "reach": None, "pf": [], "pf_h": None, "vm": 0}
        if level >= 5 and carry:
            self.figures += 1
            lane = carry[0]
            lanes[lane].update(pf=[f"public figure #{self.figures} (sim)"], pf_h=pf_h or rng.choice([6, 24, 72]), reach=int(math.exp(rng.gauss(math.log(400_000), 0.8))) + 100_000)
        if level >= 6 and carry:
            total = k + 2 + _poisson(rng, 4.0)
            for i in range(total):
                lanes[carry[i % len(carry)]]["vm"] += 1
            for lane in carry:                        # violent or mobilising replies build after the item has spread
                lanes[lane]["vm_h"] = (pf_h or 12) + 6
        self.series[pid] = {"level": level, "lanes": lanes, "carry": carry}
        self.ts[pid] = int(post["ts"])
        for kind, q in bo.queries_for(post):
            self.index[(kind, q, int(post["ts"]))] = pid

    def _at(self, spec: dict, key: str, t_h: float) -> int:
        final = spec[key] if key != "count" else spec["final"]
        if t_h >= 168:
            return int(final)
        start = spec.get("vm_h", 0) if key == "vm" else 0
        return int(round(final * (1.0 - math.exp(-max(0.0, t_h - start) / spec["tau"]))))

    def observe(self, pid: str, lane: str) -> SearchResult:
        spec = self.series[pid]["lanes"][lane]
        t_h = (self.clock() - self.ts[pid]) / 3600.0
        count = self._at(spec, "count", t_h)
        pf = spec["pf"] if spec["pf"] and t_h >= spec["pf_h"] else []
        return SearchResult(lane, count=count, reach_max=(spec["reach"] if count else None), public_figures=list(pf),
                            violent_or_mobilising=self._at(spec, "vm", t_h), note="simulated")

    def indicator(self, lane: str, kind: str, query: str) -> SearchResult:
        rng = _rng(self.seed, "indicator", lane, query)
        base = {"x": 60, "bluesky": 8, "reddit": 5, "threads": 4, "tiktok": 6, "youtube": 2, "truthsocial": 9, "mastodon": 1, "gab": 4, "gdelt": 1}.get(lane, 2)
        return SearchResult(lane, count=_poisson(rng, base * (1.6 if kind == "hashtag" else 0.6)), note="simulated")


class SimLane:
    breakout_lane = True

    def __init__(self, lane: str, label: str, engine: Engine):
        self.platform, self.label, self.engine = lane, label + " (simulated)", engine

    def enabled(self) -> bool:
        return True

    def ready(self) -> tuple[bool, str]:
        return True, "simulated"

    def search_ready(self) -> tuple[bool, str]:
        return True, "simulated"

    def search(self, query: str, kind: str = "url", since: Optional[int] = None, source_handle: Optional[str] = None) -> SearchResult:
        if self.platform == "gdelt" and kind != "phrase":
            return SearchResult("gdelt", ok=False, note="GDELT matches article text: phrase queries only")
        self.engine.searches[self.platform] += 1
        pid = self.engine.index.get((kind, query, int(since or 0)))
        if pid is None:
            return self.engine.indicator(self.platform, kind, query)
        return self.engine.observe(pid, self.platform)


def _copy_db(src: str, dst: str) -> None:
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(dst + ext):
            os.remove(dst + ext)
    a, b = sqlite3.connect(src), sqlite3.connect(dst)
    with b:
        a.backup(b)
    a.close(); b.close()


def _state(obs: list[dict], cfg: dict, social: set) -> dict:
    """Breakout state from a list of observations (what run_checks would hold after them)."""
    lanes: dict[str, dict] = {}
    for o in obs:
        cur = lanes.setdefault(o["lane"], {"count": 0, "public_figures": [], "violent_or_mobilising": 0})
        cur["count"] = max(cur["count"], int(o["count"] or 0))
        cur["public_figures"] = sorted(set(cur["public_figures"]) | set(o.get("public_figures") or []))
        cur["violent_or_mobilising"] = max(cur["violent_or_mobilising"], int(o.get("violent_or_mobilising") or 0))
    L, why = bo.level(lanes, cfg)
    live = sorted({o["lane"] for o in obs if o["lane"] in social})
    return {"level": L, "lanes": lanes, "why": why, "checks": len({o["ts"] for o in obs}), "last_check": max((o["ts"] for o in obs), default=None),
            "lanes_live": live, "measurable": len(live) >= 2}


def pick_injects(posts: list[dict], real_now: int) -> list[tuple[dict, tuple]]:
    """Deterministic inject targets: measured English posts from verified sources with a phrase the news lane can match,
    at least two hours old so the first check has happened by the snapshot; most severe first."""
    pool = [p for p in posts if ((p.get("features") or {}).get("sel") or {}).get("selected") and not pipeline._unverified(p)
            and real_now - int(p["ts"]) >= 2 * 3600 and p.get("lang") == "en" and any(k == "phrase" for k, _ in bo.queries_for(p))]
    pool.sort(key=lambda p: (-(p.get("severity") or 0), -(p.get("rr") or 0), p["id"]))
    out, used, texts = [], set(), set()
    key = lambda p: " ".join(((p.get("title") or "") + " " + (p.get("text") or "")).split())[:80].lower()
    for plan in INJECT_PLAN:
        ok = [p for p in pool if p["id"] not in used and key(p) not in texts]      # one inject per story, not per mirror of it
        cand = next((p for p in ok if (p.get("severity") or 0) >= plan[1]), None) or (ok[0] if ok else None)
        if cand:
            used.add(cand["id"]); texts.add(key(cand)); out.append((cand, plan))
    return out


def apply_opinions(store: Store, path: str) -> dict:
    """Second opinions from a JSON file ([{id, severity, rationale, ...}]), recorded exactly as the triage pass records them."""
    with open(path, encoding="utf-8") as f:
        arr = json.load(f)
    meta = arr.get("_meta", {}) if isinstance(arr, dict) else {}
    items = arr.get("opinions", []) if isinstance(arr, dict) else arr
    n = dis = 0
    for o in items:
        p = store.post(str(o.get("id")))
        if not p:
            continue
        sev = max(0, min(4, int(o["severity"])))
        rec = {"severity": sev, "us_domestic": bool(o.get("us_domestic")), "narrative": str(o.get("narrative", ""))[:80], "cta": o.get("call_to_action") or {},
               "targets_group": bool(o.get("targets_group")), "rationale": str(o.get("rationale", ""))[:300], "model": meta.get("model", o.get("model", "")),
               "rule_severity": p.get("severity"), "disagreement": abs(sev - int(p.get("severity") or 0)) >= 2}
        store.update_analysis(p["id"], llm=rec)
        n += 1; dis += 1 if rec["disagreement"] else 0
    return {"opinions": n, "disagreements": dis, "by": meta.get("model", "")}


def run(cfg: dict, out_dir: str, seed: int = 20260924, opinions: Optional[str] = None, log=print) -> dict:
    src_db = os.path.join(cfg["general"]["data_dir"], "publius.sqlite")
    data_dir = os.path.join(os.path.abspath(out_dir), "data")
    _copy_db(src_db, os.path.join(data_dir, "publius.sqlite"))
    cfg = json.loads(json.dumps({k: v for k, v in cfg.items() if not k.startswith("_")}))
    cfg["general"]["data_dir"] = data_dir
    st = Store(data_dir)
    real_now = util.now()
    k = int(cfg["model"].get("breakout_min_pickups", 3))
    horizon = int(cfg["model"].get("horizon_days", 7)) * 86400

    log("exercise: real brief and flags (before any simulated input)")
    real_snap = pipeline.snapshot(cfg, st)
    st.kv_set("exercise_brief", json.dumps(real_snap["brief"], ensure_ascii=False))
    flags_real = dict(Counter((p.get("flag") or "none") for p in real_snap["posts"].values()))
    st.kv_set("exercise", "null")
    st.kv_set("last_calibration", "null")
    with st.conn() as c:                              # the copy starts with no outcome data: the exercise measures everything itself
        c.execute("UPDATE posts SET breakout=NULL, breakout_level=NULL, breakout_ts=NULL")
        c.execute("DELETE FROM breakout_obs"); c.execute("DELETE FROM indicator_obs"); c.execute("DELETE FROM labels WHERE source='auto'")

    posts = st.posts(since=real_now - 10 * 86400, limit=100000)
    with st.bulk():                                   # first scoring within one 30-minute cycle of publication
        for p in posts:
            f = dict(p.get("features") or {})
            if not f.get("x_t0"):
                continue
            t0 = int(p["ts"]) + _rng(seed, "t0", p["id"]).randint(300, 1800)
            f.update(t0_ts=t0, t0_lag_h=round((t0 - int(p["ts"])) / 3600.0, 2))
            st.update_analysis(p["id"], features=f)
    posts = st.posts(since=real_now - 10 * 86400, limit=100000)
    selected = [p for p in posts if ((p.get("features") or {}).get("sel") or {}).get("selected")]
    clock = Clock()
    truth = truth_model()
    injects = pick_injects(posts, real_now)
    inj = {p["id"]: plan for p, plan in injects}
    # One draw per measured post. A calibration needs >= 10 posts at level 3+, so the first seed (from the one asked for)
    # whose draw clears that with a margin is used, and both seeds are reported.
    seed_asked, need = seed, min(14, max(1, len(selected) // 20))
    for seed in range(seed_asked, seed_asked + 200):
        draws = {p["id"]: draw_level(truth, p["features"]["x_t0"], _rng(seed, "level", p["id"])) for p in selected if p["id"] not in inj}
        if sum(1 for v in draws.values() if v >= 3) + sum(1 for plan in inj.values() if plan[0] >= 3) >= need:
            break
    eng = Engine(seed, clock, k)
    for p in selected:
        if p["id"] in inj:
            lv, _, carry_n, pf_h, _ = inj[p["id"]]
            eng.plan(p, lv, carry_n=carry_n, pf_h=pf_h, fast=True)
        else:
            eng.plan(p, draws[p["id"]])
    lanes = {s[0]: SimLane(s[0], s[1], eng) for s in SOCIAL}
    lanes["gdelt"] = SimLane(MAINSTREAM[0], MAINSTREAM[1], eng)
    social = {s[0] for s in SOCIAL}
    t_start = min(int(p["ts"]) for p in selected) + 3600
    t_end = max(int(p["ts"]) for p in selected) + 168 * 3600 + 3600
    log(f"exercise: {len(selected)} measured posts, {len(injects)} injects; simulating checks {util.iso(t_start)} → {util.iso(t_end)}")
    with simulated_clock(clock):
        t, sweeps = t_start, 0
        while t <= t_end:
            clock.t = t
            bo.run_checks(st, lanes, cfg, max_checks=100000)
            if t <= real_now and (t - t_start) % (6 * 3600) < 3600:
                sweeps += pipeline.indicator_sweep(st, lanes)
            t += 3600
        clock.t = t_end
        auto = bo.auto_label(st, cfg)
        # Simulated outcomes are independent draws, so no outcome window overlaps the next and the backtest needs no
        # purge gap; a live calibration purges one full horizon (7 days) between training and test posts.
        cal = pipeline.calibrate(cfg, st, activate=False, purge_s=0)
    log(f"exercise: auto-labels {auto}; calibration {cal.get('status')} (n={cal.get('n')}, B>=3: {cal.get('positives_b3')})")

    # back to the real clock: scores and flags see only what had been observed by now; the rest is kept as projected
    so_far_checks = 0
    with st.bulk():
        for p in selected:
            obs = st.breakout_obs(p["id"])
            if not obs:
                continue
            final, now_part = _state(obs, cfg, social), [o for o in obs if o["ts"] <= real_now]
            cur = _state(now_part, cfg, social) if now_part else {"level": None, "lanes": {}, "why": {}, "checks": 0, "last_check": None, "lanes_live": [], "measurable": False}
            so_far_checks += cur["checks"]
            b = {**cur, "simulated": True, "projected": {"level": final["level"], "why": final["why"], "checks": final["checks"], "last_check": final["last_check"]}}
            if p["id"] in inj:
                b["inject"] = inj[p["id"]][4]
            st.update_analysis(p["id"], breakout=b, breakout_level=cur["level"], breakout_ts=cur["last_check"])
    x_days = Counter(util.day(o["ts"]) for p in selected for o in st.breakout_obs(p["id"]) if o["lane"] == "x" and o["ts"] <= real_now)
    for d, n in sorted(x_days.items()):              # one recent-counts call per X check, $0.005 each, on the day it was made
        st.add_spend(d, "x", round(0.005 * n, 3), n)
    op = apply_opinions(st, opinions) if opinions else {"opinions": 0}
    pipeline.analyse(cfg, st)
    labels = st.labels()
    flags_ex = Counter(p.get("flag") or "none" for p in st.posts(since=real_now - 7 * 86400, limit=100000))
    prior = Model()
    exercise = {
        "seed": seed, "seed_asked": seed_asked, "generated": util.iso(real_now),
        "lanes": [{"lane": s[0], "label": s[1], "needs": s[3]} for s in SOCIAL] + [{"lane": MAINSTREAM[0], "label": MAINSTREAM[1], "needs": MAINSTREAM[2]}],
        "truth": {"beta": {n: truth.beta[n] for n in truth.names}, "base_rates": {str(k2): v for k2, v in TRUE_BASE_RATES.items()},
                  "prior_base_rates": {str(k2): v for k2, v in prior.prior["base_rates"].items() if not str(k2).startswith("_")}},
        "injects": [{"post_id": p["id"], "level": plan[0], "scenario": plan[4], "source": p.get("s_name")} for p, plan in injects],
        "counts": {"measured": len(selected), "rule": sum(1 for p in selected if p["features"]["sel"].get("why") == "rule"),
                   "audit": sum(1 for p in selected if p["features"]["sel"].get("why") == "audit"), "checks_so_far": so_far_checks,
                   "labelled": len(labels), "positives_b3": sum(1 for l in labels if int(l["level"]) >= 3), "searches": dict(eng.searches),
                   "indicator_sweeps": sweeps, "flags_real": flags_real, "flags_exercise": dict(flags_ex), "levels_projected": dict(Counter(str(s["level"]) for s in eng.series.values()))},
        "opinions": op,
        "real": ["posts, their text, sources and the watchlist", "features, severity, narratives, flashpoint coupling", "echo clusters, coordinated link sharing, aggregator provenance",
                 "GDELT salience series", "the analyst brief and its figures"] + ([f"second opinions on {op['opinions']} posts (by {op.get('by') or 'the file given'}), recorded as the triage pass records them"] if op.get("opinions") else []),
        "simulated": ["pickup counts in every US lane (X, Reddit, Bluesky, Threads, YouTube, TikTok, Truth Social, Mastodon, Gab) and GDELT news counts",
                      "public figures (numbered placeholders, never real accounts)", "covert-operation indicator counts", "auto-labels and the dry-run calibration",
                      "lane statuses and X spend", "breakout probabilities and flags on measured posts, which include pickups observed so far"],
        "notes": ["Checks run through each post's full 7-day horizon, so check times go past the collection date; scores use only what was observed by the snapshot time.",
                  "First scoring is placed within 30 minutes of publication, as a collector running every 30 minutes would have done.",
                  f"Scripted injects fix the outcome of {len(injects)} posts so every Breakout Scale level appears; every other measured post is one draw (seed {seed}) from the simulation truth."
                  + (f" Seed {seed_asked} was asked for; {seed} was the first seed from there whose draw gave calibration enough level-3 outcomes to run." if seed != seed_asked else ""),
                  "The calibration is a dry run: the active model stays the analyst prior.",
                  "The backtest split is not purged here: simulated outcomes are independent draws, so no outcome window overlaps the next. A live calibration purges one 7-day horizon."],
    }
    st.kv_set("exercise", json.dumps(exercise, ensure_ascii=False))
    return {"data_dir": data_dir, "exercise": exercise, "calibration": {k2: cal.get(k2) for k2 in ("status", "n", "positives_b3", "effective_n", "message")}}
