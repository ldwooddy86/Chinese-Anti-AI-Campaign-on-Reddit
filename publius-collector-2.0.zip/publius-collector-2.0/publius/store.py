"""SQLite store (WAL): sources, posts, metric snapshots, breakout observations, labels, model versions, runs.

Privacy rail: the store holds posts ONLY from watchlist sources (foreign state and state-aligned accounts).
Breakout observations in US-audience lanes are stored as aggregate counts; an individual amplifier's
handle is stored only when that account is above the public-figure threshold (config model.public_figure_followers)."""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

from .util import now

SCHEMA_VERSION = 3
SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
  id TEXT PRIMARY KEY, entity_id TEXT, platform TEXT NOT NULL, handle TEXT, name TEXT, country TEXT, category TEXT,
  tier TEXT, grade TEXT, lang TEXT, evidence TEXT, followers INTEGER, followers_ts INTEGER, enabled INTEGER DEFAULT 1,
  status TEXT DEFAULT 'unverified', status_note TEXT, last_post_ts INTEGER, cursor TEXT, last_ok INTEGER, last_error TEXT,
  last_run INTEGER, items INTEGER DEFAULT 0, provenance TEXT
);
CREATE INDEX IF NOT EXISTS sources_platform ON sources(platform);
CREATE INDEX IF NOT EXISTS sources_entity ON sources(entity_id);
CREATE TABLE IF NOT EXISTS posts (
  id TEXT PRIMARY KEY, source_id TEXT NOT NULL, platform TEXT, country TEXT, category TEXT, ts INTEGER NOT NULL, url TEXT,
  title TEXT, text TEXT, lang TEXT, urls TEXT, domains TEXT, hashtags TEXT, mentions TEXT, media TEXT, metrics TEXT,
  metrics_ts INTEGER, fwd_from TEXT, upstream TEXT, features TEXT, narratives TEXT, severity INTEGER, sev_evidence TEXT,
  score TEXT, p3 REAL, risk REAL, rr REAL, flag TEXT, scored_ts INTEGER, model_version TEXT, breakout TEXT, breakout_level INTEGER,
  breakout_ts INTEGER, cluster_id TEXT, llm TEXT, created INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS posts_ts ON posts(ts DESC);
CREATE INDEX IF NOT EXISTS posts_src ON posts(source_id);
CREATE INDEX IF NOT EXISTS posts_risk ON posts(risk DESC);
CREATE INDEX IF NOT EXISTS posts_country ON posts(country, ts DESC);
CREATE TABLE IF NOT EXISTS metric_snaps (post_id TEXT, ts INTEGER, views INTEGER, likes INTEGER, shares INTEGER, replies INTEGER);
CREATE INDEX IF NOT EXISTS snaps_post ON metric_snaps(post_id, ts);
CREATE TABLE IF NOT EXISTS breakout_obs (
  post_id TEXT, lane TEXT, ts INTEGER, count INTEGER, reach_max INTEGER, public_figures TEXT, violent_or_mobilising INTEGER, query TEXT, note TEXT
);
CREATE INDEX IF NOT EXISTS bo_post ON breakout_obs(post_id, ts);
CREATE TABLE IF NOT EXISTS labels (post_id TEXT PRIMARY KEY, level INTEGER NOT NULL, source TEXT, note TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS model_versions (id TEXT PRIMARY KEY, ts INTEGER, params TEXT, metrics TEXT, active INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS runs (id INTEGER PRIMARY KEY AUTOINCREMENT, started INTEGER, finished INTEGER, connector TEXT, items INTEGER, errors INTEGER, note TEXT);
CREATE TABLE IF NOT EXISTS spend (day TEXT, lane TEXT, usd REAL, units INTEGER, PRIMARY KEY(day, lane));
CREATE TABLE IF NOT EXISTS salience (flashpoint TEXT, day TEXT, volume REAL, source TEXT, PRIMARY KEY(flashpoint, day, source));
CREATE TABLE IF NOT EXISTS indicator_obs (op_id TEXT, indicator TEXT, lane TEXT, ts INTEGER, count INTEGER, public_figures TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ind_op ON indicator_obs(op_id, indicator, lane, ts);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""

JSON_COLS = ("urls", "domains", "hashtags", "mentions", "media", "metrics", "upstream", "features", "narratives", "sev_evidence", "score", "breakout", "llm")


@dataclass
class Post:
    id: str
    source_id: str
    ts: int
    text: str = ""
    title: str = ""
    url: str = ""
    lang: str = ""
    platform: str = ""
    country: str = ""
    category: str = ""
    urls: list = field(default_factory=list)
    domains: list = field(default_factory=list)
    hashtags: list = field(default_factory=list)
    mentions: list = field(default_factory=list)
    media: dict = field(default_factory=dict)       # {"photo": n, "video": n}
    metrics: dict = field(default_factory=dict)     # {"views":…, "likes":…, "shares":…, "replies":…}
    fwd_from: str = ""
    upstream: list = field(default_factory=list)    # aggregator provenance: channels / outlets the item was lifted from


class Store:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self.path = os.path.join(data_dir, "publius.sqlite")
        self._local = threading.local()
        with self.conn() as c:
            c.executescript(SCHEMA)
            c.execute("INSERT OR IGNORE INTO kv(k,v) VALUES('schema_version', ?)", (str(SCHEMA_VERSION),))

    def conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=60, check_same_thread=False)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            self._local.conn = c
        return c

    # ---------------------------------------------------------------- sources
    def upsert_source(self, s: dict) -> None:
        cols = ["id", "entity_id", "platform", "handle", "name", "country", "category", "tier", "grade", "lang", "evidence", "enabled", "provenance"]
        vals = [s.get(k) if k != "evidence" else json.dumps(s.get("evidence") or [], ensure_ascii=False) for k in cols]
        vals[cols.index("enabled")] = 1 if s.get("enabled", True) else 0
        with self.conn() as c:
            c.execute(f"INSERT INTO sources({','.join(cols)}) VALUES({','.join('?' * len(cols))}) ON CONFLICT(id) DO UPDATE SET "
                      + ",".join(f"{k}=excluded.{k}" for k in cols if k != "id"), vals)      # the watchlist file is the switch

    def delete_sources(self, ids: list[str]) -> int:
        with self.conn() as c:
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                c.execute(f"DELETE FROM posts WHERE source_id IN ({','.join('?' * len(chunk))})", chunk)
                c.execute(f"DELETE FROM sources WHERE id IN ({','.join('?' * len(chunk))})", chunk)
            c.execute("DELETE FROM metric_snaps WHERE post_id NOT IN (SELECT id FROM posts)")
            c.execute("DELETE FROM breakout_obs WHERE post_id NOT IN (SELECT id FROM posts)")
        return len(ids)

    def purge_disabled(self) -> int:
        """A source is switched off because it must not be collected (a listed individual who may be a US person, or an
        attribution not yet evidenced), so anything already collected from it is deleted too."""
        with self.conn() as c:
            n = c.execute("DELETE FROM posts WHERE source_id IN (SELECT id FROM sources WHERE enabled=0)").rowcount
            c.execute("DELETE FROM metric_snaps WHERE post_id NOT IN (SELECT id FROM posts)")
            c.execute("DELETE FROM breakout_obs WHERE post_id NOT IN (SELECT id FROM posts)")
        return n

    def set_source_status(self, sid: str, status: str, note: str = "", followers: Optional[int] = None, last_post_ts: Optional[int] = None, name: Optional[str] = None) -> None:
        with self.conn() as c:
            c.execute("UPDATE sources SET status=?, status_note=?, followers=COALESCE(?, followers), followers_ts=CASE WHEN ? IS NULL THEN followers_ts ELSE ? END, "
                      "last_post_ts=COALESCE(?, last_post_ts), name=COALESCE(?, name) WHERE id=?", (status, note[:300], followers, followers, now(), last_post_ts, name, sid))

    def source_ok(self, sid: str, cursor: Optional[str] = None, n_items: int = 0, last_post_ts: Optional[int] = None) -> None:
        with self.conn() as c:
            c.execute("UPDATE sources SET last_ok=?, last_run=?, last_error=NULL, cursor=COALESCE(?, cursor), items=items+?, last_post_ts=MAX(COALESCE(last_post_ts,0), COALESCE(?,0)) WHERE id=?",
                      (now(), now(), cursor, n_items, last_post_ts, sid))

    def source_error(self, sid: str, err: str) -> None:
        with self.conn() as c:
            c.execute("UPDATE sources SET last_run=?, last_error=? WHERE id=?", (now(), str(err)[:400], sid))

    def source(self, sid: str) -> Optional[dict]:
        r = self.conn().execute("SELECT * FROM sources WHERE id=?", (sid,)).fetchone()
        return self._row_source(r) if r else None

    def sources(self, platform: str = "", enabled_only: bool = False) -> list[dict]:
        q, a = "SELECT * FROM sources WHERE 1=1", []
        if platform:
            q += " AND platform=?"; a.append(platform)
        if enabled_only:
            q += " AND enabled=1"
        q += " ORDER BY country, category, platform, handle"
        return [self._row_source(r) for r in self.conn().execute(q, a).fetchall()]

    def set_enabled(self, sid: str, on: bool) -> None:
        with self.conn() as c:
            c.execute("UPDATE sources SET enabled=? WHERE id=?", (1 if on else 0, sid))

    @staticmethod
    def _row_source(r: sqlite3.Row) -> dict:
        d = dict(r)
        try:
            d["evidence"] = json.loads(d["evidence"]) if d.get("evidence") else []
        except Exception:
            d["evidence"] = []
        return d

    # ---------------------------------------------------------------- posts
    def has_post(self, pid: str) -> bool:
        return self.conn().execute("SELECT 1 FROM posts WHERE id=?", (pid,)).fetchone() is not None

    def add_post(self, p: Post) -> bool:
        """Insert a new post; for an existing one refresh engagement metrics (and keep a snapshot for velocity)."""
        c = self.conn()
        if self.has_post(p.id):
            if p.metrics:
                with c:
                    c.execute("UPDATE posts SET metrics=?, metrics_ts=? WHERE id=?", (json.dumps(p.metrics), now(), p.id))
                    self._snap(c, p.id, p.metrics)
            return False
        with c:
            c.execute("INSERT INTO posts(id,source_id,platform,country,category,ts,url,title,text,lang,urls,domains,hashtags,mentions,media,metrics,metrics_ts,fwd_from,upstream,created) "
                      "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (p.id, p.source_id, p.platform, p.country, p.category, int(p.ts or now()), (p.url or "")[:900], (p.title or "")[:400], p.text, p.lang[:8],
                       json.dumps(p.urls), json.dumps(p.domains), json.dumps(p.hashtags, ensure_ascii=False), json.dumps(p.mentions), json.dumps(p.media),
                       json.dumps(p.metrics), now() if p.metrics else None, (p.fwd_from or "")[:200], json.dumps(p.upstream, ensure_ascii=False), now()))
            if p.metrics:
                self._snap(c, p.id, p.metrics)
        return True

    @staticmethod
    def _snap(c: sqlite3.Connection, pid: str, m: dict) -> None:
        c.execute("INSERT INTO metric_snaps(post_id, ts, views, likes, shares, replies) VALUES(?,?,?,?,?,?)",
                  (pid, now(), m.get("views"), m.get("likes"), m.get("shares"), m.get("replies")))

    def update_analysis(self, pid: str, **cols: Any) -> None:
        if not cols:
            return
        sets, vals = [], []
        for k, v in cols.items():
            sets.append(f"{k}=?")
            vals.append(json.dumps(v, ensure_ascii=False) if k in JSON_COLS and not isinstance(v, str) else v)
        vals.append(pid)
        c = self.conn()
        if getattr(self._local, "bulk", False):
            c.execute(f"UPDATE posts SET {', '.join(sets)} WHERE id=?", vals)
        else:
            with c:
                c.execute(f"UPDATE posts SET {', '.join(sets)} WHERE id=?", vals)

    def bulk(self):
        """Context manager: many update_analysis calls in one transaction."""
        store = self

        class _B:
            def __enter__(self_):
                store._local.bulk = True
                store.conn().execute("BEGIN")

            def __exit__(self_, et, ev, tb):
                store._local.bulk = False
                c = store.conn()
                c.execute("ROLLBACK") if et else c.execute("COMMIT")
        return _B()

    def posts(self, since: Optional[int] = None, until: Optional[int] = None, limit: int = 500, country: str = "", platform: str = "", category: str = "",
              source_id: str = "", order: str = "ts", q: str = "", min_risk: float = 0.0, flag: str = "", unscored: bool = False) -> list[dict]:
        sql = ("SELECT posts.*, sources.handle AS s_handle, sources.name AS s_name, sources.tier AS s_tier, sources.grade AS s_grade, "
               "sources.followers AS s_followers, sources.entity_id AS s_entity, sources.provenance AS s_prov FROM posts LEFT JOIN sources ON sources.id=posts.source_id WHERE 1=1")
        a: list[Any] = []
        if since:
            sql += " AND posts.ts>=?"; a.append(int(since))
        if until:
            sql += " AND posts.ts<?"; a.append(int(until))
        if country:
            sql += " AND posts.country=?"; a.append(country)
        if platform:
            sql += " AND posts.platform=?"; a.append(platform)
        if category:
            sql += " AND posts.category=?"; a.append(category)
        if source_id:
            sql += " AND posts.source_id=?"; a.append(source_id)
        if q:
            sql += " AND (posts.text LIKE ? OR posts.title LIKE ?)"; a += [f"%{q}%", f"%{q}%"]
        if min_risk:
            sql += " AND posts.risk>=?"; a.append(float(min_risk))
        if flag:
            sql += " AND posts.flag=?"; a.append(flag)
        if unscored:
            sql += " AND posts.scored_ts IS NULL"
        sql += {"ts": " ORDER BY posts.ts DESC", "risk": " ORDER BY posts.risk DESC, posts.ts DESC", "p3": " ORDER BY posts.p3 DESC"}.get(order, " ORDER BY posts.ts DESC")
        sql += " LIMIT ?"; a.append(int(limit))
        return [self._row_post(r) for r in self.conn().execute(sql, a).fetchall()]

    def post(self, pid: str) -> Optional[dict]:
        r = self.conn().execute("SELECT posts.*, sources.handle AS s_handle, sources.name AS s_name, sources.tier AS s_tier, sources.grade AS s_grade, sources.followers AS s_followers, sources.entity_id AS s_entity, sources.provenance AS s_prov "
                                "FROM posts LEFT JOIN sources ON sources.id=posts.source_id WHERE posts.id=?", (pid,)).fetchone()
        return self._row_post(r) if r else None

    @staticmethod
    def _row_post(r: sqlite3.Row) -> dict:
        d = dict(r)
        for k in JSON_COLS:
            if k in d:
                try:
                    d[k] = json.loads(d[k]) if d.get(k) else ([] if k in ("urls", "domains", "hashtags", "mentions", "upstream", "narratives", "sev_evidence") else {})
                except Exception:
                    d[k] = {}
        return d

    def snaps(self, pid: str) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM metric_snaps WHERE post_id=? ORDER BY ts", (pid,)).fetchall()]

    def source_engagement_baseline(self, sid: str, metric: str = "views", days: int = 30) -> tuple[float, float, int]:
        """(mean, sd, n) of log1p(metric) over the source's recent posts — the velocity z-score reference."""
        import math
        vals = []
        for r in self.conn().execute("SELECT metrics FROM posts WHERE source_id=? AND ts>=?", (sid, now() - days * 86400)).fetchall():
            try:
                v = (json.loads(r["metrics"]) or {}).get(metric)
            except Exception:
                v = None
            if isinstance(v, (int, float)) and v >= 0:
                vals.append(math.log1p(v))
        n = len(vals)
        if n < 3:
            return 0.0, 0.0, n
        m = sum(vals) / n
        sd = (sum((x - m) ** 2 for x in vals) / (n - 1)) ** 0.5
        return m, sd, n

    # ---------------------------------------------------------------- breakout / labels
    def add_breakout_obs(self, pid: str, lane: str, count: int, reach_max: Optional[int] = None, public_figures: Optional[list] = None, violent_or_mobilising: int = 0, query: str = "", note: str = "") -> None:
        with self.conn() as c:
            c.execute("INSERT INTO breakout_obs(post_id,lane,ts,count,reach_max,public_figures,violent_or_mobilising,query,note) VALUES(?,?,?,?,?,?,?,?,?)",
                      (pid, lane, now(), int(count), reach_max, json.dumps(public_figures or []), int(violent_or_mobilising), query[:300], note[:200]))

    def breakout_obs(self, pid: str) -> list[dict]:
        out = []
        for r in self.conn().execute("SELECT * FROM breakout_obs WHERE post_id=? ORDER BY ts", (pid,)).fetchall():
            d = dict(r)
            d["public_figures"] = json.loads(d["public_figures"] or "[]")
            out.append(d)
        return out

    def add_indicator_obs(self, op_id: str, indicator: str, lane: str, count: int, public_figures: Optional[list] = None, note: str = "") -> None:
        with self.conn() as c:
            c.execute("INSERT INTO indicator_obs(op_id, indicator, lane, ts, count, public_figures, note) VALUES(?,?,?,?,?,?,?)",
                      (op_id, indicator, lane, now(), int(count), json.dumps(public_figures or []), note[:200]))

    def indicator_latest(self) -> list[dict]:
        rows = self.conn().execute("SELECT o.* FROM indicator_obs o JOIN (SELECT op_id, indicator, lane, MAX(ts) AS mt FROM indicator_obs GROUP BY op_id, indicator, lane) m "
                                   "ON o.op_id=m.op_id AND o.indicator=m.indicator AND o.lane=m.lane AND o.ts=m.mt").fetchall()
        out = []
        for r in rows:
            d = dict(r); d["public_figures"] = json.loads(d["public_figures"] or "[]"); out.append(d)
        return out

    def set_label(self, pid: str, level: int, source: str = "analyst", note: str = "") -> None:
        with self.conn() as c:
            c.execute("INSERT INTO labels(post_id, level, source, note, ts) VALUES(?,?,?,?,?) ON CONFLICT(post_id) DO UPDATE SET level=excluded.level, source=excluded.source, note=excluded.note, ts=excluded.ts "
                      "WHERE labels.source<>'analyst' OR excluded.source='analyst'", (pid, int(level), source, note[:300], now()))

    def labels(self) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM labels").fetchall()]

    # ---------------------------------------------------------------- model / runs / spend / kv
    def save_model(self, mid: str, params: dict, metrics: dict, active: bool = True) -> None:
        with self.conn() as c:
            if active:
                c.execute("UPDATE model_versions SET active=0")
            c.execute("INSERT OR REPLACE INTO model_versions(id, ts, params, metrics, active) VALUES(?,?,?,?,?)", (mid, now(), json.dumps(params), json.dumps(metrics), 1 if active else 0))

    def active_model(self) -> Optional[dict]:
        r = self.conn().execute("SELECT * FROM model_versions WHERE active=1 ORDER BY ts DESC LIMIT 1").fetchone()
        if not r:
            return None
        d = dict(r); d["params"] = json.loads(d["params"]); d["metrics"] = json.loads(d["metrics"] or "{}")
        return d

    def run_start(self, connector: str) -> int:
        with self.conn() as c:
            return int(c.execute("INSERT INTO runs(started, connector) VALUES(?,?)", (now(), connector)).lastrowid)

    def run_end(self, rid: int, items: int, errors: int, note: str = "") -> None:
        with self.conn() as c:
            c.execute("UPDATE runs SET finished=?, items=?, errors=?, note=? WHERE id=?", (now(), items, errors, note[:400], rid))

    def recent_runs(self, limit: int = 40) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

    def add_spend(self, day_: str, lane: str, usd: float, units: int = 0) -> None:
        with self.conn() as c:
            c.execute("INSERT INTO spend(day, lane, usd, units) VALUES(?,?,?,?) ON CONFLICT(day, lane) DO UPDATE SET usd=usd+excluded.usd, units=units+excluded.units", (day_, lane, usd, units))

    def spend_today(self, day_: str, lane: str) -> float:
        r = self.conn().execute("SELECT usd FROM spend WHERE day=? AND lane=?", (day_, lane)).fetchone()
        return float(r["usd"]) if r else 0.0

    def set_salience(self, fp: str, day_: str, volume: float, source: str) -> None:
        with self.conn() as c:
            c.execute("INSERT OR REPLACE INTO salience(flashpoint, day, volume, source) VALUES(?,?,?,?)", (fp, day_, volume, source))

    def salience(self) -> list[dict]:
        return [dict(r) for r in self.conn().execute("SELECT * FROM salience ORDER BY flashpoint, day").fetchall()]

    def kv_get(self, k: str, default: str = "") -> str:
        r = self.conn().execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return r["v"] if r else default

    def kv_set(self, k: str, v: str) -> None:
        with self.conn() as c:
            c.execute("INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))

    def counts(self) -> dict:
        c = self.conn()
        one = lambda q, *a: c.execute(q, a).fetchone()[0]
        return {"posts": one("SELECT COUNT(*) FROM posts"), "sources": one("SELECT COUNT(*) FROM sources"), "enabled_sources": one("SELECT COUNT(*) FROM sources WHERE enabled=1"),
                "live_sources": one("SELECT COUNT(*) FROM sources WHERE status='live'"), "scored": one("SELECT COUNT(*) FROM posts WHERE scored_ts IS NOT NULL"),
                "flagged": one("SELECT COUNT(*) FROM posts WHERE flag IN ('WATCH','ALERT')"), "labels": one("SELECT COUNT(*) FROM labels"),
                "breakout_checks": one("SELECT COUNT(*) FROM breakout_obs")}

    def prune(self, keep_days: int) -> int:
        cutoff = now() - keep_days * 86400
        c = self.conn()
        with c:
            n = c.execute("DELETE FROM posts WHERE ts<? AND id NOT IN (SELECT post_id FROM labels)", (cutoff,)).rowcount
            c.execute("DELETE FROM metric_snaps WHERE post_id NOT IN (SELECT id FROM posts)")
        return int(n)
