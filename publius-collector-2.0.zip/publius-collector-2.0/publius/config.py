"""Configuration: config.toml over defaults, secrets overridable from the environment, and the rails enforced at load."""
from __future__ import annotations

import copy
import os
import sys
from typing import Any

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore
    except ModuleNotFoundError:
        tomllib = None  # type: ignore

LOOPBACK = {"127.0.0.1", "localhost", "::1"}

DEFAULTS: dict[str, Any] = {
    "general": {"data_dir": "./data", "interval_minutes": 30, "keep_days": 120, "watchlists": ["hamilton_base", "aggregators", "cn_domestic", "ir_messengers", "ru_domestic", "kp_base", "discord"], "title": "PUBLIUS"},
    "server": {"host": "127.0.0.1", "port": 8768, "token": ""},
    "model": {"public_figure_followers": 100000, "horizon_days": 7, "watch_rr": 2.0, "watch_min_severity": 3, "alert_p3": 0.20, "alert_min_severity": 3,
              "s2_watch_rr": 5.0, "breakout_min_pickups": 3, "breakout_check_hours": [1, 6, 24, 72, 168], "breakout_max_checks_per_cycle": 40,
              "breakout_min_severity": 2, "breakout_min_rr": 1.5, "audit_rate": 0.05, "breakout_min_mainstream": 2},
    "triage": {"enabled": False, "anthropic_api_key": "", "model": "claude-sonnet-5", "max_posts_per_cycle": 40, "min_rr": 1.5},
    # ---------------------------------------------------------------- collection lanes (watchlist sources)
    "telegram_web": {"enabled": True, "pages_per_channel": 1, "max_channels_per_cycle": 200},
    "telegram": {"enabled": False, "api_id": 0, "api_hash": "", "session": "publius_user", "max_messages_per_channel": 100},
    "x": {"enabled": False, "bearer_token": "", "daily_budget_usd": 5.0, "max_results": 20, "priority": ["media", "aggregator", "gov"]},
    "youtube": {"enabled": True, "api_key": "", "use_rss": True},
    "rss": {"enabled": True},
    "bluesky": {"enabled": True, "app_password": "", "handles": [], "jetstream": False},
    "mastodon": {"enabled": True, "instances": ["mastodon.social"], "token": ""},
    "truthsocial": {"enabled": False, "token": "", "note": "Mastodon-compatible API; cloud IPs are blocked; check the platform's terms before enabling"},
    "gab": {"enabled": False, "token": "", "note": "Mastodon-derived API; same caveats as Truth Social"},
    "reddit": {"enabled": False, "client_id": "", "client_secret": "", "user_agent": "publius-collector/2.0 (read-only research)"},
    "threads": {"enabled": False, "access_token": ""},
    "meta": {"enabled": False, "access_token": "", "ig_business_id": ""},
    "tiktok": {"enabled": False, "client_key": "", "client_secret": ""},
    "vk": {"enabled": False, "service_token": ""},
    "rutube": {"enabled": True},
    "odysee": {"enabled": True},
    "gdelt": {"enabled": True, "state_domains": True, "salience": True},
    "cn_hotlist": {"enabled": True, "boards": ["baidu", "toutiao"]},
    "eitaa": {"enabled": False},
    "discord": {"enabled": False, "token": ""},
    # ---------------------------------------------------------------- 2.0 lanes
    "telegram_bot": {"enabled": False, "token": ""},
    "weibo": {"enabled": True, "accounts": True, "hot_search": True},
    "bilibili": {"enabled": True, "popular": True, "hot_words": True, "visitor_cookie": True},
    "zhihu": {"enabled": True, "hot_list": True, "members": True},
    "douyin": {"enabled": True},
    "wechat_mp": {"enabled": False},
    "rsshub": {"enabled": False, "base_url": "", "access_key": ""},
    "bale": {"enabled": False}, "splus": {"enabled": False}, "aparat": {"enabled": True}, "virasty": {"enabled": False},
    "ok": {"enabled": False, "application_key": "", "access_token": "", "session_secret_key": ""},
    "dzen": {"enabled": False, "rss_template": "https://dzen.ru/{handle}/rss"},
    "max": {"enabled": False},
    "dprk_web": {"enabled": True, "timeout": 60, "fetch_bodies": False, "max_new_articles_per_page": 20},
    "kcnawatch": {"enabled": True},
    "tumblr": {"enabled": False, "api_key": ""},
    "fourchan": {"enabled": False, "boards": ["pol", "news"]},
}
LOGIN_COOKIE_KEYS = ("cookie", "cookies", "sessdata", "sub", "z_c0", "sessionid", "bili_jct", "wechat_session")   # never accepted on a domestic-platform lane
COOKIE_LANES = ("weibo", "bilibili", "zhihu", "douyin", "wechat_mp", "cn_hotlist", "bale", "splus", "virasty", "max", "dzen", "eitaa")

SECRET_KEYS = (("server", "token"), ("triage", "anthropic_api_key"), ("telegram", "api_hash"), ("x", "bearer_token"), ("youtube", "api_key"), ("bluesky", "app_password"),
               ("mastodon", "token"), ("truthsocial", "token"), ("gab", "token"), ("reddit", "client_secret"), ("threads", "access_token"), ("meta", "access_token"),
               ("tiktok", "client_secret"), ("vk", "service_token"), ("cn_hotlist", "weibo_cookie"), ("discord", "token"), ("telegram_bot", "token"), ("ok", "access_token"),
               ("ok", "session_secret_key"), ("tumblr", "api_key"), ("rsshub", "access_key"))   # weibo_cookie: redacted if an old config still carries one
ENV = {"PUBLIUS_TOKEN": ("server", "token"), "ANTHROPIC_API_KEY": ("triage", "anthropic_api_key"), "X_BEARER_TOKEN": ("x", "bearer_token"),
       "YOUTUBE_API_KEY": ("youtube", "api_key"), "BLUESKY_APP_PASSWORD": ("bluesky", "app_password"), "REDDIT_CLIENT_SECRET": ("reddit", "client_secret"),
       "THREADS_ACCESS_TOKEN": ("threads", "access_token"), "META_ACCESS_TOKEN": ("meta", "access_token"), "VK_SERVICE_TOKEN": ("vk", "service_token"),
       "DISCORD_BOT_TOKEN": ("discord", "token"), "TELEGRAM_BOT_TOKEN": ("telegram_bot", "token"), "OK_ACCESS_TOKEN": ("ok", "access_token"),
       "OK_SESSION_SECRET_KEY": ("ok", "session_secret_key"), "OK_APPLICATION_KEY": ("ok", "application_key"), "TUMBLR_API_KEY": ("tumblr", "api_key"),
       "RSSHUB_BASE_URL": ("rsshub", "base_url"), "RSSHUB_ACCESS_KEY": ("rsshub", "access_key")}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def load(path: str | None) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    path = path or "config.toml"
    if os.path.exists(path):
        if tomllib is None:
            sys.exit("Python 3.11+ (tomllib) or `pip install tomli` is required to read config.toml")
        with open(path, "rb") as f:
            cfg = _merge(cfg, tomllib.load(f))
    cfg["_path"] = os.path.abspath(path)
    for env, (sect, key) in ENV.items():
        if os.environ.get(env):
            cfg[sect][key] = os.environ[env]
    if cfg["server"]["host"] not in LOOPBACK:
        sys.exit(f"server.host must be loopback (127.0.0.1 / localhost); got {cfg['server']['host']!r}. PUBLIUS never listens on a network interface.")
    base = os.path.dirname(cfg["_path"])
    dd = cfg["general"]["data_dir"]
    cfg["general"]["data_dir"] = dd if os.path.isabs(dd) else os.path.normpath(os.path.join(base, dd))
    cfg["_root"] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    # rails: the board-and-state-account lanes never carry a login cookie, whatever the config says
    hl = cfg.get("cn_hotlist", {})
    if "weibo" in (hl.get("boards") or []) or hl.get("weibo_cookie"):
        print("cn_hotlist: the Weibo board moved to the weibo lane (public hot-search endpoint); no cookie is used. Reading Baidu and Toutiao here.", file=sys.stderr)
        hl["boards"] = [b for b in hl.get("boards") or [] if b != "weibo"]
        hl.pop("weibo_cookie", None)
    for lane in COOKIE_LANES:
        sect = cfg.get(lane)
        if not isinstance(sect, dict):
            continue
        for k in list(sect):
            if isinstance(sect[k], bool):
                continue                                   # visitor_cookie = true/false is a switch, not a cookie
            if k.lower() in LOGIN_COOKIE_KEYS or "cookie" in k.lower():
                print(f"{lane}.{k}: dropped. A login cookie is never used on a domestic-platform lane; the lane reads what an anonymous visitor sees, or nothing.", file=sys.stderr)
                sect.pop(k)
    return cfg


def redacted(cfg: dict) -> dict:
    out = copy.deepcopy(cfg)
    for sect, key in SECRET_KEYS:
        if out.get(sect, {}).get(key):
            out[sect][key] = "•••"
    out.pop("_path", None); out.pop("_root", None)
    return out
