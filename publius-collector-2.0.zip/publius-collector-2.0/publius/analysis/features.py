"""Post → explainable feature record: lexicon evidence, narratives, flashpoint coupling, severity (S0–S4), and the
numeric feature vector the breakout model consumes. Dynamic diffusion features (velocity, echo, cross-country
convergence, platforms seen, early pickups) are merged in by the pipeline once coordination has run."""
from __future__ import annotations

import json
import math
import os
import re
from functools import lru_cache
from typing import Optional

from .gazetteer import countries_in
import bisect

from .lexicon import match_all, spans_all


def _jload(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return json.load(f)


DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")

# US adult reach by platform (Pew 2025 'ever use'); platforms Pew does not survey carry an analyst estimate, flagged in platforms.json
PLATFORM_REACH = {"youtube": 0.84, "facebook": 0.71, "instagram": 0.50, "tiktok": 0.37, "reddit": 0.26, "x": 0.21, "threads": 0.08, "bluesky": 0.04,
                  "truthsocial": 0.03, "rumble": 0.03, "telegram": 0.03, "odysee": 0.005, "rss": 0.05, "vk": 0.001, "rutube": 0.001, "cn_hotlist": 0.0,
                  "mastodon": 0.01, "gab": 0.005, "eitaa": 0.0, "discord": 0.02}


@lru_cache(maxsize=1)
def narratives() -> list[dict]:
    return _jload(os.path.join(DATA, "narratives.json"))["narratives"]


@lru_cache(maxsize=1)
def flashpoints() -> list[dict]:
    return _jload(os.path.join(DATA, "flashpoints.json"))["flashpoints"]


@lru_cache(maxsize=1)
def _narr_matcher():
    from .lexicon import PhraseMatcher
    terms = {}
    for n in narratives():
        terms[n["id"] + "|s"] = n["strong"]
        terms[n["id"] + "|u"] = n["support"]
    return PhraseMatcher(terms)


@lru_cache(maxsize=1)
def _fp_matcher():
    from .lexicon import PhraseMatcher
    terms = {}
    for f in flashpoints():
        terms[f["id"] + "|a"] = f.get("anchors", [])
        terms[f["id"] + "|k"] = f.get("keywords", [])
    return PhraseMatcher(terms)


def _grievance(fid: str) -> bool:
    return next((bool(f.get("grievance", True)) for f in flashpoints() if f["id"] == fid), True)


def reload_reference_data() -> None:
    narratives.cache_clear(); flashpoints.cache_clear(); _narr_matcher.cache_clear(); _fp_matcher.cache_clear()


def assign_narratives(text: str, us: bool) -> list[str]:
    """Narrative N applies when the post is about the US and carries one strong cue or two distinct support cues."""
    if not us:
        return []
    strong, support = set(), {}
    for cat, _, term in _narr_matcher().spans(text or ""):
        nid, kind = cat.split("|")
        if kind == "s":
            strong.add(nid)
        else:
            support.setdefault(nid, set()).add(term)
    return [n["id"] for n in narratives() if n["id"] in strong or len(support.get(n["id"], ())) >= 2]


def couple_flashpoints(text: str, ts: int) -> list[str]:
    """Flashpoint F applies inside its window when the post carries one anchor term or two distinct keywords."""
    import datetime as _dt
    anchors, kws = set(), {}
    for cat, _, term in _fp_matcher().spans(text or ""):
        fid, kind = cat.split("|")
        if kind == "a":
            anchors.add(fid)
        else:
            kws.setdefault(fid, set()).add(term)
    out = []
    for f in flashpoints():
        fid = f["id"]
        if fid not in anchors and len(kws.get(fid, ())) < 2:
            continue
        try:
            start = int(_dt.datetime.fromisoformat(f["start"]).replace(tzinfo=_dt.timezone.utc).timestamp())
            end = int(_dt.datetime.fromisoformat(f["end"]).replace(tzinfo=_dt.timezone.utc).timestamp()) + 86400
        except Exception:
            continue
        if ts and not (start - 3 * 86400 <= ts <= end):
            continue
        out.append(fid)
    return out


def severity(ev: dict, domestic: bool, flash: list[str]) -> tuple[int, str]:
    """S0 not US-domestic · S1 divisive framing · S2 delegitimisation/conspiracy/known falsehood · S3 mobilisation or dehumanisation
    · S4 violence endorsement, or violence fused with mobilisation/dehumanisation. Returns (level, rule)."""
    if not domestic:
        return 0, "not US-domestic"
    has = lambda k: bool(ev.get(k))
    if has("violence_endorse") or (has("violence") and (has("mobilization_call") or has("dehumanization"))):
        return 4, "violence endorsed, or violence fused with a call to act / dehumanising language"
    if has("mobilization_call") or has("dehumanization") or (has("mobilization_report") and has("delegitimization") and flash):
        return 3, "call to action, dehumanisation, or unrest during a live flashpoint framed as a fight against an illegitimate order"
    if has("delegitimization") or has("conspiracy") or has("debunked"):
        return 2, "delegitimises US institutions, conspiratorial, or repeats a known falsehood"
    return 1, "divisive framing of a US domestic issue"


SENT_SPLIT = re.compile(r"(?<=[.!?。！？؟])\s+|\n+")
ABBREV = re.compile(r"(?:\b(?:U\.S|U\.K|U\.N|D\.C|E\.U|Mr|Mrs|Ms|Dr|Gov|Sen|Rep|Gen|Lt|Col|Sgt|St|Jr|Sr|Inc|Co|Corp|No|vs|etc|approx|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\.|\b[A-Z]\.)$")


def _sentence_starts(text: str) -> list[int]:
    """Sentence start offsets. Splits on terminal punctuation or newlines, but not after abbreviations (U.S., D.C., Gov.)."""
    starts = [0]
    for m in SENT_SPLIT.finditer(text):
        if "\n" not in m.group(0) and ABBREV.search(text[max(0, m.start() - 8):m.start()]):
            continue
        starts.append(m.end())
    return starts
US_SCOPED = ("mobilization_call", "violence_endorse", "dehumanization", "delegitimization")
GROUP_KEYS = ("topic:immigration", "topic:policing_race", "topic:lgbt", "partisan")


def _scoped(text: str, lang: str) -> tuple[dict, dict, list[str], bool, bool]:
    """Sentence-level co-occurrence from one pass of the matchers. A topic only counts as a US-domestic topic when it
    shares a sentence with a US anchor or a US partisan term; calls to action, violence endorsement and delegitimisation
    only count in such sentences; dehumanising terms only count when a group (migrants, race, LGBT, partisans) is named
    in the same sentence. Returns (all hits by category, US-scoped hits, US topics, any US anchor, any US topic)."""
    text = text or ""
    starts = _sentence_starts(text)
    by_sent: dict[int, dict[str, list[str]]] = {}
    ev: dict[str, list[str]] = {}
    for cat, pos, term in spans_all(text, lang):
        ev.setdefault(cat, []).append(term)
        i = bisect.bisect_right(starts, pos) - 1
        by_sent.setdefault(i, {}).setdefault(cat, []).append(term)
    scoped: dict[str, list[str]] = {}
    topics: set[str] = set()
    us_any = False
    for m in by_sent.values():
        if not (m.get("us_anchor") or m.get("partisan")):
            continue
        us_any = True
        topics.update(k.split(":", 1)[1] for k in m if k.startswith("topic:"))
        for k in US_SCOPED:
            if m.get(k) and (k != "dehumanization" or any(m.get(g) for g in GROUP_KEYS)):
                scoped.setdefault(k, []).extend(m[k])
    return ev, scoped, sorted(topics), us_any, bool(topics)


def extract(post: dict, source: Optional[dict] = None) -> dict:
    """Static (content + source) features. Keys in x feed the model; the rest is evidence for the analyst."""
    text = ((post.get("title") or "") + "\n" + (post.get("text") or "")).strip()
    lang = post.get("lang") or "und"
    ev, scoped, topics, us, has_topic = _scoped(text, lang)
    for k in US_SCOPED:                      # evidence shown to the analyst = the US-scoped hits only
        if scoped.get(k):
            ev[k] = scoped[k]
        else:
            ev.pop(k, None)
    for k in list(ev):
        if k.startswith("topic:") and k.split(":", 1)[1] not in topics:
            ev.pop(k)
    domestic = us and (has_topic or bool(ev.get("partisan")))
    flash = couple_flashpoints(text, int(post.get("ts") or 0)) if us else []
    narr = assign_narratives(text, us)
    sev, rule = severity(ev, domestic, flash)
    hashtags = [h.lower() for h in (post.get("hashtags") or [])]
    debunked = bool(ev.get("debunked")) or "alldemocratsarecriminals" in hashtags
    if debunked and "debunked" not in ev:
        ev["debunked"] = ["#alldemocratsarecriminals"]
    media = post.get("media") or {}
    src = source or {}
    followers = src.get("followers") or post.get("s_followers") or 0
    platform = post.get("platform") or src.get("platform") or ""
    cat = post.get("category") or src.get("category") or ""
    cap = lambda n, m: float(min(m, n))
    reach = max(0.003, PLATFORM_REACH.get(platform, 0.02))
    x = {
        "us_domestic": 1.0 if domestic else 0.0,
        "wedge_n": cap(len([t for t in topics if t != "political_violence"]), 3),
        "outgroup_n": cap(len(ev.get("partisan", [])), 3),
        "moral_emotional_n": cap(len(ev.get("moral_emotional", [])), 5) if domestic else 0.0,
        "negative_n": cap(len(ev.get("negative", [])), 5) if domestic else 0.0,
        "debunked": 1.0 if debunked else 0.0,
        "conspiracy": 1.0 if (ev.get("conspiracy") and domestic) else 0.0,
        "delegit": 1.0 if ev.get("delegitimization") else 0.0,
        "mob_call": 1.0 if ev.get("mobilization_call") else 0.0,
        "violence": 1.0 if (ev.get("violence_endorse") or (ev.get("violence") and domestic)) else 0.0,
        "video": 1.0 if media.get("video") else 0.0,
        "flashpoint": 1.0 if any(_grievance(f) for f in flash) else 0.0,
        "lang_en": (1.0 if lang == "en" else 0.0) - 1.0,
        "log_followers": max(-3.0, min(3.0, math.log10(followers) - 5.0)) if followers and followers > 0 else 0.0,
        "platform_reach": max(-3.0, min(1.5, math.log(reach / 0.21))),
        "tier_aggregator": 1.0 if cat == "aggregator" else 0.0,
        "gov": 1.0 if cat == "gov" else 0.0,
    }
    return {"x": x, "evidence": {k: sorted(set(v))[:8] for k, v in ev.items()}, "topics": topics, "us": us, "domestic": domestic, "narratives": narr,
            "flashpoints": flash, "severity": sev, "severity_rule": rule, "countries": countries_in(text)[:12], "lang": lang}
