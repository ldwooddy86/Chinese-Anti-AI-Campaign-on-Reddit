"""Coordination and diffusion structure across the watchlist:

  * link graph — posts joined DIRECTLY by a shared story link, or by near-duplicate text (MinHash/LSH over word
    5-shingles, Jaccard >= 0.6), within 72 h. Signature links are removed first: homepage, profile, messenger-channel,
    donation and link-in-bio links, and any link a source repeats across three or more of its own posts. So are the
    boilerplate lines a channel appends to every post. Either would otherwise chain a channel's whole output into one
    cluster (a single promo or donation link was joining 400+ unrelated posts).
  * echo clusters — connected components of that graph, for display; a component that still exceeds max_size is
    treated as a chaining artefact and dissolved
  * diffusion features for the model — echo (other sources), cross-country and platforms-seen — counted over DIRECT
    neighbours only, so a chain A~B~C does not credit A with C
  * coordinated link sharing — pairs of sources that repeatedly share the same URL within a short window, with the
    window estimated from the corpus (fastest decile of inter-share gaps, as in CooRnet; Giglietto et al. 2020)
  * aggregator provenance — which upstream channels the laundering aggregators name as their sources
"""
from __future__ import annotations

import hashlib
import math
import re
import urllib.parse
from collections import Counter, defaultdict
from typing import Iterable, Optional

import numpy as np

NUM_PERM, BANDS = 64, 16
ROWS = NUM_PERM // BANDS
_P = np.uint64((1 << 31) - 1)
_A = np.array([int(hashlib.sha1(f"a{i}".encode()).hexdigest()[:7], 16) % ((1 << 31) - 2) + 1 for i in range(NUM_PERM)], dtype=np.uint64)
_B = np.array([int(hashlib.sha1(f"b{i}".encode()).hexdigest()[:7], 16) % ((1 << 31) - 1) for i in range(NUM_PERM)], dtype=np.uint64)

# links that say who posted, not what was shared
MESSENGER_HOSTS = {"t.me", "telegram.me", "telegram.dog", "max.ru", "eitaa.com", "rubika.ir", "ble.ir", "wa.me", "whatsapp.com"}
PROMO_HOSTS = {"qr.nspk.ru", "boosty.to", "donationalerts.com", "patreon.com", "yoomoney.ru", "tribute.tg", "cloudtips.ru", "linktr.ee", "taplink.cc",
               "ko-fi.com", "buymeacoffee.com", "paypal.me", "subscribestar.com", "donate.stream", "tgstat.ru", "tgstat.com"}
PROFILE_HOSTS = {"x.com", "twitter.com", "vk.com", "ok.ru", "youtube.com", "facebook.com", "instagram.com", "tiktok.com", "rutube.ru", "dzen.ru", "odysee.com",
                 "rumble.com", "gab.com", "truthsocial.com", "bsky.app", "threads.net", "threads.com", "aparat.com", "weibo.com", "bilibili.com", "douyin.com"}
PROFILE_PREFIX = {"channel", "c", "user", "id", "group", "public", "club", "profile", "u", "people"}
CONTENT_START = ("wall", "video", "clip", "photo", "watch", "shorts", "reel", "status", "post")


def _host_segs(u: str) -> tuple[str, list[str], str]:
    try:
        s = urllib.parse.urlsplit(u)
    except ValueError:
        return "", [], ""
    h = (s.hostname or "").lower()
    for pre in ("www.", "m."):
        if h.startswith(pre):
            h = h[len(pre):]
    return h, [x for x in s.path.split("/") if x], s.query


def _under(h: str, hosts: set[str]) -> bool:
    return h in hosts or any(h.endswith("." + x) for x in hosts)


def is_signature(u: str) -> bool:
    """Homepage, profile, messenger-channel, donation and link-in-bio links."""
    h, segs, q = _host_segs(u)
    if not h or _under(h, MESSENGER_HOSTS) or _under(h, PROMO_HOSTS):
        return True
    if not segs and not q:
        return True
    if _under(h, PROFILE_HOSTS) and not q:
        first = segs[0].lower()
        if len(segs) == 1 and "." not in first and not first.startswith(CONTENT_START):
            return True
        if len(segs) == 2 and first in PROFILE_PREFIX:
            return True
    return False


def signature_links(posts: Iterable[dict], min_repeats: int = 3) -> set[str]:
    """Links some source repeats across min_repeats or more of its own posts: its footer, promo or donation link."""
    per: Counter = Counter()
    for p in posts:
        for u in set(p.get("urls") or []):
            per[(p["source_id"], u)] += 1
    return {u for (_, u), n in per.items() if n >= min_repeats}


def _norm_line(line: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"https?://\S+|[@#]\w+", " ", line)).strip().lower()


def boilerplate(posts: Iterable[dict], min_repeats: int = 3) -> dict[str, set[str]]:
    """source id → the lines it repeats across min_repeats or more of its posts (subscribe / support / footer lines)."""
    per: Counter = Counter()
    for p in posts:
        for ln in {_norm_line(x) for x in (p.get("text") or "").splitlines()}:
            if len(ln) >= 6:
                per[(p["source_id"], ln)] += 1
    out: dict[str, set[str]] = defaultdict(set)
    for (s, ln), n in per.items():
        if n >= min_repeats:
            out[s].add(ln)
    return dict(out)


def content_text(p: dict, boiler: Optional[set[str]] = None) -> str:
    lines = [(p.get("title") or "")] + (p.get("text") or "").splitlines()
    keep = [_norm_line(x) for x in lines]
    return " ".join(x for x in keep if x and x not in (boiler or ()))


def _shingles(text: str, k: int = 5) -> np.ndarray:
    words = re.findall(r"\w+", (text or "").lower())
    if not words:
        return np.zeros(0, dtype=np.uint64)
    grams = [" ".join(words)] if len(words) < k else {" ".join(words[i:i + k]) for i in range(len(words) - k + 1)}
    return np.array([int.from_bytes(hashlib.blake2b(g.encode(), digest_size=4).digest(), "little") % ((1 << 31) - 1) for g in grams], dtype=np.uint64)


def minhash(text: str) -> tuple[int, ...]:
    """64-permutation MinHash with universal hashing mod the Mersenne prime 2^31-1 (products stay inside uint64)."""
    sh = _shingles(text)
    if sh.size == 0:
        return tuple()
    return tuple(int(v) for v in ((_A[:, None] * sh[None, :] + _B[:, None]) % _P).min(axis=1))


def jaccard_est(m1: tuple, m2: tuple) -> float:
    if not m1 or not m2:
        return 0.0
    return sum(1 for a, b in zip(m1, m2) if a == b) / len(m1)


class UnionFind:
    def __init__(self):
        self.p: dict[str, str] = {}

    def find(self, x: str) -> str:
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[max(ra, rb)] = min(ra, rb)


def link_graph(posts: list[dict], window_h: int = 72, min_jacc: float = 0.6, max_bucket: int = 200) -> dict:
    """Direct links between posts: a shared story link (signature links removed) or near-duplicate text (boilerplate
    removed), inside the window. Returns {adj: {post id: set(post ids)}, stats...}."""
    W = window_h * 3600
    sig = signature_links(posts)
    boiler = boilerplate(posts)
    adj: dict[str, set[str]] = defaultdict(set)
    by_url: dict[str, list[dict]] = defaultdict(list)
    for p in posts:
        for u in set(p.get("urls") or []):
            if u in sig or is_signature(u):
                continue
            by_url[u].append(p)
    url_edges = 0
    for ps in by_url.values():
        if len(ps) < 2:
            continue
        ps.sort(key=lambda x: x["ts"])
        for i in range(len(ps)):
            for j in range(i + 1, len(ps)):
                if ps[j]["ts"] - ps[i]["ts"] > W:
                    break
                a, b = ps[i]["id"], ps[j]["id"]
                if a != b and b not in adj[a]:
                    adj[a].add(b); adj[b].add(a); url_edges += 1
    sigs: dict[str, tuple] = {}
    buckets: dict[tuple, list[str]] = defaultdict(list)
    for p in posts:
        txt = content_text(p, boiler.get(p["source_id"]))
        if len(txt) < 60:
            continue
        m = minhash(txt)
        if not m:
            continue
        sigs[p["id"]] = (m, p["ts"])
        for b in range(BANDS):
            buckets[(b,) + m[b * ROWS:(b + 1) * ROWS]].append(p["id"])
    checked: set[tuple[str, str]] = set()
    text_edges = oversized = 0
    for ids in buckets.values():
        if len(ids) < 2:
            continue
        if len(ids) > max_bucket:          # a bucket this full is boilerplate the per-source filter missed
            oversized += 1; continue
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                a, b = ids[i], ids[j]
                key = (a, b) if a < b else (b, a)
                if a == b or key in checked:
                    continue
                checked.add(key)
                (ma, ta), (mb, tb) = sigs[a], sigs[b]
                if abs(ta - tb) <= W and jaccard_est(ma, mb) >= min_jacc and b not in adj[a]:
                    adj[a].add(b); adj[b].add(a); text_edges += 1
    return {"adj": dict(adj), "signature_links": len(sig), "boilerplate_sources": len(boiler), "url_edges": url_edges, "text_edges": text_edges,
            "oversized_buckets": oversized, "dissolved": 0}


def clusters(posts: list[dict], window_h: int = 72, min_jacc: float = 0.6, graph: Optional[dict] = None, max_size: int = 250) -> dict[str, str]:
    """post id → cluster id: connected components of the link graph. A component larger than max_size is a chaining
    artefact, not a story, and its posts are left unclustered (their direct-neighbour diffusion features are unaffected)."""
    g = graph if graph is not None else link_graph(posts, window_h, min_jacc)
    uf = UnionFind()
    for p in posts:
        uf.find(p["id"])
    for a, ns in g["adj"].items():
        for b in ns:
            uf.union(a, b)
    cmap = {p["id"]: uf.find(p["id"]) for p in posts}
    size = Counter(cmap.values())
    big = {c for c, n in size.items() if n > max_size}
    if big:
        g["dissolved"] = sum(size[c] for c in big)
        cmap = {pid: (pid if c in big else c) for pid, c in cmap.items()}
    return cmap


def diffusion_features(posts: list[dict], cmap: dict[str, str], echo_h: int = 24, cross_h: int = 48, graph: Optional[dict] = None) -> dict[str, dict]:
    """Per post, over its direct neighbours: echo (log1p other sources within echo_h), cross_country (0/1, within cross_h),
    platforms_seen (extra platforms, cap 4); plus the display cluster's size."""
    g = graph if graph is not None else link_graph(posts)
    adj = g["adj"]
    by_id = {p["id"]: p for p in posts}
    size = Counter(cmap.values())
    out = {}
    for p in posts:
        nb = [by_id[q] for q in adj.get(p["id"], ()) if q in by_id]
        srcs = {q["source_id"] for q in nb if q["source_id"] != p["source_id"] and abs(q["ts"] - p["ts"]) <= echo_h * 3600}
        cc = {c for c in ({q.get("country") for q in nb if abs(q["ts"] - p["ts"]) <= cross_h * 3600} | {p.get("country")}) if c}
        plats = {x for x in ({q.get("platform") for q in nb} | {p.get("platform")}) if x}
        out[p["id"]] = {"echo": math.log1p(len(srcs)), "echo_sources": len(srcs), "cross_country": 1.0 if len(cc) >= 2 else 0.0,
                        "platforms_seen": float(min(4, max(0, len(plats) - 1))), "cluster_size": size.get(cmap.get(p["id"], p["id"]), 1),
                        "cluster_countries": sorted(cc)}
    return out


def coordinated_link_sharing(posts: list[dict], min_repeats: int = 3, min_window_s: int = 60, max_window_s: int = 3600) -> dict:
    """CooRnet-style: estimate the 'rapid share' window as the 10th percentile of first-to-next share gaps per URL,
    then connect source pairs that co-share >= min_repeats distinct URLs inside it. Own-outlet links and signature links
    are excluded (an outlet's accounts linking its own site, or a channel's footer, is expected behaviour, not coordination)."""
    sig = signature_links(posts)
    by_url: dict[str, list[tuple[int, str, str]]] = defaultdict(list)
    for p in posts:
        own = set(p.get("own_domains") or [])
        for u in set(p.get("urls") or []):
            if u in sig or is_signature(u):
                continue
            dom = _host_segs(u)[0]
            if any(dom == d or dom.endswith("." + d) for d in own):
                continue
            by_url[u].append((p["ts"], p["source_id"], p.get("country") or ""))
    gaps = []
    for shares in by_url.values():
        if len(shares) < 2:
            continue
        shares.sort()
        gaps.extend(b[0] - a[0] for a, b in zip(shares, shares[1:]) if b[1] != a[1])
    if not gaps:
        return {"window_s": None, "edges": [], "networks": [], "urls_considered": len(by_url)}
    gaps.sort()
    window = max(min_window_s, min(max_window_s, gaps[max(0, int(0.1 * len(gaps)) - 1)]))
    pair_urls: dict[tuple[str, str], set] = defaultdict(set)
    for u, shares in by_url.items():
        shares.sort()
        for i in range(len(shares)):
            for j in range(i + 1, len(shares)):
                if shares[j][0] - shares[i][0] > window:
                    break
                a, b = sorted((shares[i][1], shares[j][1]))
                if a != b:
                    pair_urls[(a, b)].add(u)
    edges = [{"a": a, "b": b, "urls": len(us)} for (a, b), us in pair_urls.items() if len(us) >= min_repeats]
    uf = UnionFind()
    for e in edges:
        uf.union(e["a"], e["b"])
    comps: dict[str, set] = defaultdict(set)
    for e in edges:
        comps[uf.find(e["a"])].update((e["a"], e["b"]))
    nets = sorted(({"sources": sorted(s), "size": len(s)} for s in comps.values()), key=lambda d: -d["size"])
    return {"window_s": window, "edges": sorted(edges, key=lambda e: -e["urls"])[:300], "networks": nets[:50], "urls_considered": len(by_url)}


def provenance_graph(posts: Iterable[dict], known: set[str]) -> list[dict]:
    """Aggregator -> upstream channel counts. 'known' marks upstreams that are themselves watchlist sources;
    others are shown as 'not attributed' — appearing as an upstream is not evidence of state affiliation."""
    c: Counter = Counter()
    for p in posts:
        for u in p.get("upstream") or []:
            c[(p["source_id"], u.lower())] += 1
    return [{"aggregator": a, "upstream": u, "items": n, "watchlisted": ("telegram:" + u) in known} for (a, u), n in c.most_common(300)]
