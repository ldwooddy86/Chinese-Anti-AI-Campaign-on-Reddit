"""Country gazetteer for the Hamilton-style 'Top countries' panel: canonical name -> aliases (English + RU/ZH/FA for the
three principals' own languages on the largest entries). Special entities (EU, NATO, Gaza, Hong Kong, Taiwan) are kept
separate, as Hamilton does. Known ambiguity: 'Georgia' collides with the US state; the matcher drops it when a US anchor
and a US-state context word co-occur."""
from __future__ import annotations

import re
from functools import lru_cache

COUNTRIES: dict[str, list[str]] = {
    "United States": ["united states", "u.s.", "usa", "america", "american", "washington", "сша!", "америк", "美国", "آمریکا", "امریکا"],
    "Russia": ["russia", "russian", "moscow", "kremlin", "россия", "российск", "москв", "кремл", "俄罗斯", "俄方", "روسیه"],
    "China": ["china", "chinese", "beijing", "prc", "китай", "китайск", "пекин", "中国", "中方", "北京", "چین"],
    "Iran": ["iran", "iranian", "tehran", "иран", "тегеран", "伊朗", "ایران", "تهران"],
    "Ukraine": ["ukraine", "ukrainian", "kyiv", "kiev", "украин", "киев", "乌克兰", "اوکراین"],
    "Israel": ["israel", "israeli", "tel aviv", "израил", "以色列", "اسرائیل", "رژیم صهیونیستی"],
    "Palestine/Gaza": ["gaza", "palestine", "palestinian", "west bank", "газа", "палестин", "加沙", "巴勒斯坦", "غزه", "فلسطین"],
    "Lebanon": ["lebanon", "lebanese", "beirut", "hezbollah", "ливан", "黎巴嫩", "لبنان"],
    "Syria": ["syria", "syrian", "damascus", "сири", "叙利亚", "سوریه"],
    "Iraq": ["iraq", "iraqi", "baghdad", "ирак", "伊拉克", "عراق"],
    "Yemen": ["yemen", "yemeni", "houthi", "ansarallah", "йемен", "хусит", "也门", "یمن"],
    "Saudi Arabia": ["saudi", "riyadh", "саудовск", "沙特", "عربستان"],
    "United Arab Emirates": ["uae", "emirates", "abu dhabi", "dubai", "оаэ", "阿联酋", "امارات"],
    "Qatar": ["qatar", "doha", "катар", "卡塔尔", "قطر"],
    "Bahrain": ["bahrain", "бахрейн", "巴林", "بحرین"],
    "Kuwait": ["kuwait", "кувейт", "科威特", "کویت"],
    "Oman": ["oman", "muscat", "оман", "阿曼", "عمان"],
    "Turkey": ["turkey", "türkiye", "turkish", "ankara", "erdogan", "турци", "土耳其", "ترکیه"],
    "Egypt": ["egypt", "cairo", "египет", "埃及", "مصر"],
    "Jordan": ["jordan", "amman", "иордан", "约旦", "اردن"],
    "Afghanistan": ["afghanistan", "taliban", "kabul", "афганистан", "阿富汗", "افغانستان"],
    "Pakistan": ["pakistan", "islamabad", "пакистан", "巴基斯坦", "پاکستان"],
    "India": ["india", "indian", "new delhi", "modi", "индия", "индии", "индией", "индийск", "印度", "هند"],
    "Taiwan": ["taiwan", "taipei", "тайван", "台湾", "تایوان"],
    "Hong Kong": ["hong kong", "гонконг", "香港"],
    "Japan": ["japan", "japanese", "tokyo", "япони", "日本", "ژاپن"],
    "South Korea": ["south korea", "seoul", "южная корея", "южной коре", "韩国", "کره جنوبی"],
    "North Korea": ["north korea", "dprk", "pyongyang", "кндр!", "朝鲜", "کره شمالی"],
    "Philippines": ["philippines", "manila", "филиппин", "菲律宾", "فیلیپین"],
    "Vietnam": ["vietnam", "hanoi", "вьетнам", "越南", "ویتنام"],
    "Indonesia": ["indonesia", "jakarta", "индонез", "印度尼西亚", "اندونزی"],
    "Australia": ["australia", "canberra", "австрали", "澳大利亚", "استرالیا"],
    "United Kingdom": ["united kingdom", "britain", "british", "london", "великобритан", "британ", "лондон", "英国", "انگلیس", "بریتانیا"],
    "France": ["france", "french", "paris", "macron", "франци", "法国", "فرانسه"],
    "Germany": ["germany", "german", "berlin", "германи", "德国", "آلمان"],
    "Italy": ["italy", "italian", "rome", "итали", "意大利", "ایتالیا"],
    "Spain": ["spain", "spanish", "madrid", "испани", "西班牙", "اسپانیا"],
    "Poland": ["poland", "polish", "warsaw", "польш", "波兰", "لهستان"],
    "Hungary": ["hungary", "budapest", "orban", "венгри", "匈牙利", "مجارستان"],
    "Romania": ["romania", "bucharest", "румыни", "罗马尼亚", "رومانی"],
    "Moldova": ["moldova", "chisinau", "молдав", "摩尔多瓦", "مولداوی"],
    "Georgia": ["georgia", "tbilisi", "грузи", "格鲁吉亚", "گرجستان"],
    "Armenia": ["armenia", "yerevan", "армени", "亚美尼亚", "ارمنستان"],
    "Azerbaijan": ["azerbaijan", "baku", "азербайджан", "阿塞拜疆", "آذربایجان"],
    "Belarus": ["belarus", "minsk", "lukashenko", "беларус", "белорус", "白俄罗斯", "بلاروس"],
    "Kazakhstan": ["kazakhstan", "astana", "казахстан", "哈萨克斯坦", "قزاقستان"],
    "Finland": ["finland", "helsinki", "финлянд", "芬兰", "فنلاند"],
    "Sweden": ["sweden", "stockholm", "швеци", "瑞典", "سوئد"],
    "Norway": ["norway", "oslo", "норвеги", "挪威", "نروژ"],
    "Denmark/Greenland": ["denmark", "copenhagen", "greenland", "дани", "гренланд", "丹麦", "格陵兰", "دانمارک", "گرینلند"],
    "Estonia": ["estonia", "tallinn", "эстони", "爱沙尼亚", "استونی"],
    "Latvia": ["latvia", "riga", "латви", "拉脱维亚", "لتونی"],
    "Lithuania": ["lithuania", "vilnius", "литв", "立陶宛", "لیتوانی"],
    "Serbia": ["serbia", "belgrade", "серби", "塞尔维亚", "صربستان"],
    "Netherlands": ["netherlands", "dutch", "amsterdam", "the hague", "нидерланд", "荷兰", "هلند"],
    "Belgium": ["belgium", "brussels", "бельги", "比利时", "بلژیک"],
    "Canada": ["canada", "canadian", "ottawa", "канад", "加拿大", "کانادا"],
    "Mexico": ["mexico", "mexican", "мексик", "墨西哥", "مکزیک"],
    "Venezuela": ["venezuela", "caracas", "maduro", "венесуэл", "委内瑞拉", "ونزوئلا"],
    "Cuba": ["cuba", "havana", "куба!", "кубы!", "кубе!", "кубу!", "кубинск", "古巴", "کوبا"],
    "Brazil": ["brazil", "brasilia", "lula", "бразили", "巴西", "برزیل"],
    "Argentina": ["argentina", "buenos aires", "milei", "аргентин", "阿根廷", "آرژانتین"],
    "Colombia": ["colombia", "bogota", "колумби", "哥伦比亚", "کلمبیا"],
    "Nicaragua": ["nicaragua", "managua", "никарагу", "尼加拉瓜", "نیکاراگوئه"],
    "Nigeria": ["nigeria", "abuja", "нигери", "尼日利亚", "نیجریه"],
    "South Africa": ["south africa", "pretoria", "юар!", "南非", "آفریقای جنوبی"],
    "Ethiopia": ["ethiopia", "addis ababa", "эфиопи", "埃塞俄比亚", "اتیوپی"],
    "Sudan": ["sudan", "khartoum", "судан", "苏丹", "سودان"],
    "Libya": ["libya", "tripoli", "ливи", "利比亚", "لیبی"],
    "Mali": ["mali", "bamako", "мали!", "马里", "مالی"],
    "Niger": ["niger", "niamey", "нигер!", "尼日尔", "نیجر"],
    "Burkina Faso": ["burkina faso", "ouagadougou", "буркина", "布基纳法索", "بورکینافاسو"],
    "Serbia/Kosovo": ["kosovo", "косово", "科索沃", "کوزوو"],
    "European Union": ["european union", "eu", "brussels", "евросоюз", "ес!", "евросоюз", "европейск союз", "欧盟", "اتحادیه اروپا"],
    "NATO": ["nato", "нато", "北约", "ناتو"],
    "United Nations": ["united nations", "un", "unga", "security council", "оон!", "联合国", "سازمان ملل"],
}


@lru_cache(maxsize=1)
def _matcher():
    from .lexicon import PhraseMatcher
    terms = {}
    for name, aliases in COUNTRIES.items():
        out = []
        for a in aliases:
            a = a.strip()
            if not a:
                continue
            # Latin aliases match whole words, with simple plural/demonym variants; other scripts match as stems
            if re.match(r"^[a-z .'-]+$", a):
                out += [a, a + "s"] if not a.endswith("s") else [a]
            else:
                out.append(a)
        terms[name] = out
    return PhraseMatcher(terms)


US_STATE_CTX = re.compile(r"\b(atlanta|savannah|georgia state|georgia's governor|kemp|warnock|ossoff|georgia republicans|georgia democrats|peach state|fulton county)\b", re.I)


def countries_in(text: str) -> list[str]:
    seen, hits = set(), []
    for name, _, _ in sorted(_matcher().spans(text or ""), key=lambda t: t[1]):
        if name not in seen:
            seen.add(name); hits.append(name)
    if "Georgia" in hits and US_STATE_CTX.search(text or ""):
        hits.remove("Georgia")
    return hits
