"""GHOST LOOM bridge: code watchlist posts for GHOST LOOM's eight anti-AI seams behind an AI gate, in English, Russian,
Persian and Chinese, and write the compact pack that GHOST LOOM's PUBLIUS tab loads.

A code says a post raised a topic, never which side it took. As in DALABA, a seam needs its AI or data-center term and
its grievance term inside a short window of text, so a post that names AI in one paragraph and electricity bills in
another is not a hit. Every pattern runs on every post whatever its detected language, because state channels mix
scripts (a Persian post that says 'AI' in Latin letters, a Russian post quoting an English headline).

The pack carries only what the real collection shows. An exercise snapshot's simulated lanes, indicator counts,
labels, calibration and the breakout scores of measured posts are left out; the analyst brief it carries is the one
computed before any simulated input. Posts by sources whose affiliation is unverified count in the totals but are never
listed, and listed items name only the watchlisted outlet or office that published them."""
from __future__ import annotations

import json
import re
import time
import unicodedata
from collections import Counter, defaultdict
from typing import Callable, Iterable, Optional

VERSION = "gl-2026.09e"
SEAMS = ("DC", "MIL", "BUB", "TRUST", "JOBS", "ART", "DOOM", "BOY")
LABELS = {
    "DC": "Data centers drain power, water and wallets",
    "MIL": "AI is a war and surveillance machine",
    "BUB": "AI is a bubble and the US will pay for it",
    "TRUST": "Western AI is biased, captured or unsafe",
    "JOBS": "AI is taking jobs and livelihoods",
    "ART": "AI art is theft and slop is flooding the internet",
    "DOOM": "AI could end humanity",
    "BOY": "Boycott and reject AI",
}

# ------------------------------------------------------------------------------------------------ building blocks
# English and Chinese follow DALABA 2.0's codebook (sv6) so the two tools count the same way.
# 'AI' only in capitals: lower-case 'ai' is a word in French (j'ai), Italian and Portuguese, and 'a.i.' is 'ad interim'.
# Dotted initials before a name ('A.I. Studennikov') are not AI.
_AI = (r"(?:(?-i:(?<![A-Za-z0-9'’])(?:AIs?(?![A-Za-z0-9])|A\.I\.(?!\s?[A-ZА-ЯЁ\u3040-\u30ff\u4e00-\u9fff])))"
       r"|(?<![a-z0-9])#ai\b|artificial intelligence)")
_AIZ = r"(?:人工智能|(?<![a-z])ai(?![a-z])|大模型)"
_DC = r"data ?cent(?:er|re)s?"
# Russian: 'ИИ' only in capitals and as a whole word (lower-case 'ии' ends thousands of nouns); 'нейросеть' is the everyday
# word for a generative model.
_AIR = r"(?:(?-i:(?<![А-Яа-яЁё])ИИ(?![А-Яа-яЁё]))|искусственн\w{0,4} интеллект\w{0,3}|нейросет\w*|нейронн\w{0,3} сет\w*)"
_DCR = r"(?:дата[\s-]?центр\w*|центр\w{0,3} обработки данных|(?<![а-яё])цод(?:а|у|ом|е|ы|ов|ам|ами|ах)?(?![а-яё]))"
# Persian: word edges are written out because Arabic-script letters are not separated by \b the way the stems need.
_B, _E = r"(?<![؀-ۿ])", r"(?![؀-ۿ])"
_Z = r"[\s‌]*"                     # optional space or zero-width non-joiner inside compounds
_AIF = r"(?:هوش" + _Z + r"مصنوعی)"
_DCF = r"(?:" + _B + r"(?:مرکز|مراکز)" + _Z + r"داده|دیتا" + _Z + r"سنتر)"
# Words that must stand alone in Persian: 'آب' (water) sits inside hundreds of words, 'برق' (power) inside 'برقرار'.
_WATER_F = _B + r"آب" + _E
_POWER_F = _B + r"برق" + _E
# Korean (2.0): KCNA and Rodong write in the Northern register (로보트, 로동자, 자료쎈터 alongside 데이터센터); 'AI' in capitals is
# caught by _AI because Hangul is not a Latin letter. Substrings, as for Chinese: Korean particles attach to the noun.
_AIK = r"(?:인공지능|인공지성|기계학습|심층학습|대형언어모델|생성형|(?-i:(?<![A-Za-z0-9])AI(?![A-Za-z0-9])))"
_DCK = r"(?:데이터센터|데이터쎈터|자료쎈터|자료센터|자료중심)"

CODEBOOK = {
    "version": VERSION,
    "note": "Topic detectors for GHOST LOOM's eight seams. A hit says a post raised the topic, never which side it took.",
    "gate": [
        _AI,
        r"\b(?:machine learning|deep learning|neural networks?|large (?:language )?models?|llms?|foundation models?|generative"
        r"|chatbots?|chatgpt|openai|anthropic|deepseek|qwen|kimi|doubao|ernie bot|hunyuan|agi|superintelligence|algorithms?|palantir|anduril"
        r"|computing power|semiconductors?|gpus?|nvidia|huawei ascend|robot(?:s|ics)?|humanoids?|deepfakes?|voice[\s-]clon\w+"
        r"|synthetic media|intelligent computing|smart manufacturing)\b",
        r"(?<!bargaining )(?<!blue )(?<!blue-)(?<!fish and )(?<!fish & )\b(?:chips?|chipmakers?)\b(?! in\b)(?!\s+shops?\b)",
        _DC,
        r"人工智能|大模型|算力|数据中心|芯片|半导体|英伟达|深度求索|通义千问|豆包|文心一言|智能体|机器人|具身智能|生成式|智算|深度伪造",
        _AIR, _DCR,
        r"машинн\w* обучени\w*|больш\w{0,3} языков\w{0,3} модел\w*|чат-?бот\w*|полупроводник\w*|микрочип\w*|(?<![а-яё])чип(?:ы|ов|ами|ах)?(?![а-яё])"
        r"|дипфейк\w*|суперкомпьютер\w*|(?<![а-яё])робот\w*",
        _AIF, _DCF,
        r"یادگیری" + _Z + r"ماشین|مدل" + _Z + r"(?:های" + _Z + r")?زبانی|چت" + _Z + r"بات|چت" + _Z + r"جی" + _Z + r"پی" + _Z + r"تی|دیپ" + _Z + r"فیک"
        r"|" + _B + r"تراشه|نیمه" + _Z + r"(?:هادی|رسانا)|انویدیا|رباتیک|ربات" + _Z + r"(?:های" + _Z + r")?انسان" + _Z + r"نما|الگوریتم",
        _AIK, _DCK,
        r"신경망|챗봇|챗GPT|오픈AI|딥시크|반도체|첨단칩|엔비디아|로보트|휴머노이드|딥페이크|연산능력|계산능력|초지능|알고리듬|알고리즘",
    ],
    "seams": {
        "DC": [
            _DC + r".{0,80}\b(?:electric(?:ity|al)?\\b(?!\\s+(?:vehicles?|cars?|buses|trucks|motors?|mobility))|power|grid|water|energy|bills?|utilit\w*|rates|emissions|carbon|noise|land|farmland|protest\w*|opposition"
                  r"|backlash|resist\w*)\b",
            r"\b(?:electric(?:ity|al)?\\b(?!\\s+(?:vehicles?|cars?|buses|trucks|motors?|mobility))|power|grid|energy|water|utility|utilities|protests?|opposition|backlash|residents|moratorium)\b.{0,80}" + _DC,
            _AI + r".{0,60}\b(?:electricity|power|energy|grid)\b.{0,40}\b(?:squeeze|shortage|strain\w*|crunch|bills?|prices?|costs?|demand|crisis)\b",
            r"\bpjm\b|\bcapacity auction\b",
            r"数据中心.{0,30}(?:电|水|能耗|排放|居民)|(?:电价|电费|电网|用电|缺电|电力).{0,30}(?:数据中心|人工智能|ai)|算力.{0,20}(?:耗电|能耗)",
            _DCR + r".{0,80}(?:(?<![а-яё])электр\w*|(?<![а-яё])энерг\w*|электросет\w*|(?<![а-яё])вод(?:а|ы|у|ой|е|ные|ных|оснабжени\w*|опотреблени\w*)(?![а-яё])"
                   r"|тариф\w*|счет(?:а|ов)? за|протест\w*|жител\w*|(?<![а-яё])земл\w*|выброс\w*)",
            r"(?:(?<![а-яё])электр\w*|(?<![а-яё])энерг\w*|протест\w*|жител\w*|мораторий\w*).{0,80}" + _DCR,
            _AIR + r".{0,60}(?:электроэнерги\w*|(?<![а-яё])энерги\w*|электросет\w*|энергосистем\w*).{0,40}(?:дефицит\w*|нехватк\w*|нагрузк\w*|цен\w*|тариф\w*|кризис\w*|спрос\w*)",
            _DCF + r".{0,80}(?:" + _POWER_F + r"|" + _WATER_F + r"|انرژی|آلودگی|مصرف|قبض|اعتراض|ساکنان|محیط" + _Z + r"زیست)",
            r"(?:" + _POWER_F + r"|" + _WATER_F + r"|انرژی|اعتراض|ساکنان).{0,80}" + _DCF,
            _AIF + r".{0,60}(?:" + _POWER_F + r"|انرژی).{0,40}(?:کمبود|بحران|فشار|مصرف|قیمت|تقاضا)",
            _DCK + r".{0,40}(?:전력|전기|용수|물|에네르기|에너지|주민|반대|항의|배출)|(?:전력|전기|에네르기|에너지|주민|항의).{0,40}" + _DCK,
            _AIK + r".{0,40}(?:전력|전기).{0,30}(?:부족|위기|료금|요금|수요)",
        ],
        "MIL": [
            _AI + r".{0,50}\b(?:military|militar\w+|weapon\w*|warfare|battlefield|targeting (?:systems?|software|data|decisions?)|kill chains?|lethal"
                  r"|surveillance|pentagon|drones?|killing|arms race)\b",
            r"\b(?:military|missile|air)? ?strikes?\b.{0,40}" + _DC + r"|" + _DC + r".{0,40}\b(?:military|strikes?|legitimate target|attack\w*)\b",
            r"\b(?:attacks?|drone strikes?|missile strikes?) (?:on|against|at) (?:\w+ ){0,3}" + _DC,
            r"\b(?:military|pentagon|weaponi[sz]\w*|warfare|arms race)\b.{0,50}" + _AI,
            r"\bpalantir\b|\bproject (?:nimbus|maven)\b|палантир\w*|پالانتیر",
            _AIZ + r".{0,20}(?:军事|武器|战争|战场|五角大楼|(?:大规模|全面|算法|智能|人脸识别|ai)监控|监控(?:系统|网络|技术|社会|国家|平台)"
                   r"|(?:军用|作战|攻击|自杀式)无人机|无人机(?:作战|攻击|袭击|蜂群))|(?:军事|武器化|五角大楼).{0,20}" + _AIZ + r"|军备竞赛",
            _AIR + r".{0,50}(?:военн\w*|оружи\w*|вооружени\w*|(?<![а-яё])арми\w*|боев\w*|пол\w{0,3} боя|целеуказани\w*|наведени\w*|летальн\w*|слежк\w*"
                   r"|наблюдени\w*|разведк\w*|пентагон\w*|беспилот\w*|(?<![а-яё])дрон\w*|убийств\w*|гонк\w* вооружений)",
            r"(?:военн\w*|пентагон\w*|гонк\w* вооружений|милитаризаци\w*).{0,50}" + _AIR,
            _DCR + r".{0,40}(?:военн\w*|(?<![а-яё])удар\w*|(?<![а-яё])цел(?:ь|и|ью|ей|ям|ях)(?![а-яё])|атак\w*)|(?:(?<![а-яё])удар\w*|атак\w*|военн\w*).{0,40}" + _DCR,
            _AIF + r".{0,50}(?:نظامی|" + _B + r"جنگ|تسلیحات|" + _B + r"سلاح|پهپاد|هدف" + _Z + r"گیری|جاسوسی|نظارت|کشتار|میدان" + _Z + r"نبرد|پنتاگون|ارتش)",
            r"(?:نظامی|ارتش|پنتاگون|" + _B + r"جنگ" + _E + r").{0,50}" + _AIF,
            _DCF + r".{0,40}(?:حمله|" + _B + r"هدف|نظامی|موشک)|(?:حمله|موشک|" + _B + r"هدف" + _E + r").{0,40}" + _DCF,
            _AIK + r".{0,30}(?:군사|무기|전쟁|살인|살륙|감시|표적|무인기|드론|군비경쟁|국방성|펜타곤|살인무기)|(?:군사|무기화|군비경쟁|국방성|펜타곤).{0,30}" + _AIK,
        ],
        "BUB": [
            r"\bai bubble\b|\bai boom\b.{0,40}\b(?:fails?|hollow|illusion|mirage|bust)\b",
            r"\bbubble\b.{0,60}(?:" + _AI + r"|\btech\b|\bnvidia\b|" + _DC + r")",
            _AI + r".{0,60}\b(?:bubble|overhyped|hype|overinvest\w*|unsustainable|burn\w* cash|circular (?:deals|financing))\b",
            r"(?:人工智能|ai|大模型|英伟达|科技股|算力).{0,20}泡沫|泡沫.{0,20}(?:人工智能|ai|科技|英伟达)",
            r"пузыр\w*.{0,60}(?:" + _AIR + r"|nvidia|технолог\w*|техсектор\w*|" + _DCR + r")|(?:" + _AIR + r"|nvidia).{0,60}пузыр\w*",
            r"حباب.{0,40}(?:" + _AIF + r"|فناوری|انویدیا)|(?:" + _AIF + r"|انویدیا).{0,40}حباب",
            r"(?:" + _AIK + r"|엔비디아).{0,30}거품|거품.{0,30}(?:" + _AIK + r"|엔비디아)",
        ],
        "TRUST": [
            r"\b(?:chatgpt|openai|gemini|claude|copilot|grok|western ai|us ai|american ai|silicon valley)\b.{0,60}"
            r"\b(?:propaganda|bias\w*|censor\w*|spy\w*|surveillance|leak\w*|compromised|privacy|misinformation|disinformation|hallucinat\w*|unsafe"
            r"|monopol\w*|breach\w*|hack\w*|infiltrat\w*|unauthori[sz]ed access|rogue)\b",
            r"(?:" + _AI + r"|\btech) (?:owners|companies|firms|giants|oligarchs|billionaires|barons)\b.{0,40}\bconcentrat\w*",
            r"(?:chatgpt|openai|美国(?:的)?(?:人工智能|ai)|西方(?:的)?(?:人工智能|ai)).{0,30}(?:偏见|审查|泄露|隐私|监控|虚假信息|垄断|安全隐患)",
            r"(?:chatgpt|openai|anthropic|gemini|grok|американск\w* (?:" + _AIR + r")|западн\w* (?:" + _AIR + r")|кремниев\w* долин\w*).{0,60}"
            r"(?:пропаганд\w*|цензур\w*|шпион\w*|слежк\w*|утечк\w*|предвзят\w*|дезинформ\w*|галлюцин\w*|опасн\w*|монопол\w*)",
            r"(?:چت" + _Z + r"جی" + _Z + r"پی" + _Z + r"تی|اوپن" + _Z + r"(?:ای" + _Z + r"آی|اِی" + _Z + r"آی)|" + _AIF + _Z + r"(?:آمریکا|آمریکایی|غربی|غرب))"
            r".{0,60}(?:جاسوسی|سانسور|تعصب|سوگیری|صهیونیست|اسرائیل|تبلیغات|اطلاعات" + _Z + r"نادرست|نظارت|حریم" + _Z + r"خصوصی)",
            r"(?:챗GPT|오픈AI|미국(?:의|식)?.{0,6}" + _AIK + r"|서방(?:의)?.{0,6}" + _AIK + r").{0,40}(?:편견|검열|감시|정탐|간첩|사생활|허위|독점|해킹|기만)",
        ],
        "JOBS": [
            r"(?:" + _AI + r"|\bautomation\b|\brobots?\b).{0,60}\b(?:jobs?|employment|unemploy\w*|layoffs?|laid off|workers|livelihoods?|replac\w+)\b",
            r"\b(?:layoffs?|laid off|job (?:losses|cuts))\b.{0,60}(?:" + _AI + r"|\bautomation\b)",
            r"(?:人工智能|ai|自动化|机器人).{0,30}(?:就业|失业|裁员|岗位|取代|替代|饭碗|抢走.{0,4}工作|丢.{0,2}工作)|(?:裁员|失业).{0,30}(?:人工智能|ai)",
            r"(?:" + _AIR + r"|автоматизаци\w*|(?<![а-яё])робот\w*).{0,60}(?:рабоч\w* мест\w*|безработ\w*|увольнени\w*|сокращени\w* (?:штат\w*|рабоч\w*|сотрудник\w*|персонал\w*)"
            r"|замен\w* (?:людей|работник\w*|сотрудник\w*|человек\w*)|лиш\w* работ\w*|потер\w* работ\w*)",
            r"(?:увольнени\w*|безработ\w*|сокращени\w* штат\w*).{0,60}(?:" + _AIR + r"|автоматизаци\w*)",
            r"(?:" + _AIF + r"|اتوماسیون|خودکارسازی|" + _B + r"ربات).{0,60}(?:" + _B + r"شغل|مشاغل|بیکاری|اخراج|کارگران|نیروی" + _Z + r"کار|جایگزین)",
            r"(?:بیکاری|اخراج).{0,60}" + _AIF,
            r"(?:" + _AIK + r"|자동화|로보트|로봇).{0,40}(?:일자리|실업|해고|로동자|노동자|대체|실직)|(?:실업|해고|실직).{0,40}" + _AIK,
        ],
        "ART": [
            r"\bai[\s-]?(?:generated|art|images?|videos?|content)\b.{0,60}\b(?:copyright\w*|theft|infring\w*|artists?|plagiari\w*|slop|label\w*)\b",
            r"\b(?:copyright\w*|artists?)\b.{0,60}" + _AI + r".{0,30}\b(?:train\w*|scrap\w*|theft|infring\w*)\b",
            r"\bai slop\b",
            r"(?:ai|人工智能)(?:生成|绘画|作品).{0,30}(?:版权|侵权|艺术家|标识|抄袭)|版权.{0,20}(?:人工智能|ai|大模型)",
            _AIR + r".{0,60}(?:авторск\w* прав\w*|плагиат\w*|художник\w*|искусств(?!енн)\w*|творчеств\w*|маркировк\w*)",
            r"(?:авторск\w* прав\w*|художник\w*).{0,60}" + _AIR,
            _AIF + r".{0,60}(?:هنرمند|آثار" + _Z + r"هنری|کپی" + _Z + r"رایت|حق" + _Z + r"نشر|سرقت" + _Z + r"ادبی)",
            r"(?:هنرمندان|حق" + _Z + r"نشر).{0,60}" + _AIF,
            _AIK + r".{0,40}(?:저작권|예술가|표절|도용|창작)|(?:저작권|예술가).{0,40}" + _AIK,
        ],
        "DOOM": [
            r"(?:" + _AI + r"|\bagi\b|\bsuperintelligence\b).{0,50}\b(?:extinction|existential|end of humanity|out of (?:human )?control|loss of (?:human )?control"
            r"|doom\w*|catastroph\w*)\b",
            r"\b(?:uncontrolled|unchecked|runaway)\b.{0,40}(?:" + _AI + r"|\bneural networks?\b|\bsuperintelligence\b)",
            r"\b(?:warn\w*|risks?|dangers?)\b.{0,60}\b(?:increasingly )?powerful (?:AI )?systems\b",
            r"\bpause ai\b",
            r"(?:人工智能|ai|超级智能).{0,20}(?:失控|灭绝|生存风险|末日)",
            r"(?:" + _AIR + r"|сверхинтеллект\w*).{0,50}(?:вымирани\w*|уничтож\w* человечеств\w*|гибел\w* человечеств\w*|конец человечеств\w*|экзистенциальн\w*"
            r"|из-под контроля|потер\w* контрол\w*|апокалипсис\w*|бесконтрольн\w*)",
            r"бесконтрольн\w*.{0,40}(?:" + _AIR + r")|(?:угроз\w*|опасност\w*) (?:со стороны )?(?:" + _AIR + r")",
            _AIF + r".{0,50}(?:نابودی" + _Z + r"بشر|انقراض|تهدید" + _Z + r"وجودی|خارج" + _Z + r"از" + _Z + r"کنترل|پایان" + _Z + r"بشریت)",
            r"(?:" + _AIK + r"|초지능).{0,40}(?:인류.{0,6}(?:멸망|종말|위협|파멸)|통제.{0,6}(?:벗어|불능|상실)|존재론적|파국)",
        ],
        "BOY": [
            r"\b(?:boycott\w*|reject\w*)\b.{0,30}(?:" + _AI + r"|\bgenai\b|\bchatgpt\b)",
            r"\banti[\s-]?ai\b",
            r"\b(?:public|workers|artists|residents|consumers)\b.{0,30}\b(?:reject\w*|push\w* back|backlash|revolt)\b.{0,30}" + _AI,
            r"\bbacklash (?:against|to) " + _AI,
            r"抵制.{0,10}(?:人工智能|ai)|反(?:对)?(?:人工智能|ai)",
            r"бойкот\w*.{0,30}" + _AIR + r"|(?:протест\w*|выступ\w*) против (?:" + _AIR + r")",
            r"(?:بایکوت|تحریم" + _Z + r"استفاده" + _Z + r"از).{0,20}" + _AIF,
            r"(?:배격|거부|보이코트|반대).{0,20}" + _AIK + r"|반인공지능",
        ],
    },
}

_TR = str.maketrans({"ё": "е", "Ё": "Е", "ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "ه", "’": "'", "‘": "'"})


def _compile(rx: Iterable[str]) -> "re.Pattern":
    return re.compile("|".join(f"(?:{p})" for p in rx), re.I | re.S)


def norm(text: str) -> str:
    t = unicodedata.normalize("NFKC", text or "").translate(_TR)
    t = re.sub("[‐-―−]", "-", t)
    return re.sub(r"[ \t\r\f\v]+", " ", t)


def _snip(t: str, m: "re.Match", pad: int = 40) -> str:
    a, b = max(0, m.start() - pad), min(len(t), m.end() + pad)
    return ("…" if a else "") + re.sub(r"\s+", " ", t[a:b]).strip() + ("…" if b < len(t) else "")


class Coder:
    def __init__(self, book: Optional[dict] = None):
        self.book = book or CODEBOOK
        self.version = self.book["version"]
        self.gate = _compile(self.book["gate"])
        self.seams = {k: _compile(v) for k, v in self.book["seams"].items()}

    def code(self, *parts: str) -> dict:
        t = norm(" \n ".join(p for p in parts if p))
        res = {"ai": False, "seams": [], "hits": {}}
        m = self.gate.search(t)
        if not m:
            return res
        res["ai"] = True
        res["hits"]["AI"] = _snip(t, m)
        for k in SEAMS:
            mm = self.seams[k].search(t)
            if mm:
                res["seams"].append(k)
                res["hits"][k] = _snip(t, mm)
        return res


_CODER: Optional[Coder] = None


def coder() -> Coder:
    global _CODER
    if _CODER is None:
        _CODER = Coder()
    return _CODER


# ------------------------------------------------------------------------------------------------ over a set of posts
def _get(p: dict, *keys, default=None):
    for k in keys:
        v = p.get(k)
        if v not in (None, ""):
            return v
    return default


def _headline(p: dict) -> str:
    """The post's title, or for a channel post its first substantial line (a forwarding banner is not a headline)."""
    if p.get("title"):
        return str(p["title"])[:200]
    for ln in (p.get("text") or "").splitlines():
        ln = ln.strip()
        if len(re.sub(r"\W", "", ln)) >= 8 and not re.match(r"(?i)^(fwd|forwarded) from", ln):
            return ln[:200]
    return ""


def _us_facing(p: dict) -> bool:
    """Posts about the United States: the severity rules read them as US-domestic, or the gazetteer finds the US in them."""
    f = p.get("features") or {}
    rule = _get(p, "sev_rule", default=f.get("severity_rule", ""))
    if rule and rule != "not US-domestic":
        return True
    return "United States" in (_get(p, "countries", default=f.get("countries")) or [])


def section(posts: Iterable[dict], unverified: Callable[[dict], bool], coverage: str = "window", max_items: int = 400) -> dict:
    """Codes every post given (a store window or a snapshot's carried posts) and returns counts plus a slim item list of
    the AI posts. Counts include every post; the item list leaves out posts by sources whose affiliation is unverified."""
    cd = coder()
    n, n_ai, n_us, n_ai_us = Counter(), Counter(), Counter(), Counter()
    seam_n = defaultdict(Counter)                 # seam -> country -> posts
    seam_us = Counter()
    lang_n, lang_ai = Counter(), Counter()
    days = Counter()
    items, hidden = [], 0
    for p in posts:
        c = p.get("country") or "?"
        n[c] += 1
        lg = p.get("lang") or "und"
        lang_n[lg] += 1
        res = cd.code(p.get("title") or "", p.get("text") or "")
        us = _us_facing(p)
        n_us[c] += 1 if us else 0
        if not res["ai"]:
            continue
        n_ai[c] += 1
        lang_ai[lg] += 1
        n_ai_us[c] += 1 if us else 0
        days[time.strftime("%Y-%m-%d", time.gmtime(int(p.get("ts") or 0)))] += 1
        for k in res["seams"]:
            seam_n[k][c] += 1
            seam_us[k] += 1 if us else 0
        if unverified(p):
            hidden += 1
            continue
        items.append({
            "id": p.get("id"), "ts": int(p.get("ts") or 0), "country": c, "cat": _get(p, "cat", "category", default=""),
            "outlet": _get(p, "name", "s_name", default=p.get("source_id") or p.get("src") or ""), "platform": p.get("platform") or "",
            "lang": lg, "url": p.get("url") or "", "title": _headline(p), "seams": res["seams"],
            "hits": {k: v[:170] for k, v in res["hits"].items()}, "us": us, "sev": int(_get(p, "sev", "severity", default=0) or 0),
            "narr": list(_get(p, "narr", "narratives", default=[]) or [])[:4],
            "flash": list(_get(p, "flash", default=(p.get("features") or {}).get("flashpoints")) or [])[:4],
        })
    items.sort(key=lambda it: (-len(it["seams"]), -it["sev"], -it["ts"]))
    return {
        "codebook": cd.version, "coverage": coverage, "posts": sum(n.values()), "by_country": {c: {"posts": n[c], "ai": n_ai[c], "us": n_us[c], "ai_us": n_ai_us[c]} for c in sorted(n)},
        "seams": {k: {"label": LABELS[k], "by_country": dict(seam_n[k]), "total": sum(seam_n[k].values()), "us": seam_us[k]} for k in SEAMS},
        "by_lang": {lg: {"posts": lang_n[lg], "ai": lang_ai[lg]} for lg in sorted(lang_n, key=lambda x: -lang_n[x])},
        "ai_by_day": dict(sorted(days.items())), "items": items[:max_items], "items_total": len(items), "unlisted_unverified": hidden,
    }


# ------------------------------------------------------------------------------------------------ the pack GHOST LOOM loads
def _unverified_slim(p: dict) -> bool:
    return bool(p.get("unverified"))


def bridge_pack(snap: dict) -> dict:
    """Snapshot (live or exercise export) -> GHOST LOOM pack. Uses the snapshot's own 'ghostloom' section when present
    (PUBLIUS 1.1 codes the whole window); otherwise codes the posts the snapshot carries and says so."""
    meta = snap.get("meta") or {}
    ex = meta.get("exercise")
    posts = snap.get("posts") or {}
    gl = snap.get("ghostloom")
    if not gl:
        gl = section(posts.values(), _unverified_slim, coverage="carried")
    srcs = snap.get("sources") or []
    by_id = {s["id"]: s for s in srcs}

    def src_name(sid: str) -> str:
        s = by_id.get(sid) or {}
        return s.get("name") or sid

    # watchlist: institutions by name elsewhere; here only aggregates
    wl = {"sources": len(srcs), "enabled": sum(1 for s in srcs if s.get("enabled")), "live": sum(1 for s in srcs if s.get("status") == "live"),
          "with_items": sum(1 for s in srcs if (s.get("items") or 0) > 0),
          "entities": len({s.get("entity") for s in srcs if s.get("entity")}),
          "persons": len({s.get("entity") for s in srcs if s.get("kind") == "person"}),
          "by_country_cat": dict(Counter(f"{s.get('country')}|{s.get('cat')}" for s in srcs)),
          "by_platform": dict(Counter(s.get("platform") for s in srcs)),
          "live_by_platform": dict(Counter(s.get("platform") for s in srcs if s.get("status") == "live"))}
    # provenance: items per laundering aggregator; for the Pravda network's editions (the brief's measure), name only
    # upstreams that are themselves watchlisted state or state-aligned sources and count the rest
    prov = snap.get("provenance") or []
    agg = Counter()
    up_w, up_o, up_o_items = Counter(), set(), 0
    for r in prov:
        agg[src_name(r["aggregator"])] += r["items"]
        if "news-pravda" not in r["aggregator"]:
            continue
        if r.get("watchlisted"):
            up_w[r["upstream"]] += r["items"]
        else:
            up_o.add(r["upstream"]); up_o_items += r["items"]
    coord = snap.get("coordination") or {}
    nets = [{"sources": [src_name(s) for s in n.get("sources", [])], "size": n.get("size")} for n in coord.get("networks", [])]
    edges = [{"a": src_name(e["a"]), "b": src_name(e["b"]), "urls": e["urls"]} for e in coord.get("edges", [])[:20]]
    # echo: stories carried by several watchlisted sources in more than one country
    echo = []
    for e in snap.get("echo") or []:
        if len(e.get("countries") or []) < 2 or e.get("unverified_only"):
            continue
        echo.append({k: e.get(k) for k in ("posts", "sources", "countries", "platforms", "first", "last", "title")})
    narr = snap.get("narratives") or {}
    ncounts = {nid: {c: sum(d.values()) for c, d in by_c.items()} for nid, by_c in (narr.get("counts") or {}).items()}
    fps = [{k: f.get(k) for k in ("id", "title", "category", "start", "end", "status", "summary", "grievance", "refs", "n_linked")} for f in snap.get("flashpoints") or []]
    ops = [{k: o.get(k) for k in ("id", "name", "country", "status", "grade", "summary", "evidence", "indicators")} for o in snap.get("operations") or []]
    lanes = []
    for l in snap.get("lanes") or []:
        simd = bool(l.get("simulated"))
        pr = l.get("probe") if isinstance(l.get("probe"), dict) else None
        lanes.append({"platform": l["platform"], "label": l.get("label"), "enabled": l.get("real_enabled", l.get("enabled")) if simd else l.get("enabled"),
                      "ready": l.get("real_ready", l.get("ready")) if simd else l.get("ready"), "why": (l.get("real_why") if simd else l.get("why")) or "",
                      "breakout_lane": l.get("breakout_lane"), "breakout_ready": False if simd else l.get("breakout_ready"),
                      "sources": l.get("sources"), "live_sources": l.get("live_sources"), "closed_sources": l.get("closed_sources"), "simulated_in_export": simd,
                      "region": l.get("region", "global"), "route_class": l.get("route_class", "open"), "new_in": l.get("new_in", "1.0"),
                      "reads": l.get("reads", ""), "refuses": l.get("refuses", ""), "probeable": bool(l.get("probeable")),
                      "probe": ({"ok": pr.get("ok"), "note": pr.get("note", ""), "ts": pr.get("ts")} if pr else None)})
    hist = snap.get("hist") or {}
    model = (meta.get("model") or {})
    refs = snap.get("refs") or {}
    return {
        "kind": "publius-ghostloom-pack", "schema": 2, "codebook": gl.get("codebook", VERSION),
        "publius": {"version": meta.get("version"), "generated": meta.get("generated"), "window_days": meta.get("window_days"),
                    "posts_in_window": meta.get("posts_in_window"), "days": meta.get("days") or sorted((hist.get("by_day") or {}).keys()),
                    "exercise": bool(ex), "carried": len(posts)},
        "brief": snap.get("brief") or {},
        "hist": {k: hist.get(k) for k in ("country", "platform", "severity", "by_day")},
        "ghostloom": gl, "watchlist": wl,
        "provenance": {"aggregators": agg.most_common(12), "upstreams_watchlisted": up_w.most_common(15), "upstreams_other": {"channels": len(up_o), "items": up_o_items},
                       "scope": "upstreams named by the Pravda network's editions"},
        "collection": {"runs": [{k: r.get(k) for k in ("connector", "started", "finished", "items", "errors")} for r in snap.get("runs") or []],
                       "counts": {k: v for k, v in (meta.get("counts") or {}).items() if k in ("posts", "sources", "enabled_sources", "live_sources", "scored")}},
        "coordination": {"window_s": coord.get("window_s"), "urls_considered": coord.get("urls_considered"), "networks": nets, "edges": edges},
        "echo": echo[:20], "narratives": {"defs": [{"id": d["id"], "name": d["name"], "divisive": d.get("divisive")} for d in narr.get("defs") or []], "counts": ncounts},
        "flashpoints": fps, "salience": snap.get("salience") or [], "operations": ops, "lanes": lanes,
        # schema 2: per-actor collection state (RU, CN, IR, KP) and the hot boards' latest reads with early drops
        "by_actor": snap.get("by_actor") or {},
        "boards": [{k: b.get(k) for k in ("board", "ts", "n", "top", "new", "dropped", "snaps", "span_minutes")} for b in snap.get("boards") or []],
        "model": {"version": model.get("version"), "calibrated": bool(model.get("calibrated")) and not ex, "ref_p3": model.get("ref_p3"),
                  "beta": [{k: b.get(k) for k in ("name", "mean", "sd", "basis", "note")} for b in model.get("beta") or []],
                  "base_rates": model.get("base_rates") or {}, "severity_weight": model.get("severity_weight") or {}, "icd203": model.get("icd203") or [],
                  "rules": {k: v for k, v in ((meta.get("config") or {}).get("model") or {}).items()
                            if k in ("alert_p3", "alert_min_severity", "watch_rr", "watch_min_severity", "s2_watch_rr", "horizon_days", "public_figure_followers")}},
        "refs": refs,
        "left_out": ["simulated lane counts, public figures and indicator counts", "auto-labels and the dry-run calibration", "breakout scores of posts measured in the exercise",
                     "mention lists and posts by sources with unverified affiliation", "full post text (items carry a title and hit snippets)"] if ex else
                    ["mention lists and posts by sources with unverified affiliation", "full post text (items carry a title and hit snippets)"],
    }


def write_pack(snap: dict, path: str) -> dict:
    pack = bridge_pack(snap)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(pack, f, ensure_ascii=False, separators=(",", ":"))
    return {"path": path, "items": len(pack["ghostloom"]["items"]), "coverage": pack["ghostloom"]["coverage"], "posts": pack["ghostloom"]["posts"]}
