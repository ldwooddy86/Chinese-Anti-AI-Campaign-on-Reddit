"""Breakout measurement in US-audience lanes, on Ben Nimmo's Breakout Scale (Brookings 2020):

  1  one platform, no breakout (only the originating network carries it)
  2  pickup by non-network accounts on one US-audience platform
  3  pickups on two or more platforms
  4  cross-medium: US mainstream news coverage (GDELT, US-sourced outlets)
  5  amplification by a high-reach public figure (>= model.public_figure_followers)
  6  policy response, or calls to violence / mobilisation in the pickups

Rails: lanes return aggregate counts. A handle is recorded only for accounts at or above the public-figure
threshold; everyone else is a number. Pickup texts are scanned in memory for violent/mobilising language and discarded.

Selection and weights: posts meeting the check rule (severity / lift thresholds) are always checked (p=1); every other
post is checked with audit probability q. The label carries weight 1/p so calibration is unbiased (see calibrate.py)."""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Optional

from ..util import now

log = logging.getLogger("publius.breakout")
STOP = set("the a an and or of to in on for with at by from as is are was were be been this that these those it its into over after before than about".split())


def queries_for(post: dict) -> list[tuple[str, str]]:
    """(kind, query) pairs: the post's own external URLs first, then a distinctive phrase, then an operation hashtag."""
    from ..util import canonical_url
    out: list[tuple[str, str]] = []
    own = canonical_url(post.get("url") or "") if post.get("url") else ""
    if own:
        out.append(("url", own))            # the post itself (article, video, status or channel message) is what breaks out
    for u in (post.get("urls") or [])[:3]:
        if u == own or "t.me/" in u or "max.ru/" in u:
            continue
        out.append(("url", u))
    text = re.sub(r"https?://\S+|[@#]\w+", " ", (post.get("title") or "") + " " + (post.get("text") or ""))
    words = re.findall(r"[A-Za-z][A-Za-z'’-]+", text)
    best, best_score = "", 0.0
    for i in range(0, max(0, len(words) - 7)):
        win = words[i:i + 8]
        content = [w for w in win if w.lower() not in STOP]
        score = len(set(w.lower() for w in content)) + sum(1 for w in content if w[0].isupper()) * 0.5
        if len(content) >= 5 and score > best_score:
            best, best_score = " ".join(win), score
    if best:
        out.append(("phrase", best))
    for h in (post.get("hashtags") or [])[:2]:
        if len(h) >= 8:
            out.append(("hashtag", "#" + h))
    return out[:5]


def audit_draw(pid: str, q: float) -> bool:
    """Deterministic pseudo-random audit selection (stable across runs)."""
    h = int(hashlib.sha1(("audit:" + pid).encode()).hexdigest()[:8], 16) / 0xFFFFFFFF
    return h < q


def decide_selection(pid: str, rule_sev: int, rr0: float, cfg: dict) -> dict:
    """Decided ONCE, at first scoring, from pre-outcome information only (rule severity and the lift the model gave the
    post before any pickups were observed). Posts meeting the rule are always followed to the horizon (p = 1); every other
    post enters a deterministic audit sample with probability q. Calibration weights each label by 1/p."""
    m = cfg.get("model", {})
    if rule_sev >= int(m.get("breakout_min_severity", 2)) and rr0 >= float(m.get("breakout_min_rr", 1.5)):
        return {"selected": True, "p": 1.0, "why": "rule"}
    q = float(m.get("audit_rate", 0.05))
    hit = audit_draw(pid, q)
    return {"selected": hit, "p": q, "why": "audit" if hit else "not selected"}


def due(post: dict, cfg: dict, done_checks: int) -> bool:
    """The k-th check falls due once the post is at least breakout_check_hours[k] old."""
    hours = cfg.get("model", {}).get("breakout_check_hours", [1, 6, 24, 72, 168])
    age_h = (now() - int(post.get("ts") or now())) / 3600.0
    return done_checks < len(hours) and age_h >= hours[done_checks]


def level(obs_by_lane: dict, cfg: dict) -> tuple[int, dict]:
    """obs_by_lane: {lane: {count, public_figures[], violent_or_mobilising, mainstream(bool)}} → (level, reasons)."""
    m = cfg.get("model", {})
    k = int(m.get("breakout_min_pickups", 3))
    social = {ln: o for ln, o in obs_by_lane.items() if ln != "gdelt"}
    picked = [ln for ln, o in social.items() if int(o.get("count") or 0) >= k]
    L, why = 1, []
    if picked:
        L = 2; why.append(f"pickup on {picked[0]}")
    if len(picked) >= 2:
        L = 3; why.append(f"pickups on {len(picked)} platforms ({', '.join(picked)})")
    g = obs_by_lane.get("gdelt") or {}
    if int(g.get("count") or 0) >= int(m.get("breakout_min_mainstream", 2)):
        L = max(L, 4); why.append(f"US mainstream coverage ({g.get('count')} articles)")
    pfs = sorted({p for o in obs_by_lane.values() for p in (o.get("public_figures") or [])})
    if pfs:
        L = max(L, 5); why.append(f"public-figure amplification ({', '.join(pfs[:4])})")
    vm = sum(int(o.get("violent_or_mobilising") or 0) for o in social.values())
    if vm >= k:
        L = max(L, 6); why.append(f"{vm} pickups carry violent or mobilising language")
    return L, {"reasons": why, "lanes_with_pickup": picked, "public_figures": pfs}


def run_checks(store, lanes: dict, cfg: dict, max_checks: Optional[int] = None) -> dict:
    """Run due breakout checks for selected posts through every ready lane. Checks continue to the horizon whatever the
    post's later score; a check counts only if at least one lane answered."""
    max_checks = int(max_checks or cfg.get("model", {}).get("breakout_max_checks_per_cycle", 40))
    horizon = int(cfg.get("model", {}).get("horizon_days", 7)) * 86400
    cands = [p for p in store.posts(since=now() - horizon - 86400, limit=100000) if ((p.get("features") or {}).get("sel") or {}).get("selected")]
    cands.sort(key=lambda p: (int((p.get("breakout") or {}).get("checks") or 0), -(p.get("risk") or 0)))
    done = 0
    stats = {"checked": 0, "candidates": len(cands), "lanes": list(lanes), "skipped_no_query": 0}
    social = [ln for ln in lanes if ln != "gdelt"]
    for p in cands:
        if done >= max_checks:
            break
        b = dict(p.get("breakout") or {})
        n_checks = int(b.get("checks") or 0)
        if not due(p, cfg, n_checks):
            continue
        qs = queries_for(p)
        if not qs:
            stats["skipped_no_query"] += 1; continue
        obs, answered = {}, set()
        for lane, conn in lanes.items():
            best = None
            for kind, q in qs:
                try:
                    r = conn.search(q, kind=kind, since=int(p.get("ts") or now()), source_handle=p.get("s_handle") if p.get("platform") == lane else None)
                except TypeError:
                    r = conn.search(q, kind=kind, since=int(p.get("ts") or now()))
                except Exception as e:  # a failing lane is recorded as not answering, never fatal
                    log.debug("lane %s failed: %s", lane, e)
                    continue
                if not r.ok:
                    continue
                answered.add(lane)
                if best is None or r.count > best.count:
                    best = r
            if best is not None:
                store.add_breakout_obs(p["id"], lane, best.count, best.reach_max, best.public_figures, best.violent_or_mobilising, qs[0][1], best.note)
                obs[lane] = {"count": best.count, "public_figures": best.public_figures, "violent_or_mobilising": best.violent_or_mobilising}
                if best.cost_usd:
                    from ..util import day
                    store.add_spend(day(now()), lane, best.cost_usd, 1)
        if not answered:
            continue
        for o in store.breakout_obs(p["id"]):
            cur = obs.setdefault(o["lane"], {"count": 0, "public_figures": [], "violent_or_mobilising": 0})
            cur["count"] = max(cur["count"], int(o["count"] or 0))
            cur["public_figures"] = sorted(set(cur["public_figures"]) | set(o["public_figures"] or []))
            cur["violent_or_mobilising"] = max(cur["violent_or_mobilising"], int(o["violent_or_mobilising"] or 0))
        L, why = level(obs, cfg)
        live = sorted(set(b.get("lanes_live") or []) | {ln for ln in answered if ln in social})
        b.update({"level": L, "lanes": obs, "why": why, "checks": n_checks + 1, "last_check": now(), "lanes_live": live,
                  "measurable": len(live) >= 2})
        store.update_analysis(p["id"], breakout=b, breakout_level=L, breakout_ts=now())
        done += 1
        stats["checked"] += 1
    return stats


def auto_label(store, cfg: dict) -> dict:
    """After the horizon, a selected post with at least two checks, the last at 72 h or later, gets its observed level as an
    'auto' label — but only when at least two social lanes answered, because levels 2 and 3 cannot be told apart otherwise.
    Posts that fail that test are marked censored and stay out of calibration."""
    horizon = int(cfg.get("model", {}).get("horizon_days", 7)) * 86400
    n = cens = 0
    for p in store.posts(until=now() - horizon, since=now() - 60 * 86400, limit=100000):
        b = p.get("breakout") or {}
        if not b or int(b.get("checks") or 0) < 2 or (int(b.get("last_check") or 0) - int(p.get("ts") or 0)) < 72 * 3600:
            continue
        if not b.get("measurable"):
            if not b.get("censored"):
                store.update_analysis(p["id"], breakout=dict(b, censored=True)); cens += 1
            continue
        store.set_label(p["id"], int(b.get("level") or 1), source="auto", note=f"lanes={','.join(b.get('lanes_live') or [])}")
        n += 1
    return {"labelled": n, "censored": cens}
