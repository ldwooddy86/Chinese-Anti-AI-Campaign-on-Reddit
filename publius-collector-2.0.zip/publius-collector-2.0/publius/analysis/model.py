"""Breakout model: proportional-odds (cumulative logit) over the Breakout Scale, with Bayesian uncertainty.

  P(B >= k | x) = logistic(eta - theta_k),  eta = beta . x,  k = 2..6        (McCullagh 1980)

Predictive probabilities integrate over parameter uncertainty with the probit approximation
E[logistic(z)] ~= logistic(mu / sqrt(1 + pi s^2 / 8))                          (MacKay 1992)
and carry an 80% credible interval. The unrest risk index multiplies the probability of multi-platform breakout
(B >= 3) by the severity weight of what would break out (S0..S4), so likelihood and consequence stay separate and visible."""
from __future__ import annotations

import json
import math
import os
from typing import Optional


def _jload(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return json.load(f)


DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
LEVELS = (2, 3, 4, 5, 6)
Z80 = 1.2815515655446004

# ICD-203 expressions of likelihood
ICD203 = [(0.05, "almost no chance"), (0.20, "very unlikely"), (0.45, "unlikely"), (0.55, "roughly even chance"), (0.80, "likely"), (0.95, "very likely"), (1.01, "almost certain")]


def logistic(z: float) -> float:
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def logit(p: float) -> float:
    p = min(1 - 1e-12, max(1e-12, p))
    return math.log(p / (1 - p))


def icd203(p: float) -> str:
    for hi, word in ICD203:
        if p < hi:
            return word
    return "almost certain"


class Model:
    def __init__(self, params: Optional[dict] = None):
        pri = _jload(os.path.join(DATA, "priors.json"))
        self.prior = pri
        self.sev_w = {int(k): float(v) for k, v in pri["severity_weight"].items()}
        self.names = list(pri["beta"].keys())
        if params:                                   # calibrated (MAP + Laplace)
            self.version = params["version"]
            self.beta = {k: float(params["beta"][k]) for k in self.names if k in params["beta"]}
            for k in self.names:
                self.beta.setdefault(k, pri["beta"][k]["mean"])
            self.cov = params.get("cov")             # covariance of beta in self.names order (list of lists) or None
            self.cov_full = params.get("cov_full")   # covariance of (beta, theta_2..theta_6) including the cross block
            self.beta_sd = {k: float(params.get("beta_sd", {}).get(k, pri["beta"][k]["sd"])) for k in self.names}
            self.theta = {int(k): float(v) for k, v in params["theta"].items()}
            self.theta_sd = {int(k): float(v) for k, v in params.get("theta_sd", {}).items()} or {k: pri["theta_sd"] for k in LEVELS}
            self.calibrated = True
            self.metrics = params.get("metrics", {})
        else:
            self.version = pri["_meta"]["version"]
            self.beta = {k: float(v["mean"]) for k, v in pri["beta"].items()}
            self.beta_sd = {k: float(v["sd"]) for k, v in pri["beta"].items()}
            self.cov = None
            self.cov_full = None
            self.theta = {int(k): -logit(float(v)) for k, v in pri["base_rates"].items() if not str(k).startswith("_")}
            self.theta_sd = {k: float(pri["theta_sd"]) for k in LEVELS}
            self.calibrated = False
            self.metrics = {}
        # lift is predictive-over-predictive: the reference post scored exactly like any other post (rr = 1 for it)
        self.ref_p3 = self.predict({})["levels"][3]["p"]

    # ------------------------------------------------------------------ scoring
    def eta(self, x: dict) -> tuple[float, float]:
        mu = sum(self.beta[k] * float(x.get(k, 0.0)) for k in self.names)
        if self.cov:
            v = [float(x.get(k, 0.0)) for k in self.names]
            var = sum(v[i] * self.cov[i][j] * v[j] for i in range(len(v)) for j in range(len(v)))
        else:
            var = sum((self.beta_sd[k] * float(x.get(k, 0.0))) ** 2 for k in self.names)
        return mu, max(0.0, var)

    def _var_z(self, x: dict, var_eta: float, k: int) -> float:
        """Var(eta - theta_k) = x'S_bb x - 2 x'S_b,theta_k + S_theta_k (cross term only once calibrated)."""
        if self.cov_full:
            p = len(self.names)
            v = [float(x.get(n, 0.0)) for n in self.names]
            j = p + LEVELS.index(k)
            cross = sum(v[i] * self.cov_full[i][j] for i in range(p))
            return max(1e-12, var_eta - 2.0 * cross + self.cov_full[j][j])
        return var_eta + self.theta_sd[k] ** 2

    def predict(self, x: dict) -> dict:
        mu, var = self.eta(x)
        out = {}
        for k in LEVELS:
            z = mu - self.theta[k]
            s2 = self._var_z(x, var, k)
            s = math.sqrt(s2)
            out[k] = {"p": logistic(z / math.sqrt(1.0 + math.pi * s2 / 8.0)), "lo": logistic(z - Z80 * s), "hi": logistic(z + Z80 * s)}
        return {"eta": mu, "eta_sd": math.sqrt(var), "levels": out}

    def contributions(self, x: dict, top: int = 8) -> list[tuple[str, float]]:
        c = [(k, self.beta[k] * float(x.get(k, 0.0))) for k in self.names if abs(float(x.get(k, 0.0))) > 1e-9]
        c.sort(key=lambda t: -abs(t[1]))
        return [(k, round(v, 3)) for k, v in c[:top]]

    def score(self, x: dict, sev: int, cfg: dict, affil_verified: bool = True) -> dict:
        pr = self.predict(x)
        p3 = pr["levels"][3]["p"]
        p5 = pr["levels"][5]["p"]
        rr = p3 / self.ref_p3 if self.ref_p3 > 0 else 0.0
        w = self.sev_w.get(int(sev), 0.0)
        risk = 100.0 * p3 * w / max(self.sev_w.values())
        m = cfg.get("model", {})
        flag = ""
        if sev >= int(m.get("alert_min_severity", 3)) and p3 >= float(m.get("alert_p3", 0.20)):
            flag = "ALERT"
        elif (sev >= int(m.get("watch_min_severity", 3)) and rr >= float(m.get("watch_rr", 2.0))) or (sev >= 2 and rr >= float(m.get("s2_watch_rr", 5.0))) or sev >= 4:
            flag = "WATCH"
        capped = False
        if flag == "ALERT" and not affil_verified:
            flag, capped = "WATCH", True
        return {"p": {str(k): round(v["p"], 5) for k, v in pr["levels"].items()}, "p3": round(p3, 5), "p3_lo": round(pr["levels"][3]["lo"], 5),
                "p3_hi": round(pr["levels"][3]["hi"], 5), "p5": round(p5, 6), "word": icd203(p3), "rr": round(rr, 3), "severity": int(sev),
                "risk": round(risk, 3), "flag": flag, "capped_unverified": capped, "eta": round(pr["eta"], 3), "eta_sd": round(pr["eta_sd"], 3),
                "contrib": self.contributions(x), "model": self.version, "calibrated": self.calibrated}

    def describe(self) -> dict:
        pri = self.prior["beta"]
        return {"version": self.version, "calibrated": self.calibrated, "ref_p3": self.ref_p3, "metrics": self.metrics,
                "beta": [{"name": k, "mean": round(self.beta[k], 4), "sd": round(self.beta_sd[k], 4), "prior_mean": pri[k]["mean"], "prior_sd": pri[k]["sd"],
                          "basis": pri[k]["basis"], "note": pri[k]["note"]} for k in self.names],
                "theta": {str(k): round(v, 4) for k, v in self.theta.items()}, "base_rates": {str(k): round(logistic(-v), 6) for k, v in self.theta.items()},
                "severity_weight": self.sev_w, "icd203": ICD203[:-1] + [(1.0, "almost certain")]}


def load(store=None) -> Model:
    if store is not None:
        m = store.active_model()
        if m and m.get("params"):
            p = dict(m["params"]); p["version"] = m["id"]; p["metrics"] = m.get("metrics", {})
            return Model(p)
    return Model()
