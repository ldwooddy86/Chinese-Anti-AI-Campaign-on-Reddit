"""Calibration: MAP fit of the proportional-odds breakout model under its Gaussian priors, with inverse-probability
weights that undo the selection of which posts got breakout checks, a time-ordered backtest, and a Laplace posterior.

Why weights: breakout is only measured for posts that crossed the check thresholds plus a random audit sample
(probability q). Fitting on the checked posts alone would overstate breakout rates; weighting each labelled post by
1/P(checked) (Horvitz–Thompson) restores the population the model is meant to describe."""
from __future__ import annotations

import math
import time
from typing import Optional

import numpy as np

from .model import LEVELS, Model, logistic, logit


def _sig(z):
    with np.errstate(over="ignore", invalid="ignore"):
        return 1.0 / (1.0 + np.exp(-z))


def _unpack(v: np.ndarray, p: int) -> tuple[np.ndarray, np.ndarray]:
    beta, t, u = v[:p], v[p], v[p + 1:p + 5]
    theta = np.empty(5)
    theta[0] = t
    for i in range(1, 5):
        theta[i] = theta[i - 1] + math.exp(u[i - 1])
    return beta, theta


def _jac(v: np.ndarray, p: int) -> np.ndarray:
    u = v[p + 1:p + 5]
    J = np.zeros((5, 5)); J[:, 0] = 1.0
    for j in range(1, 5):
        J[j:, j] = math.exp(u[j - 1])
    return J


def _nlp_grad(v, X, y, w, mu_b, sd_b, mu_t, sd_t):
    p = X.shape[1]
    beta, theta = _unpack(v, p)
    eta = X @ beta
    lo_idx, hi_idx = np.clip(y - 2, 0, 4), np.clip(y - 1, 0, 4)
    has_lo, has_hi = y >= 2, y <= 5
    a = np.where(has_lo, eta - theta[lo_idx], 0.0)
    b = np.where(has_hi, eta - theta[hi_idx], 0.0)
    Fa = np.where(has_lo, _sig(a), 1.0); fa = np.where(has_lo, Fa * (1 - Fa), 0.0)
    Fb = np.where(has_hi, _sig(b), 0.0); fb = np.where(has_hi, Fb * (1 - Fb), 0.0)
    D = np.clip(Fa - Fb, 1e-15, None)
    ll = float(np.sum(w * np.log(D)))
    g_eta = w * (fa - fb) / D
    g_beta = X.T @ g_eta
    g_theta = np.zeros(5)
    np.add.at(g_theta, lo_idx[has_lo], -(w * fa / D)[has_lo])
    np.add.at(g_theta, hi_idx[has_hi], (w * fb / D)[has_hi])
    nlp = -ll + 0.5 * float(np.sum(((beta - mu_b) / sd_b) ** 2)) + 0.5 * float(np.sum(((theta - mu_t) / sd_t) ** 2))
    gb = -g_beta + (beta - mu_b) / sd_b ** 2
    gt = -g_theta + (theta - mu_t) / sd_t ** 2
    return nlp, np.concatenate([gb, _jac(v, p).T @ gt])


def _hessian(v, *args, h: float = 1e-5) -> np.ndarray:
    n = len(v)
    H = np.zeros((n, n))
    for j in range(n):
        e = np.zeros(n); e[j] = h
        H[:, j] = (_nlp_grad(v + e, *args)[1] - _nlp_grad(v - e, *args)[1]) / (2 * h)
    return 0.5 * (H + H.T)


def fit(X: np.ndarray, y: np.ndarray, w: np.ndarray, names: list[str], prior: dict, max_iter: int = 60) -> dict:
    p = X.shape[1]
    mu_b = np.array([prior["beta"][k]["mean"] for k in names]); sd_b = np.array([prior["beta"][k]["sd"] for k in names])
    mu_t = np.array([-logit(float(prior["base_rates"][str(k)])) for k in LEVELS]); sd_t = np.full(5, float(prior["theta_sd"]))
    v = np.concatenate([mu_b, [mu_t[0]], np.log(np.diff(mu_t))])
    args = (X, y, w, mu_b, sd_b, mu_t, sd_t)
    f, g = _nlp_grad(v, *args)
    lam = 1e-3
    for it in range(max_iter):
        H = _hessian(v, *args)
        try:
            step = np.linalg.solve(H + lam * np.eye(len(v)), g)
        except np.linalg.LinAlgError:
            lam *= 10; continue
        t = 1.0
        while t > 1e-6:
            v_new = v - t * step
            f_new, g_new = _nlp_grad(v_new, *args)
            if f_new <= f - 1e-4 * t * float(g @ step):
                break
            t *= 0.5
        if t <= 1e-6:
            lam *= 10
            if lam > 1e6:
                break
            continue
        v, f, g = v_new, f_new, g_new
        lam = max(1e-6, lam / 3)
        if float(np.max(np.abs(g))) < 1e-6:
            break
    H = _hessian(v, *args)
    try:
        cov = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        cov = np.linalg.pinv(H)
    beta, theta = _unpack(v, p)
    J = _jac(v, p)
    Jf = np.eye(p + 5)
    Jf[p:, p:] = J
    cov_bt = Jf @ cov @ Jf.T                       # covariance of (beta, theta_2..theta_6), including the beta-theta block
    cov_theta = cov_bt[p:, p:]
    return {"beta": {k: float(beta[i]) for i, k in enumerate(names)}, "cov": cov_bt[:p, :p].tolist(), "cov_full": cov_bt.tolist(),
            "beta_sd": {k: float(math.sqrt(max(cov_bt[i, i], 1e-12))) for i, k in enumerate(names)},
            "theta": {str(k): float(theta[i]) for i, k in enumerate(LEVELS)}, "theta_sd": {str(k): float(math.sqrt(max(cov_theta[i, i], 1e-12))) for i, k in enumerate(LEVELS)},
            "nlp": float(f), "iterations": it + 1}


def kish(w: np.ndarray) -> np.ndarray:
    """Rescale inverse-probability weights so they sum to the Kish effective sample size (sum w)^2 / sum w^2. Raw 1/q weights
    would otherwise count each audited post as 1/q independent observations and swamp the priors."""
    s1, s2 = float(np.sum(w)), float(np.sum(w * w))
    return w * (s1 / s2) if s2 > 0 else w


# ------------------------------------------------------------------------------------------------ evaluation
def _auc(p: np.ndarray, o: np.ndarray, w: np.ndarray) -> Optional[float]:
    pos, neg = o == 1, o == 0
    if not pos.any() or not neg.any():
        return None
    order = np.argsort(p, kind="mergesort")
    p_s, o_s, w_s = p[order], o[order], w[order]
    wneg_cum, tot, i = 0.0, 0.0, 0
    n = len(p_s)
    while i < n:
        j = i
        while j < n and p_s[j] == p_s[i]:
            j += 1
        wp = float(np.sum(w_s[i:j][o_s[i:j] == 1])); wn = float(np.sum(w_s[i:j][o_s[i:j] == 0]))
        tot += wp * (wneg_cum + 0.5 * wn)
        wneg_cum += wn
        i = j
    return tot / (float(np.sum(w[pos])) * float(np.sum(w[neg])))


def evaluate(p: np.ndarray, o: np.ndarray, w: np.ndarray, bins: Optional[int] = None) -> dict:
    W = float(np.sum(w))
    if bins is None:                                   # about 25 posts a bin: finer bins on a small test set only draw noise
        bins = max(4, min(10, len(p) // 25))
    brier = float(np.sum(w * (p - o) ** 2) / W)
    pc = np.clip(p, 1e-9, 1 - 1e-9)
    logloss = float(-np.sum(w * (o * np.log(pc) + (1 - o) * np.log(1 - pc))) / W)
    base = float(np.sum(w * o) / W)
    brier_ref = base * (1 - base)
    qs = np.unique(np.quantile(p, np.linspace(0, 1, bins + 1)))
    rel, ece = [], 0.0
    for i in range(len(qs) - 1):
        m = (p >= qs[i]) & ((p < qs[i + 1]) if i < len(qs) - 2 else (p <= qs[i + 1]))
        if not m.any():
            continue
        wb = float(np.sum(w[m]))
        mp, mo = float(np.sum(w[m] * p[m]) / wb), float(np.sum(w[m] * o[m]) / wb)
        rel.append({"p_mean": round(mp, 5), "obs_rate": round(mo, 5), "weight": round(wb, 2), "n": int(m.sum())})
        ece += wb / W * abs(mp - mo)
    return {"n": int(len(p)), "weighted_n": round(W, 1), "base_rate": round(base, 5), "brier": round(brier, 6), "brier_skill": round(1 - brier / brier_ref, 4) if brier_ref > 0 else None,
            "logloss": round(logloss, 5), "ece": round(ece, 5), "auc": (round(_auc(p, o, w), 4) if _auc(p, o, w) is not None else None), "reliability": rel}


def _predict(model: Model, X: np.ndarray, names: list[str], level: int) -> np.ndarray:
    return np.array([model.predict({k: X[i, j] for j, k in enumerate(names)})["levels"][level]["p"] for i in range(X.shape[0])])


def calibrate(rows: list[dict], min_n: int = 200, min_pos: int = 10, split: float = 0.7, gap_s: int = 0) -> dict:
    """rows: [{x: {feature: value}, y: 1..6, w: weight, ts: epoch}]. Returns {status, params?, metrics}."""
    prior_model = Model()
    names = prior_model.names
    rows = [r for r in rows if r.get("x") and 1 <= int(r.get("y", 0)) <= 6]
    n, npos = len(rows), sum(1 for r in rows if int(r["y"]) >= 3)
    counts = {str(k): sum(1 for r in rows if int(r["y"]) == k) for k in range(1, 7)}
    if n < min_n or npos < min_pos:
        return {"status": "insufficient", "n": n, "positives_b3": npos, "counts": counts, "need": {"n": min_n, "positives_b3": min_pos},
                "message": f"{n} labelled posts ({npos} with B>=3); calibration needs >= {min_n} and >= {min_pos}. The prior model stays active."}
    rows.sort(key=lambda r: r.get("ts", 0))
    X = np.array([[float(r["x"].get(k, 0.0)) for k in names] for r in rows])
    y = np.array([int(r["y"]) for r in rows]); w_raw = np.array([float(r.get("w", 1.0)) for r in rows])
    ts = np.array([int(r.get("ts", 0)) for r in rows])
    cut = int(n * split)
    # purged time split: test posts start one horizon after the last training post, so no outcome window overlaps
    test = np.where(ts >= (ts[cut - 1] + gap_s if cut > 0 else 0))[0]
    test = test[test >= cut]
    out = {"status": "ok", "n": n, "positives_b3": npos, "counts": counts, "split": split, "gap_s": gap_s, "effective_n": round(float(np.sum(w_raw)) ** 2 / float(np.sum(w_raw ** 2)), 1)}
    if cut >= 50 and (y[:cut] >= 3).sum() >= 3 and len(test) >= 30:
        tr = fit(X[:cut], y[:cut], kish(w_raw[:cut]), names, prior_model.prior)
        m_tr = Model({**tr, "version": "backtest"})
        o3 = (y[test] >= 3).astype(float)
        out["backtest"] = {"b3": {"fitted": evaluate(_predict(m_tr, X[test], names, 3), o3, w_raw[test]), "prior": evaluate(_predict(prior_model, X[test], names, 3), o3, w_raw[test])},
                           "train_n": cut, "test_n": int(len(test))}
    w = kish(w_raw)
    full = fit(X, y, w, names, prior_model.prior)
    vid = time.strftime("cal-%Y%m%d-%H%M", time.gmtime())
    out["params"] = {**full, "version": vid}
    m_full = Model({**full, "version": vid})
    out["in_sample"] = {"b3": evaluate(_predict(m_full, X, names, 3), (y >= 3).astype(float), w)}
    out["version"] = vid
    return out
