"""Optional second-opinion pass: a Claude model re-reads the posts the lexicon model ranks highest and returns a
structured severity judgement with a rationale. It never replaces the audit trail: the rule-based severity, its matched
terms and the model's answer are all kept, and disagreements of two or more levels are surfaced for the analyst.

Off unless triage.enabled = true and an Anthropic API key is configured. Only watchlist posts (foreign state and
state-aligned sources) are ever sent."""
from __future__ import annotations

import json
import logging
import re

from .store import Store
from .util import HttpError, http_post_json, iso, now

log = logging.getLogger("publius.triage")
URL = "https://api.anthropic.com/v1/messages"
SYSTEM = (
    "You assess posts published by Russian, Chinese and Iranian state or state-aligned accounts for their potential to aggravate "
    "domestic unrest in the United States if they reached US audiences. For EACH post return one JSON object: "
    "{id, us_domestic (bool: is the subject US internal affairs), severity (0-4), narrative (short label), call_to_action "
    "{present (bool), what, when, where}, targets_group (bool), rationale (<=35 words)}. Severity: 0 not US-domestic; 1 divisive framing of a "
    "US domestic issue; 2 delegitimises US institutions or elections, conspiratorial, or repeats a known falsehood; 3 calls on Americans "
    "to act (protest, strike, boycott, confront) or dehumanises a group; 4 endorses or incites violence. Judge the text as written; reporting "
    "that a protest happened is not a call to protest. Output ONLY a JSON array.")


def run(cfg: dict, store: Store) -> dict:
    t = cfg.get("triage", {})
    key = str(t.get("anthropic_api_key", "")).strip()
    if not (t.get("enabled") and key):
        return {"skipped": "triage disabled or no API key"}
    min_rr = float(t.get("min_rr", 1.5))
    cands = [p for p in store.posts(since=now() - 3 * 86400, limit=3000, order="risk")
             if not p.get("llm") and (p.get("rr") or 0) >= min_rr and (p.get("severity") or 0) >= 1][: int(t.get("max_posts_per_cycle", 40))]
    done, disagree = 0, 0
    for i in range(0, len(cands), 10):
        chunk = cands[i:i + 10]
        payload = [{"id": p["id"], "source": p.get("s_name"), "country": p.get("country"), "when": iso(p["ts"]), "text": ((p.get("title") or "") + "\n" + (p.get("text") or ""))[:1800]} for p in chunk]
        try:
            r = http_post_json(URL, {"model": t.get("model", "claude-sonnet-4-5"), "max_tokens": 3000, "system": SYSTEM, "messages": [{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}]},
                               headers={"x-api-key": key, "anthropic-version": "2023-06-01"}, timeout=120)
        except HttpError as e:
            log.warning("triage call failed: %s", e); break
        text = "".join(c.get("text", "") for c in r.get("content") or [] if c.get("type") == "text")
        m = re.search(r"\[.*\]", text, re.S)
        try:
            arr = json.loads(m.group(0)) if m else []
        except json.JSONDecodeError:
            arr = []
        by = {str(o.get("id")): o for o in arr if isinstance(o, dict)}
        for p in chunk:
            o = by.get(p["id"])
            if not o:
                continue
            try:
                sev = max(0, min(4, int(o.get("severity"))))
            except (TypeError, ValueError):
                continue
            rec = {"severity": sev, "us_domestic": bool(o.get("us_domestic")), "narrative": str(o.get("narrative", ""))[:80], "cta": o.get("call_to_action") or {},
                   "targets_group": bool(o.get("targets_group")), "rationale": str(o.get("rationale", ""))[:300], "model": t.get("model"), "rule_severity": p.get("severity"),
                   "disagreement": abs(sev - int(p.get("severity") or 0)) >= 2}
            disagree += 1 if rec["disagreement"] else 0
            store.update_analysis(p["id"], llm=rec)
            done += 1
    return {"triaged": done, "disagreements": disagree}
