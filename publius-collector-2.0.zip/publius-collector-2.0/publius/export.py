"""Export: the snapshot as JSON, and a single self-contained HTML file (dashboard + embedded snapshot, no network calls)
suitable for sharing or archiving a point-in-time read."""
from __future__ import annotations

import json
import os

DASH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard")


def _safe_json(obj) -> str:
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)
    return s.replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def static_html(snapshot: dict, title: str = "PUBLIUS") -> str:
    def read(name: str) -> str:
        with open(os.path.join(DASH, name), encoding="utf-8") as f:
            return f.read()
    html, css, js = read("index.html"), read("style.css"), read("app.js")
    html = html.replace("<title>PUBLIUS</title>", "<title>" + title.replace("<", "") + "</title>")
    html = html.replace('<link rel="stylesheet" href="style.css">', "<style>\n" + css + "\n</style>")
    data = f'<script type="application/json" id="publius-snapshot">{_safe_json(snapshot)}</script>'
    html = html.replace('<script src="app.js"></script>', data + "\n<script>\n" + js.replace("</script", "<\\/script") + "\n</script>")
    return html


def artifact_html(snapshot: dict) -> str:
    """The same page as static_html, as a fragment for hosts that supply their own document skeleton
    (title, style and content only; no doctype, html, head or body tags)."""
    full = static_html(snapshot)
    head = full.split("<head>", 1)[1].split("</head>", 1)[0]
    body = full.split("<body>", 1)[1].rsplit("</body>", 1)[0]
    title = head[head.index("<title>"):head.index("</title>") + 8]
    style = head[head.index("<style>"):head.rindex("</style>") + 8]
    return title + "\n" + style + "\n" + body


def write(snapshot: dict, out_dir: str, html: bool = True) -> dict:
    os.makedirs(out_dir, exist_ok=True)
    jp = os.path.join(out_dir, "publius-snapshot.json")
    with open(jp, "w", encoding="utf-8") as f:
        json.dump(snapshot, f, ensure_ascii=False, default=str)
    res = {"json": jp}
    from .analysis.ghostloom import write_pack
    res["ghostloom"] = write_pack(snapshot, os.path.join(out_dir, "ghostloom-pack.json"))["path"]
    if html:
        hp = os.path.join(out_dir, "publius-dashboard.html")
        with open(hp, "w", encoding="utf-8") as f:
            f.write(static_html(snapshot))
        res["html"] = hp
    return res
