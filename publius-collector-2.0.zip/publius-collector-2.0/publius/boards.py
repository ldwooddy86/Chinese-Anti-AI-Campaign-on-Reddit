"""Hot-board tracking. A trending board is re-read every cycle; the tracker keeps the last snapshots of each board in the
store's kv table so two things can be reported that a single read cannot show: what entered the board, and what left it
early. An entry that was high on the board at the previous read and is gone at this one, while its heat was still near
the top, is flagged "dropped early". That is a lead, not a finding: platforms also rotate boards on their own clocks,
so a drop is corroborated (a screenshot, a second board, the topic's own posts) before it is called a removal.

Only board entries are kept (a title, a heat figure, a rank). No poster, no comment and no user is ever recorded."""
from __future__ import annotations

import json
from typing import Optional

from .util import now

KEEP_SNAPS = 48            # ~24 h at a 30-minute cycle
WATCH_RANK = 20            # entries at or above this rank are watched for early drops
MIN_HEAT_SHARE = 0.35      # ... and only if their heat was at least this share of the board's top heat when last seen


def _key(board: str) -> str:
    return f"hotboard:{board}"


def record(store, board: str, entries: list[dict], ts: Optional[int] = None) -> dict:
    """Append one snapshot ([{title, heat, rank}]) and return the report for it."""
    ts = int(ts or now())
    raw = store.kv_get(_key(board), "") or ""
    try:
        hist = json.loads(raw) if raw else {"snaps": []}
    except ValueError:
        hist = {"snaps": []}
    top = [[str(e.get("title") or "")[:120], int(e.get("heat") or 0), int(e.get("rank") or i + 1)] for i, e in enumerate(entries) if e.get("title")]
    snaps = [s for s in (hist.get("snaps") or []) if isinstance(s, dict)]
    snaps.append({"ts": ts, "top": top})
    hist["snaps"] = snaps[-KEEP_SNAPS:]
    store.kv_set(_key(board), json.dumps(hist, ensure_ascii=False))
    return report_from(board, hist["snaps"])


def report_from(board: str, snaps: list[dict]) -> dict:
    if not snaps:
        return {"board": board, "ts": None, "n": 0, "top": [], "new": [], "dropped": [], "snaps": 0}
    cur = snaps[-1]
    cur_titles = {t for t, _, _ in cur["top"]}
    seen_before: dict[str, int] = {}
    for s in snaps[:-1]:
        for t, _, _ in s["top"]:
            seen_before[t] = seen_before.get(t, 0) + 1
    new = [t for t, _, _ in cur["top"] if t not in seen_before]
    dropped = []
    if len(snaps) >= 2:
        prev = snaps[-2]
        top_heat = max([h for _, h, _ in prev["top"]] or [0]) or 1
        for t, h, r in prev["top"]:
            if t in cur_titles or r > WATCH_RANK:
                continue
            if h and h / top_heat < MIN_HEAT_SHARE:
                continue
            life = seen_before.get(t, 0)
            dropped.append({"title": t, "last_rank": r, "last_heat": h, "reads_on_board": life, "minutes_since": int((cur["ts"] - prev["ts"]) / 60),
                            "note": "high on the board at the previous read and absent at this one; corroborate before calling it a removal"})
    return {"board": board, "ts": cur["ts"], "n": len(cur["top"]), "top": [{"title": t, "heat": h, "rank": r} for t, h, r in cur["top"][:30]],
            "new": new[:30], "dropped": dropped[:30], "snaps": len(snaps),
            "span_minutes": int((snaps[-1]["ts"] - snaps[0]["ts"]) / 60) if len(snaps) > 1 else 0}


def report(store, board: str) -> dict:
    raw = store.kv_get(_key(board), "") or ""
    try:
        snaps = (json.loads(raw) if raw else {}).get("snaps") or []
    except ValueError:
        snaps = []
    return report_from(board, [s for s in snaps if isinstance(s, dict)])


def boards(store) -> list[str]:
    rows = store.conn().execute("SELECT k FROM kv WHERE k LIKE 'hotboard:%'").fetchall()
    return sorted(r[0].split(":", 1)[1] for r in rows)


def summary(store) -> list[dict]:
    return [report(store, b) for b in boards(store)]
