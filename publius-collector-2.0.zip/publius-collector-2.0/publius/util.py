"""Shared helpers: stdlib HTTP with retries and per-host pacing, text cleaning, URL canonicalisation,
entity extraction (URLs, hashtags, mentions), script-based language guess, hashing and time."""
from __future__ import annotations

import gzip
import hashlib
import html
import json
import logging
import random
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from typing import Any, Iterable, Optional

log = logging.getLogger("publius")

UA = "publius-collector/2.0 (+read-only research monitor of foreign state media; operator: local)"
BROWSER_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36"
DEFAULT_TIMEOUT = 25


class HttpError(Exception):
    def __init__(self, status: int, msg: str = "", body: bytes = b"", retry_after: Optional[float] = None):
        super().__init__(f"HTTP {status} {msg}".strip())
        self.status = status
        self.body = body
        self.retry_after = retry_after


# ------------------------------------------------------------------ pacing
class HostPacer:
    """Minimum spacing between requests to the same host (GDELT asks for 5 s, Telegram previews ~1 s)."""

    def __init__(self):
        self._last: dict[str, float] = {}
        self._lock = threading.Lock()
        self.spacing: dict[str, float] = {"api.gdeltproject.org": 5.5, "t.me": 1.1, "api.x.com": 1.0, "www.reddit.com": 2.0,
                                          "oauth.reddit.com": 0.7, "public.api.bsky.app": 0.3, "bsky.social": 0.3, "www.youtube.com": 0.5,
                                          "www.googleapis.com": 0.2, "api.vk.com": 0.4, "rutube.ru": 0.6}

    def wait(self, url: str) -> None:
        host = urllib.parse.urlsplit(url).hostname or ""
        gap = self.spacing.get(host, 0.25)
        with self._lock:
            last = self._last.get(host, 0.0)
            delay = last + gap - time.monotonic()
            self._last[host] = max(time.monotonic(), last + gap)
        if delay > 0:
            time.sleep(delay)


PACER = HostPacer()


def _open(req: urllib.request.Request, timeout: int, max_bytes: int) -> tuple[bytes, dict, str]:
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise HttpError(413, "response too large")
        enc = (r.headers.get("Content-Encoding") or "").lower()
        if enc == "gzip":
            data = gzip.decompress(data)
        elif enc == "deflate":
            data = zlib.decompress(data)
        return data, dict(r.headers.items()), r.geturl()


def http_request(url: str, method: str = "GET", headers: Optional[dict] = None, data: Optional[bytes] = None, timeout: int = DEFAULT_TIMEOUT,
                 max_bytes: int = 12 * 1024 * 1024, params: Optional[dict] = None, retries: int = 2, browser: bool = False) -> tuple[bytes, dict, str]:
    """Paced request with bounded body, gzip, and retry on 429/5xx (honouring Retry-After). Returns (body, headers, final_url)."""
    if params:
        url = url + ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
    attempt = 0
    while True:
        PACER.wait(url)
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("User-Agent", BROWSER_UA if browser else UA)
        req.add_header("Accept-Encoding", "gzip")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        try:
            return _open(req, timeout, max_bytes)
        except urllib.error.HTTPError as e:
            ra = e.headers.get("Retry-After") if e.headers else None
            body = e.read(4096) if hasattr(e, "read") else b""
            err = HttpError(e.code, str(e.reason), body, float(ra) if ra and str(ra).isdigit() else None)
            if e.code in (429, 500, 502, 503, 504) and attempt < retries:
                attempt += 1
                time.sleep(min(60.0, (err.retry_after or 2 ** attempt) + random.random()))
                continue
            raise err from None
        except urllib.error.URLError as e:
            if attempt < retries:
                attempt += 1
                time.sleep(2 ** attempt)
                continue
            raise HttpError(0, str(e.reason)) from None
        except TimeoutError:
            if attempt < retries:
                attempt += 1
                continue
            raise HttpError(0, "timeout") from None


def http_get(url: str, headers: Optional[dict] = None, timeout: int = DEFAULT_TIMEOUT, params: Optional[dict] = None, browser: bool = False, max_bytes: int = 12 * 1024 * 1024) -> bytes:
    return http_request(url, headers=headers, timeout=timeout, params=params, browser=browser, max_bytes=max_bytes)[0]


def http_get_json(url: str, headers: Optional[dict] = None, timeout: int = DEFAULT_TIMEOUT, params: Optional[dict] = None) -> Any:
    h = {"Accept": "application/json"}
    h.update(headers or {})
    return json.loads(http_get(url, h, timeout=timeout, params=params).decode("utf-8", "replace"))


def http_post_json(url: str, body: Any, headers: Optional[dict] = None, timeout: int = 90) -> Any:
    """POST JSON — used only for OAuth/session exchanges and the optional Anthropic triage call.
    Never used against any platform's write endpoints: every connector is read-only."""
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    h.update(headers or {})
    raw, _, _ = http_request(url, method="POST", headers=h, data=json.dumps(body).encode("utf-8"), timeout=timeout, retries=1)
    return json.loads(raw.decode("utf-8", "replace"))


def http_post_form(url: str, form: dict, headers: Optional[dict] = None, timeout: int = 30) -> Any:
    h = {"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"}
    h.update(headers or {})
    raw, _, _ = http_request(url, method="POST", headers=h, data=urllib.parse.urlencode(form).encode("utf-8"), timeout=timeout, retries=1)
    return json.loads(raw.decode("utf-8", "replace"))


# ------------------------------------------------------------------ text
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"[ \t ​]+")
_CTRL_RE = re.compile("[\\x00-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f\\u202a-\\u202e\\u2066-\\u2069\\ufeff]")


def clean_text(s: Any, limit: int = 6000) -> str:
    """HTML to plain text: entities decoded, control and bidi-override characters removed, whitespace collapsed, capped."""
    if s is None:
        return ""
    t = str(s)
    t = re.sub(r"<br\s*/?>|</p>|</div>|</li>|</blockquote>", "\n", t, flags=re.I)
    t = _TAG_RE.sub(" ", t)
    t = html.unescape(t)
    t = _CTRL_RE.sub(" ", t)
    t = _WS_RE.sub(" ", t)
    t = re.sub(r" *\n *", "\n", t)
    t = re.sub(r"\n{3,}", "\n\n", t).strip()
    if len(t) > limit:
        t = t[: limit - 1].rstrip() + "…"
    return t


URL_RE = re.compile(r"https?://[^\s<>\"'()\[\]{}]+", re.I)
HASHTAG_RE = re.compile(r"(?<![\w&])#([^\s#.,!?;:()\[\]{}\"'«»“”]{2,60})", re.U)
MENTION_RE = re.compile(r"(?<![\w@.])@([A-Za-z0-9_]{3,32})\b")
TRACKING_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id", "fbclid", "gclid", "igshid", "si", "s", "ref", "ref_src", "feature", "mc_cid", "mc_eid", "_ga", "yclid"}


def canonical_url(u: str) -> str:
    """Lower-case scheme/host, strip www., tracking parameters, fragments and trailing slashes; unwrap t.me/s/."""
    try:
        p = urllib.parse.urlsplit(u.strip().rstrip(".,;:!?)»”'\""))
    except ValueError:
        return u
    host = (p.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]
    if host in ("m.youtube.com", "youtu.be"):
        if host == "youtu.be":
            return f"https://youtube.com/watch?v={p.path.strip('/')}"
        host = "youtube.com"
    path = p.path or "/"
    if host == "t.me" and path.startswith("/s/"):
        path = path[2:]
    q = [(k, v) for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=False) if k.lower() not in TRACKING_PARAMS]
    if host == "youtube.com":
        q = [(k, v) for k, v in q if k == "v"]
    path = re.sub(r"/{2,}", "/", path)
    if len(path) > 1 and path.endswith("/"):
        path = path[:-1]
    return urllib.parse.urlunsplit(("https", host, path, urllib.parse.urlencode(q), ""))


def domain_of(u: str) -> str:
    try:
        h = (urllib.parse.urlsplit(u).hostname or "").lower()
    except ValueError:
        return ""
    return h[4:] if h.startswith("www.") else h


def registrable_domain(host: str) -> str:
    """Rough eTLD+1 (handles the common two-level suffixes used by the tracked outlets)."""
    parts = host.split(".")
    if len(parts) <= 2:
        return host
    two = ".".join(parts[-2:])
    if two in {"co.uk", "com.cn", "org.cn", "gov.cn", "com.ru", "org.ru", "co.ir", "ac.ir", "gov.ir", "org.ir", "com.au", "co.jp", "com.tr", "com.br"}:
        return ".".join(parts[-3:])
    return two


def extract_entities(text: str, extra_urls: Iterable[str] = ()) -> dict:
    urls, seen = [], set()
    for u in list(URL_RE.findall(text or "")) + [x for x in extra_urls if x]:
        c = canonical_url(u)
        if c not in seen:
            seen.add(c); urls.append(c)
    tags = sorted({h.lower() for h in HASHTAG_RE.findall(text or "") if not h.isdigit()})
    mentions = sorted({m.lower() for m in MENTION_RE.findall(text or "")})
    doms = sorted({registrable_domain(domain_of(u)) for u in urls if domain_of(u)})
    return {"urls": urls[:25], "domains": doms[:25], "hashtags": tags[:25], "mentions": mentions[:25]}


_SCRIPTS = [("ru", re.compile(r"[Ѐ-ӿ]")), ("zh", re.compile(r"[一-鿿]")), ("fa", re.compile(r"[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")),
            ("ko", re.compile(r"[가-힯]")), ("ja", re.compile(r"[぀-ヿ]"))]
_LATIN = re.compile(r"[A-Za-z]")
_ES = re.compile(r"\b(el|la|los|las|que|de|del|para|con|por|una|está|según)\b", re.I)
_FR = re.compile(r"\b(le|les|des|est|une|pour|avec|dans|selon|qui)\b", re.I)
_DE = re.compile(r"\b(der|die|das|und|nicht|mit|für|ist|auf|eine)\b", re.I)
_AR = re.compile(r"[ةى]")  # ta marbuta / alef maksura: Arabic rather than Persian


def guess_lang(text: str) -> str:
    """Script-level language guess (good enough to route lexicons; not a translator)."""
    t = text or ""
    n = max(1, len(re.sub(r"\s", "", t)))
    best, frac = "", 0.0
    for code, rx in _SCRIPTS:
        f = len(rx.findall(t)) / n
        if f > frac:
            best, frac = code, f
    if frac >= 0.2:
        if best == "fa" and len(_AR.findall(t)) > 3 and "پ" not in t and "گ" not in t and "چ" not in t:
            return "ar"
        return best
    if len(_LATIN.findall(t)) / n >= 0.3:
        es, fr, de = len(_ES.findall(t)), len(_FR.findall(t)), len(_DE.findall(t))
        m = max(es, fr, de)
        if m >= 3:
            return "es" if m == es else ("fr" if m == fr else "de")
        return "en"
    return best or "und"


# ------------------------------------------------------------------ misc
def sha1(*parts: Any) -> str:
    h = hashlib.sha1()
    for p in parts:
        h.update(str(p).encode("utf-8", "replace"))
        h.update(b"\x1f")
    return h.hexdigest()


def now() -> int:
    return int(time.time())


def iso(ts: Optional[int]) -> str:
    if not ts:
        return ""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts))


def day(ts: int) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(ts))


def parse_iso(s: str) -> Optional[int]:
    """ISO-8601 or RFC-2822 to epoch seconds (UTC)."""
    if not s:
        return None
    s = str(s).strip()
    import datetime as _dt
    try:
        d = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=_dt.timezone.utc)
        return int(d.timestamp())
    except ValueError:
        pass
    try:
        from email.utils import parsedate_to_datetime
        d = parsedate_to_datetime(s)
        if d.tzinfo is None:
            d = d.replace(tzinfo=_dt.timezone.utc)
        return int(d.timestamp())
    except Exception:
        return None


def parse_count(s: str) -> Optional[int]:
    """'12.3K' / '1.2M' / '4 567' -> int."""
    if s is None:
        return None
    t = str(s).strip().replace(" ", "").replace(" ", "").replace(",", "")
    m = re.match(r"^([0-9]*\.?[0-9]+)([KkMmBb]?)$", t)
    if not m:
        return None
    v = float(m.group(1))
    mult = {"": 1, "k": 1e3, "m": 1e6, "b": 1e9}[m.group(2).lower()]
    return int(round(v * mult))


def gen_token() -> str:
    return secrets.token_urlsafe(24)


def chunks(seq: list, n: int) -> Iterable[list]:
    for i in range(0, len(seq), n):
        yield seq[i:i + n]
