"""Loopback server: the dashboard (same origin) and its JSON API.

  GET  /                      dashboard (index.html, app.js, style.css)
  GET  /api/snapshot?days=7   everything the dashboard renders (cached briefly)
  GET  /api/post/<id>         one post with full text, breakout observations and label
  GET  /api/search?q=&country=&platform=&limit=   full-text search over the store
  GET  /api/status            counts, lanes (with region, route class, probe record), recent runs, spend
  GET  /api/boards            the hot boards' latest reads, new entries and early drops
  GET  /api/probes            the last `publius probe` result per lane
  POST /api/label             {"post_id": "...", "level": 1..6, "note": "..."} — analyst ground truth for calibration

Binds to loopback only and refuses requests whose Host header is not the loopback address it serves (a DNS-rebinding
page cannot read the API). Every /api call needs the token (header x-publius-token, or ?k=), compared in constant
time; the server never runs without one (a session token is generated when the config has none). POST also requires a
same-origin request (no cross-site form posts) and a JSON object body of at most 4 KB."""
from __future__ import annotations

import hmac
import json
import logging
import mimetypes
import os
import secrets
import socket
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import __version__
from .config import LOOPBACK
from .store import Store

log = logging.getLogger("publius.server")
DASH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard")


def make_handler(cfg: dict, store: Store):
    token = str(cfg["server"].get("token") or "")
    if not token:
        raise ValueError("server.token is empty; the API never runs without a token")
    port = int(cfg["server"]["port"])
    hosts = {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}
    if port == 80:                                   # browsers omit the default port from Host and Origin
        hosts |= {"127.0.0.1", "localhost", "[::1]"}
    origins = {f"http://{h}" for h in hosts}
    cache: dict = {"t": 0.0, "days": None, "body": b""}
    lock = threading.Lock()

    class H(BaseHTTPRequestHandler):
        server_version = "PUBLIUS/" + __version__

        def log_message(self, fmt, *args):
            log.debug("%s " + fmt, self.address_string(), *args)

        def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8"):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(body)

        def _json(self, code: int, obj):
            self._send(code, json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8"))

        def _authed(self, q: dict) -> bool:
            given = self.headers.get("x-publius-token") or (q.get("k") or [""])[0]
            return hmac.compare_digest(given.encode("utf-8"), token.encode("utf-8"))

        def _host_ok(self) -> bool:
            return (self.headers.get("Host") or "").lower() in hosts

        def do_GET(self):
            u = urllib.parse.urlsplit(self.path)
            q = urllib.parse.parse_qs(u.query)
            path = u.path
            if not self._host_ok():
                self._send(421, b"misdirected request: this server answers only on its loopback address", "text/plain"); return
            if not path.startswith("/api/"):
                name = "index.html" if path in ("/", "") else path.lstrip("/")
                fp = os.path.normpath(os.path.join(DASH, name))
                if not fp.startswith(DASH + os.sep) or not os.path.isfile(fp):
                    self._send(404, b"not found", "text/plain"); return
                ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript",):
                    ctype += "; charset=utf-8"
                with open(fp, "rb") as f:
                    self._send(200, f.read(), ctype)
                return
            if not self._authed(q):
                self._json(401, {"ok": False, "error": "token required (x-publius-token header or ?k=)"}); return
            try:
                from . import pipeline
                if path == "/api/snapshot":
                    days = max(1, min(30, int((q.get("days") or ["7"])[0])))
                    with lock:
                        if time.time() - cache["t"] > 60 or cache["days"] != days:
                            cache["body"] = json.dumps(pipeline.snapshot(cfg, store, days=days), ensure_ascii=False, default=str).encode("utf-8")
                            cache["t"], cache["days"] = time.time(), days
                        body = cache["body"]
                    self._send(200, body)
                elif path.startswith("/api/post/"):
                    pid = path.rsplit("/", 1)[1]
                    p = store.post(pid)
                    if not p:
                        self._json(404, {"ok": False}); return
                    lab = next((l for l in store.labels() if l["post_id"] == pid), None)
                    self._json(200, {"ok": True, "post": pipeline._slim(p, full_text=True), "observations": store.breakout_obs(pid), "label": lab})
                elif path == "/api/search":
                    rows = store.posts(q=(q.get("q") or [""])[0][:200], country=(q.get("country") or [""])[0], platform=(q.get("platform") or [""])[0],
                                       limit=max(1, min(500, int((q.get("limit") or ["200"])[0]))), since=int(time.time()) - 30 * 86400)
                    self._json(200, {"ok": True, "posts": [pipeline._slim(p) for p in rows]})
                elif path == "/api/status":
                    self._json(200, {"ok": True, "version": __version__, "counts": store.counts(), "lanes": pipeline.lane_status(cfg, store), "runs": store.recent_runs(30),
                                     "last_cycle": json.loads(store.kv_get("last_cycle", "{}") or "{}")})
                elif path == "/api/boards":
                    from . import boards as _boards
                    self._json(200, {"ok": True, "boards": _boards.summary(store)})
                elif path == "/api/probes":
                    rows = store.conn().execute("SELECT k, v FROM kv WHERE k LIKE 'probe:%'").fetchall()
                    self._json(200, {"ok": True, "probes": {r[0].split(":", 1)[1]: json.loads(r[1]) for r in rows}})
                else:
                    self._json(404, {"ok": False, "error": "unknown endpoint"})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:
                log.exception("request failed")
                self._json(500, {"ok": False, "error": str(e)[:300]})

        def do_POST(self):
            u = urllib.parse.urlsplit(self.path)
            q = urllib.parse.parse_qs(u.query)
            if not self._host_ok():
                self._json(421, {"ok": False, "error": "misdirected request"}); return
            origin = self.headers.get("Origin", "")
            if origin and origin not in origins:
                self._json(403, {"ok": False, "error": "cross-origin POST refused"}); return
            if not self._authed(q):
                self._json(401, {"ok": False, "error": "token required"}); return
            if u.path != "/api/label":
                self._json(404, {"ok": False}); return
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if n > 4096:
                    self._json(413, {"ok": False, "error": "body too large"}); return
                d = json.loads(self.rfile.read(n) or b"{}")
                if not isinstance(d, dict):
                    self._json(400, {"ok": False, "error": "body must be a JSON object"}); return
                pid, lvl = str(d.get("post_id", "")), int(d.get("level", 0))
                if not store.post(pid) or not 1 <= lvl <= 6:
                    self._json(400, {"ok": False, "error": "post_id must exist and level must be 1..6"}); return
                store.set_label(pid, lvl, "analyst", str(d.get("note", ""))[:300])
                cache["t"] = 0
                self._json(200, {"ok": True})
            except (ValueError, TypeError, json.JSONDecodeError):
                self._json(400, {"ok": False, "error": "bad JSON"})
    return H


class _Server6(ThreadingHTTPServer):
    address_family = socket.AF_INET6


class Server:
    def __init__(self, cfg: dict, store: Store):
        host, port = cfg["server"]["host"], int(cfg["server"]["port"])
        if host not in LOOPBACK:
            raise ValueError("PUBLIUS only binds to loopback")
        self.generated_token = False
        if not str(cfg["server"].get("token") or ""):
            cfg["server"]["token"] = secrets.token_urlsafe(24)       # never serve the API open; this token lasts for the session
            self.generated_token = True
        self.httpd = (_Server6 if host == "::1" else ThreadingHTTPServer)((host, port), make_handler(cfg, store))
        self.httpd.daemon_threads = True
        self.url = f"http://{'127.0.0.1' if host == 'localhost' else ('[::1]' if host == '::1' else host)}:{port}/"
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="publius-api", daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        try:
            self.httpd.shutdown(); self.httpd.server_close()
        except Exception:
            pass
