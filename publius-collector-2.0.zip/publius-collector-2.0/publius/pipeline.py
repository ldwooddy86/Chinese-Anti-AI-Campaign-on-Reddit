"""Orchestration: lanes → collect → analyse (features, coordination, velocity, scoring) → breakout checks → auto-labels
→ calibration, plus the snapshot builder the dashboard and the exporter share."""
from __future__ import annotations

import importlib
import json
import logging
import math
import os
import time
from collections import Counter, defaultdict
from typing import Optional

from . import __version__
from .analysis import breakout as bo
from .analysis import coordination as co
from .analysis import features as fx
from .analysis import ghostloom as gl
from .analysis import trends as tr
from .analysis.model import Model, load as load_model
from .connectors.base import REGISTRY, Connector
from .store import Store
from .util import day, iso, now
from .watchlist import operations, provenance


def _jload(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return json.load(f)


log = logging.getLogger("publius.pipeline")
for _m in ("telegram_web", "rss", "youtube", "x_api", "social", "news_boards", "gated", "telegram_bot", "cn_platforms", "ir_platforms", "ru_platforms", "dprk", "bridges", "breakout_extra"):
    importlib.import_module(f"publius.connectors.{_m}")

SECTION = {"telegram": "telegram_web", "telegram_user": "telegram", "facebook": "meta", "instagram": "meta"}
COUNTRIES = ("RU", "CN", "IR", "KP")
SOURCE_PLATFORM = {"telegram_user": "telegram", "telegram_bot": "telegram"}      # lanes that read another lane's source rows
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def lanes(cfg: dict, store: Store) -> dict[str, Connector]:
    out = {}
    for plat, cls in REGISTRY.items():
        sect = SECTION.get(plat, plat)
        out[plat] = cls(cfg.get(sect, {}), cfg, store)
    return out


def lane_status(cfg: dict, store: Store) -> list[dict]:
    res = []
    srcs = store.sources()
    counts = Counter(s["platform"] for s in srcs)
    live = Counter(s["platform"] for s in srcs if s.get("status") == "live")
    closed = Counter(s["platform"] for s in srcs if s.get("status") in ("closed", "refused", "no_route"))
    for plat, c in lanes(cfg, store).items():
        ok, why = c.ready()
        sok, swhy = c.search_ready()
        sp = SOURCE_PLATFORM.get(plat, plat)
        try:
            probe = json.loads(store.kv_get(f"probe:{plat}", "null") or "null")
        except ValueError:
            probe = None
        row = {"platform": plat, "label": c.label, "enabled": c.enabled(), "ready": ok, "why": why, "breakout_lane": c.breakout_lane,
               "breakout_ready": bool(c.breakout_lane and sok), "breakout_why": swhy if c.breakout_lane else "",
               "sources": counts.get(sp, 0), "live_sources": live.get(sp, 0), "closed_sources": closed.get(sp, 0), "probe": probe}
        row.update(c.meta())
        res.append(row)
    return res


def probe(cfg: dict, store: Store, only: Optional[list[str]] = None) -> dict:
    """One credential-free read per lane from the operator's own network, recorded in kv as probe:<platform>. This is
    how 'coded' lanes become 'verified' or 'closed': the build network could reach none of the domestic platforms."""
    out = {}
    for plat, c in lanes(cfg, store).items():
        if only and plat not in only:
            continue
        t0 = time.time()
        try:
            r = c.probe()
        except Exception as e:
            r = {"ok": False, "note": str(e)[:160]}
        r = dict(r, ts=now(), seconds=round(time.time() - t0, 1))
        store.kv_set(f"probe:{plat}", json.dumps(r))
        out[plat] = r
    return out


# ------------------------------------------------------------------------------------------------ collect
def collect(cfg: dict, store: Store, only: Optional[list[str]] = None) -> dict:
    summary = {}
    for plat, c in lanes(cfg, store).items():
        if only and plat not in only:
            continue
        ok, why = c.ready()
        if not c.enabled() or not ok:
            summary[plat] = {"skipped": why if c.enabled() else "disabled"}
            continue
        rid = store.run_start(plat)
        t0 = time.time()
        cap = int(cfg.get(SECTION.get(plat, plat), {}).get("max_channels_per_cycle", 0) or 0) or None
        try:
            st = c.collect(max_sources=cap)
            store.run_end(rid, st.items, len(st.errors), "; ".join(st.errors[:5]))
            summary[plat] = {"items": st.items, "sources": st.sources, "errors": len(st.errors), "seconds": round(time.time() - t0, 1), "first_errors": st.errors[:3]}
        except Exception as e:
            store.run_end(rid, 0, 1, str(e))
            summary[plat] = {"error": str(e)[:200]}
            log.exception("lane %s failed", plat)
    return summary


# ------------------------------------------------------------------------------------------------ analyse
def _velocity(store: Store, p: dict, cache: dict) -> float:
    m = (p.get("metrics") or {})
    v = m.get("views") if m.get("views") is not None else m.get("likes")
    if v is None:
        return 0.0
    key = (p["source_id"], "views" if m.get("views") is not None else "likes")
    if key not in cache:
        cache[key] = store.source_engagement_baseline(p["source_id"], key[1])
    mu, sd, n = cache[key]
    if n < 5 or sd <= 1e-6:
        return 0.0
    age_h = max(1.0, (now() - int(p["ts"])) / 3600.0)
    # compare like with like: scale the source's typical log-engagement to this post's age on a saturating curve
    expected = mu + math.log(min(1.0, 0.35 + 0.65 * (1 - math.exp(-age_h / 12.0))))
    return max(-2.0, min(4.0, (math.log1p(float(v)) - expected) / sd))


def attach_own_domains(posts: list[dict], srcs: dict[str, dict]) -> None:
    """An outlet's own site (from its RSS feed) is attached to every post by the same entity, so its accounts linking
    their own articles are not read as coordinated link sharing."""
    from .util import domain_of, registrable_domain
    own = defaultdict(set)
    for s in srcs.values():
        if s["platform"] == "rss" and s["handle"].startswith("http"):
            own[s["entity_id"]].add(registrable_domain(domain_of(s["handle"])))
    for p in posts:
        p["own_domains"] = sorted(own.get((srcs.get(p["source_id"]) or {}).get("entity_id"), set()))


def analyse(cfg: dict, store: Store, window_days: int = 10, rescore_all: bool = False) -> dict:
    model = load_model(store)
    posts = store.posts(since=now() - window_days * 86400, limit=100000)
    srcs = {s["id"]: s for s in store.sources()}
    attach_own_domains(posts, srcs)
    graph = co.link_graph(posts)
    cmap = co.clusters(posts, graph=graph)
    diff = co.diffusion_features(posts, cmap, graph=graph)
    vel_cache: dict = {}
    flags = Counter()
    with store.bulk():
        _score_all(cfg, store, model, posts, srcs, cmap, diff, vel_cache, flags)
    sizes = Counter(cmap.values())
    return {"scored": len(posts), "flags": dict(flags), "clusters": sum(1 for n in sizes.values() if n > 1), "largest_cluster": max(sizes.values(), default=0),
            "graph": {k: v for k, v in graph.items() if k != "adj"}, "model": model.version}


def _score_all(cfg, store, model, posts, srcs, cmap, diff, vel_cache, flags) -> None:
    for p in posts:
        src = srcs.get(p["source_id"]) or {}
        f = fx.extract(p, src)
        d = diff.get(p["id"], {})
        x = dict(f["x"])
        x["velocity_z"] = _velocity(store, p, vel_cache)
        x["echo"] = float(d.get("echo", 0.0))
        x["cross_country"] = float(d.get("cross_country", 0.0))
        x["platforms_seen"] = float(d.get("platforms_seen", 0.0))
        b = p.get("breakout") or {}
        pick = sum(int(o.get("count") or 0) for ln, o in (b.get("lanes") or {}).items() if ln != "gdelt")
        x["early_pickup"] = math.log1p(pick)
        sev = int(f["severity"])            # the rule severity scores; a second opinion is advisory (shown, and flagged when 2+ levels apart)
        prov = provenance(src)
        sc = model.score(x, sev, cfg, affil_verified=bool(prov.get("affil_verified", True)))
        # Pre-outcome record, frozen at first scoring: calibration trains on x_t0 (never on features that already contain
        # observed pickups), and the breakout selection is decided once from it, so selection cannot depend on the outcome.
        old = p.get("features") or {}
        x_t0, t0_ts, sel = old.get("x_t0"), old.get("t0_ts"), old.get("sel")
        if x_t0 is None:
            x_t0, t0_ts = dict(x, early_pickup=0.0), now()
        if sel is None:
            rr0 = model.score(x_t0, int(f["severity"]), cfg)["rr"]
            sel = bo.decide_selection(p["id"], int(f["severity"]), rr0, cfg)
        feats = {"x": x, "x_t0": x_t0, "t0_ts": t0_ts, "t0_lag_h": round((t0_ts - int(p["ts"])) / 3600.0, 2), "sel": sel,
                 "evidence": f["evidence"], "topics": f["topics"], "us": f["us"], "domestic": f["domestic"], "flashpoints": f["flashpoints"],
                 "countries": f["countries"], "severity_rule": f["severity_rule"], "rule_severity": f["severity"], "diffusion": d}
        store.update_analysis(p["id"], features=feats, narratives=f["narratives"], severity=sev, sev_evidence=f["evidence"], score=sc, p3=sc["p3"], risk=sc["risk"], rr=sc["rr"],
                              flag=sc["flag"], scored_ts=now(), model_version=model.version, cluster_id=cmap.get(p["id"]))
        if sc["flag"]:
            flags[sc["flag"]] += 1


def breakout_cycle(cfg: dict, store: Store) -> dict:
    ls = {k: c for k, c in lanes(cfg, store).items() if c.enabled() and c.search_ready()[0]}
    st = bo.run_checks(store, ls, cfg)
    st["auto_labels"] = bo.auto_label(store, cfg)
    st["indicator_sweeps"] = indicator_sweep(store, ls)
    return st


def indicator_sweep(store: Store, ls: dict, every_h: int = 6) -> int:
    """Covert operations have no stable handles, so their published indicators (hashtags, phrases) are counted in the
    US-audience lanes instead: aggregate counts only, public figures above the threshold named, nobody else recorded."""
    last = {(r["op_id"], r["indicator"], r["lane"]): r["ts"] for r in store.indicator_latest()}
    n = 0
    for op in operations(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))):
        ind = op.get("indicators") or {}
        items = [("hashtag", "#" + h) for h in ind.get("hashtags", [])] + [("phrase", p) for p in ind.get("phrases", []) if len(p.split()) >= 2]
        for kind, q in items:
            for lane, conn in ls.items():
                if lane == "gdelt" and kind == "hashtag":
                    continue
                if now() - last.get((op["id"], q, lane), 0) < every_h * 3600:
                    continue
                try:
                    r = conn.search(q, kind=kind, since=now() - 7 * 86400)
                except Exception as e:
                    log.debug("indicator %s on %s failed: %s", q, lane, e)
                    continue
                if r.ok:
                    store.add_indicator_obs(op["id"], q, lane, r.count, r.public_figures, r.note)
                    n += 1
    return n


def calibrate(cfg: dict, store: Store, activate: bool = True, max_t0_lag_h: float = 6.0, purge_s: Optional[int] = None) -> dict:
    """Rows = labelled posts that were SELECTED for measurement (rule or audit), first scored within max_t0_lag_h of
    publication (so x_t0 is genuinely early), and not censored. Weight = 1/P(selected). Analyst labels correct the level
    of selected posts; analyst labels on unselected posts are reported but excluded (their selection is unknown)."""
    from .analysis.calibrate import calibrate as _cal
    rows, excluded = [], Counter()
    for lab in store.labels():
        p = store.post(lab["post_id"])
        f = (p or {}).get("features") or {}
        if not p or not f.get("x_t0"):
            excluded["no pre-outcome features"] += 1; continue
        sel = f.get("sel") or {}
        if not sel.get("selected"):
            excluded["not in the measured sample"] += 1; continue
        if float(f.get("t0_lag_h") or 0) > max_t0_lag_h:
            excluded[f"first scored more than {max_t0_lag_h:g} h after posting"] += 1; continue
        if (p.get("breakout") or {}).get("censored") and lab["source"] != "analyst":
            excluded["censored (fewer than two social lanes)"] += 1; continue
        rows.append({"x": f["x_t0"], "y": int(lab["level"]), "w": 1.0 / max(1e-3, float(sel.get("p") or 1.0)), "ts": p["ts"]})
    horizon = int(cfg.get("model", {}).get("horizon_days", 7)) * 86400
    res = _cal(rows, gap_s=horizon if purge_s is None else int(purge_s))
    res["excluded"] = dict(excluded)
    applied = res.get("status") == "ok" and activate
    if applied:
        store.save_model(res["version"], res["params"], {k: v for k, v in res.items() if k not in ("params",)})
    keep = {k: v for k, v in res.items() if k != "params"}
    if res.get("params"):
        keep["fit"] = {k: res["params"].get(k) for k in ("beta", "beta_sd", "theta", "theta_sd", "iterations")}
    store.kv_set("last_calibration", json.dumps(dict(keep, applied=applied, ts=now()), default=str))
    return res


def cycle(cfg: dict, store: Store) -> dict:
    t0 = time.time()
    out = {"collect": collect(cfg, store)}
    out["analyse"] = analyse(cfg, store)
    out["breakout"] = breakout_cycle(cfg, store)
    if out["breakout"].get("checked"):
        out["analyse_after_breakout"] = analyse(cfg, store)
    store.kv_set("last_cycle", json.dumps({"ts": now(), "seconds": round(time.time() - t0, 1)}))
    return out


# ------------------------------------------------------------------------------------------------ snapshot
PLATFORM_LABEL = {"rss": "its website feed", "youtube": "YouTube", "telegram": "Telegram", "x": "X", "facebook": "Facebook", "instagram": "Instagram",
                  "bluesky": "Bluesky", "mastodon": "Mastodon", "rutube": "Rutube", "odysee": "Odysee", "vk": "VK", "cn_hotlist": "a Chinese hot list",
                  "weibo": "Weibo", "bilibili": "Bilibili", "zhihu": "Zhihu", "douyin": "Douyin's hot board", "wechat_mp": "WeChat", "rsshub": "an RSSHub route",
                  "bale": "Bale", "splus": "Soroush Plus", "aparat": "Aparat", "virasty": "Virasty", "eitaa": "Eitaa", "ok": "Odnoklassniki", "dzen": "Dzen", "max": "Max",
                  "dprk_web": "its own website", "kcnawatch": "KCNA Watch", "discord": "Discord", "tiktok": "TikTok", "threads": "Threads"}


def _fill_brief(brief: dict, cur: list, prov: list, fps: list, fp_links: dict, model, lanes_ready: Optional[list] = None) -> dict:
    """Recompute the figures the analyst text cites ({token}s) from the current window."""
    if not brief:
        return brief
    n = len(cur) or 1
    dom = [p for p in cur if (p.get("features") or {}).get("domestic")]
    dom_v = [p for p in dom if not _unverified(p)]
    griev = {f["id"] for f in fps if f.get("grievance")}
    ver = [p for p in cur if not _unverified(p)]
    top = max((p for p in ver if (p.get("severity") or 0) >= 1), key=lambda p: p.get("p3") or 0, default=None)     # posts on US domestic affairs
    top_any = max(ver, key=lambda p: p.get("p3") or 0, default=None)
    narr = Counter(x for p in dom_v for x in (p.get("narratives") or []))
    fpc = Counter(fid for p in dom_v for fid in ((p.get("features") or {}).get("flashpoints") or []) if fid in griev)
    ndefs = {d["id"]: d["name"] for d in fx.narratives()}
    fpt = {f["id"]: f["title"] for f in fps}
    ups, unattributed = Counter(), Counter()
    for r in prov:
        if "news-pravda" in r["aggregator"]:
            (ups if r.get("watchlisted") else unattributed)[r["upstream"]] += r["items"]
    rate = "n/a"
    pts = sorted(p["ts"] for p in cur if str(p.get("source_id", "")).startswith("rss:https://usa.news-pravda.com"))
    if pts:
        first_full, last_full = (pts[0] // 3600 + 1) * 3600, (pts[-1] // 3600) * 3600       # whole clock hours only
        hours = (last_full - first_full) // 3600
        if hours >= 2:
            rate = f"{sum(1 for t in pts if first_full <= t < last_full) / hours:.0f}"
    vals = {
        "pravda_usa_rate": rate,
        "posts": f"{len(cur):,}", "domestic_pct": f"{100 * len(dom) / n:.1f}%", "s2plus": str(sum(1 for p in cur if (p.get("severity") or 0) >= 2)),
        "alert": str(sum(1 for p in cur if (p.get("score") or {}).get("flag") == "ALERT")), "watch": str(sum(1 for p in cur if (p.get("score") or {}).get("flag") == "WATCH")),
        "max_p3": f"{100 * (top.get('p3') or 0):.1f}%" if top else "n/a", "max_p3_word": ((top or {}).get("score") or {}).get("word", "n/a"),
        "max_p3_source": (f"{top.get('s_name')} on {PLATFORM_LABEL.get(top.get('platform'), top.get('platform'))}" if top else "n/a"),
        "max_p3_any_sentence": ("" if not top_any or (top and top_any["id"] == top["id"]) else
                                f" The highest estimate for any post, {100 * (top_any.get('p3') or 0):.1f}% ({top_any.get('s_name')} on {PLATFORM_LABEL.get(top_any.get('platform'), top_any.get('platform'))}), belongs to "
                                "coverage the severity rules do not read as US-domestic, so it carries no unrest weight."),
        "top_narratives": ", ".join(f"{ndefs.get(k, k)} ({v})" for k, v in narr.most_common(3)) or "none",
        "top_flashpoints": ", ".join(f"{fpt.get(k, k)} ({v})" for k, v in fpc.most_common(3)) or "none",
        "breakout_lanes": (", ".join(lanes_ready) + (" only" if len(lanes_ready) == 1 else "")) if lanes_ready else "none",
        "pravda_top_upstreams": (", ".join(f"{u} ({c})" for u, c in ups.most_common(5)) or "no watchlisted channels") + f", plus {len(unattributed)} channels outside the watchlist carrying {sum(unattributed.values())} items",
    }

    class _D(dict):
        def __missing__(self, k):
            return "{" + k + "}"
    out = dict(brief)
    out["bluf"] = str(brief.get("bluf", "")).format_map(_D(vals))
    out["kjs"] = [dict(k, text=str(k.get("text", "")).format_map(_D(vals))) for k in brief.get("kjs", [])]
    out["figures"] = vals
    return out


def _unverified(p: dict) -> bool:
    try:
        return json.loads(p.get("s_prov") or "{}").get("affil_verified", True) is False
    except Exception:
        return False


def _llm_view(llm) -> Optional[dict]:
    if not isinstance(llm, dict) or not isinstance(llm.get("severity"), int):
        return None
    cta = llm.get("cta") if isinstance(llm.get("cta"), dict) else {}
    return {"sev": llm["severity"], "rule_sev": llm.get("rule_severity"), "disagree": bool(llm.get("disagreement")), "rationale": str(llm.get("rationale", ""))[:400],
            "narrative": str(llm.get("narrative", ""))[:80], "us_domestic": llm.get("us_domestic"), "targets_group": llm.get("targets_group"), "model": llm.get("model", ""),
            "cta": {k: str(cta.get(k, ""))[:120] for k in ("present", "what", "when", "where") if cta.get(k) not in (None, "")}}


def _slim(p: dict, full_text: bool = False, label: Optional[dict] = None) -> dict:
    f = p.get("features") or {}
    sc = p.get("score") or {}
    text = p.get("text") or ""
    return {"id": p["id"], "ts": p["ts"], "src": p["source_id"], "name": p.get("s_name") or p["source_id"], "handle": p.get("s_handle") or "", "platform": p.get("platform"),
            "country": p.get("country"), "cat": p.get("category"), "tier": p.get("s_tier") or "", "grade": p.get("s_grade") or "", "url": p.get("url") or "", "title": (p.get("title") or "")[:300],
            "text": text if full_text else text[:1000], "lang": p.get("lang"), "urls": (p.get("urls") or [])[:6], "tags": (p.get("hashtags") or [])[:8], "mentions": (p.get("mentions") or [])[:8],
            "metrics": p.get("metrics") or {}, "media": p.get("media") or {}, "upstream": (p.get("upstream") or [])[:6], "narr": p.get("narratives") or [], "sev": p.get("severity") or 0,
            "sev_rule": f.get("severity_rule", ""), "ev": {k: v for k, v in (f.get("evidence") or {}).items() if k in ("mobilization_call", "violence_endorse", "violence", "dehumanization", "delegitimization", "conspiracy", "debunked", "partisan", "moral_emotional", "decline_frame") or k.startswith("topic:")},
            "flash": f.get("flashpoints") or [], "countries": (f.get("countries") or [])[:8], "p3": sc.get("p3"), "p3_lo": sc.get("p3_lo"), "p3_hi": sc.get("p3_hi"), "p": sc.get("p") or {},
            "word": sc.get("word", ""), "rr": sc.get("rr"), "risk": sc.get("risk"), "flag": sc.get("flag", ""), "capped": sc.get("capped_unverified", False), "contrib": sc.get("contrib") or [],
            "diff": {k: v for k, v in (f.get("diffusion") or {}).items() if k in ("cluster_size", "echo_sources", "cluster_countries")}, "cluster": p.get("cluster_id"), "breakout": p.get("breakout") or {},
            "unverified": _unverified(p), "llm": _llm_view(p.get("llm")), "sim": bool((p.get("breakout") or {}).get("simulated")),
            "label": {"level": label["level"], "source": label["source"], "note": label.get("note") or ""} if label else None}


def snapshot(cfg: dict, store: Store, days: int = 7, baseline_days: int = 28, max_posts: int = 40000) -> dict:
    t_end = now()
    cur = store.posts(since=t_end - days * 86400, limit=max_posts)
    base = store.posts(since=t_end - (days + baseline_days) * 86400, until=t_end - days * 86400, limit=20000)
    if len(base) < 50:   # young store: compare the last 48 h with the rest of the window instead
        split = t_end - 2 * 86400
        base = [p for p in cur if p["ts"] < split]
        cur_trend = [p for p in cur if p["ts"] >= split]
        trend_note = "Baseline is the earlier part of the collection window (store younger than the baseline period): last 48 h vs the days before."
    else:
        cur_trend = cur
        trend_note = f"Last {days} days vs the preceding {baseline_days} days."
    model = load_model(store)
    srcs = store.sources()
    panels = {}
    plats = sorted({p.get("platform") for p in cur if p.get("platform")})
    for c in ("ALL",) + COUNTRIES:
        pc = cur if c == "ALL" else [p for p in cur if p.get("country") == c]
        for cat in ("all", "gov", "media", "aggregator", "domestic_aggregator"):
            sl = pc if cat == "all" else [p for p in pc if p.get("category") == cat]
            if sl or cat == "all":
                panels[f"{c}|{cat}|all"] = tr.hamilton_panels(sl)
        for pl in plats:
            sl = [p for p in pc if p.get("platform") == pl]
            if sl:
                panels[f"{c}|all|{pl}"] = tr.hamilton_panels(sl)
    days_list = sorted({day(p["ts"]) for p in cur})
    queue = sorted([p for p in cur if (p.get("score") or {}).get("flag")], key=lambda p: -(p.get("risk") or 0))
    top_risk = sorted([p for p in cur if p.get("risk")], key=lambda p: -(p.get("risk") or 0))[:400]
    ids_needed = {p["id"] for p in queue} | {p["id"] for p in top_risk}
    for pan in panels.values():
        ids_needed |= set(pan["top_posts"])
    feed = sorted(cur, key=lambda p: -p["ts"])
    known = {s["id"] for s in srcs if s.get("enabled")}          # parked candidates and switched-off individuals are not attributed
    prov = co.provenance_graph(cur, known)
    attach_own_domains(cur, {s["id"]: s for s in srcs})
    cls = co.coordinated_link_sharing(cur)
    clusters = defaultdict(list)
    for p in cur:
        if p.get("cluster_id"):
            clusters[p["cluster_id"]].append(p)
    echo = []
    for cid, ps in clusters.items():
        srcset = {p["source_id"] for p in ps}
        if len(srcset) < 2:
            continue
        cc = sorted({p.get("country") for p in ps if p.get("country")})
        verified = [p for p in ps if not _unverified(p)]
        lead = max(verified or ps, key=lambda p: p.get("risk") or 0)
        echo.append({"cluster": cid, "posts": len(ps), "sources": len(srcset), "countries": cc, "platforms": sorted({p.get("platform") for p in ps}),
                     "first": min(p["ts"] for p in ps), "last": max(p["ts"] for p in ps), "lead": lead["id"], "max_risk": lead.get("risk") or 0,
                     "title": (lead.get("title") or lead.get("text") or "")[:160], "unverified_only": not verified})
    echo.sort(key=lambda e: (-len(e["countries"]), -e["sources"], -e["max_risk"]))
    for e in echo[:150]:
        ids_needed.add(e["lead"])
    sev_hist = Counter(int(p.get("severity") or 0) for p in cur)
    flag_hist = Counter((p.get("score") or {}).get("flag") or "none" for p in cur)
    plat_hist = Counter(p.get("platform") for p in cur)
    country_hist = Counter(p.get("country") for p in cur)
    by_day = defaultdict(lambda: Counter())
    for p in cur:
        by_day[day(p["ts"])][p.get("country") or "?"] += 1
    narr = tr.narrative_matrix(cur, days_list)
    fps = fx.flashpoints()
    fp_links, fp_unv = defaultdict(list), defaultdict(list)       # posts by individuals with unverified affiliation are kept apart
    for p in cur:
        for fid in (p.get("features") or {}).get("flashpoints") or []:
            (fp_unv if _unverified(p) else fp_links)[fid].append(p)
    for links in (fp_links, fp_unv):
        for fid, ps in links.items():
            for p in sorted(ps, key=lambda p: -(p.get("risk") or 0))[:12]:
                ids_needed.add(p["id"])
    measured = sorted((p for p in cur if (p.get("breakout") or {}).get("checks") or (p.get("breakout") or {}).get("projected") or p.get("llm")),
                      key=lambda p: (-int((p.get("breakout") or {}).get("level") or 0), -(p.get("risk") or 0)))
    ids_needed |= {p["id"] for p in measured[:800]}
    labels = store.labels()
    lab_by = {l["post_id"]: l for l in labels}
    post_index = {p["id"]: _slim(p, label=lab_by.get(p["id"])) for p in cur if p["id"] in ids_needed}
    feed_ids = [p["id"] for p in feed[:1500]]
    by_id = {p["id"]: p for p in feed[:1500]}
    for pid in feed_ids:
        if pid not in post_index:
            post_index[pid] = _slim(by_id[pid], label=lab_by.get(pid))
    observations = {}
    for pid, sp in post_index.items():
        if sp["breakout"].get("checks") or sp["breakout"].get("projected"):
            observations[pid] = [{"lane": o["lane"], "ts": o["ts"], "count": o["count"], "reach": o.get("reach_max"), "pf": o.get("public_figures") or [],
                                  "vm": o.get("violent_or_mobilising") or 0} for o in store.breakout_obs(pid)]
    censored = store.conn().execute("SELECT COUNT(*) FROM posts WHERE json_extract(breakout, '$.censored') = 1").fetchone()[0]
    label_summary = {"total": len(labels), "by_level": dict(Counter(str(l["level"]) for l in labels)), "by_source": dict(Counter(l["source"] for l in labels)), "censored": censored}
    spend = [dict(r) for r in store.conn().execute("SELECT day, lane, usd, units FROM spend ORDER BY day").fetchall()]
    calibration = json.loads(store.kv_get("last_calibration", "null") or "null")
    exercise = json.loads(store.kv_get("exercise", "null") or "null")
    src_rows = []
    for s in srcs:
        pv = provenance(s)
        src_rows.append({"id": s["id"], "entity": s["entity_id"], "platform": s["platform"], "handle": s["handle"], "name": s["name"], "country": s["country"], "cat": s["category"],
                         "tier": s["tier"], "grade": s["grade"], "status": s.get("status") or "unverified", "note": s.get("status_note") or "", "followers": s.get("followers"),
                         "last_post": s.get("last_post_ts"), "items": s.get("items") or 0, "evidence": s.get("evidence") or [], "kind": pv.get("kind", ""), "affil_verified": pv.get("affil_verified", True),
                         "enabled": bool(s.get("enabled"))})
    refs = _jload(os.path.join(DATA, "references.json"))["refs"]
    bp = os.path.join(DATA, "brief.json")
    brief = _jload(bp) if os.path.exists(bp) else {}
    lstat = lane_status(cfg, store)
    short = {"gdelt": "GDELT", "x": "X", "bluesky": "Bluesky", "reddit": "Reddit", "youtube": "YouTube", "mastodon": "Mastodon", "threads": "Threads",
             "tiktok": "TikTok", "truthsocial": "Truth Social", "gab": "Gab"}
    ready = [short.get(l["platform"], l["platform"]) for l in lstat if l.get("breakout_ready") and l.get("enabled")]
    brief = _fill_brief(brief, cur, prov, fps, fp_links, model, ready)
    if exercise:
        # the analyst assessment describes the real collection, so an exercise carries the brief computed before any simulated input
        brief = json.loads(store.kv_get("exercise_brief", "null") or "null") or brief
        sim = {l["lane"]: l for l in exercise.get("lanes", [])}
        for l in lstat:
            if l["platform"] in sim:
                l.update({"simulated": True, "real_enabled": l.get("enabled"), "real_ready": l.get("ready"), "real_why": sim[l["platform"]].get("needs") or l.get("breakout_why") or l.get("why"),
                          "enabled": True, "breakout_ready": True, "breakout_why": "simulated in this exercise"})
    plat_doc = _jload(os.path.join(DATA, "platforms.json"))
    runs = store.recent_runs(60)
    from . import boards as _boards
    by_actor = {}
    for c in COUNTRIES:
        pc = [p for p in cur if p.get("country") == c]
        sc = [s for s in src_rows if s["country"] == c]
        by_actor[c] = {"posts": len(pc), "platforms": dict(Counter(p.get("platform") for p in pc)), "sources": len(sc), "live_sources": sum(1 for s in sc if s["status"] == "live"),
                       "closed_sources": sum(1 for s in sc if s["status"] in ("closed", "refused", "no_route", "unreachable")),
                       "domestic": sum(1 for p in pc if (p.get("features") or {}).get("domestic")), "s2plus": sum(1 for p in pc if (p.get("severity") or 0) >= 2),
                       "flags": dict(Counter((p.get("score") or {}).get("flag") for p in pc if (p.get("score") or {}).get("flag"))),
                       "top_narratives": Counter(x for p in pc for x in (p.get("narratives") or [])).most_common(5)}
    return {
        "meta": {"product": cfg.get("general", {}).get("title", "PUBLIUS"), "version": __version__, "generated": iso(t_end), "window_days": days, "posts_in_window": len(cur),
                 "model": model.describe(), "trend_note": trend_note, "config": {"model": cfg.get("model", {})}, "counts": store.counts(), "days": days_list,
                 "collection_started": store.conn().execute("SELECT MIN(created) FROM posts").fetchone()[0], "exercise": exercise},
        "posts": post_index, "feed": feed_ids,
        "queue": [p["id"] for p in queue[:300]], "top_risk": [p["id"] for p in top_risk[:300]],
        "panels": panels,
        "trending": tr.fightin_words(cur_trend, base, top=40), "distinctive": tr.distinctive_by_country(cur, top=15),
        "hist": {"severity": dict(sev_hist), "flags": dict(flag_hist), "platform": dict(plat_hist), "country": dict(country_hist),
                 "by_day": {d: dict(c) for d, c in sorted(by_day.items())}},
        "narratives": {"defs": fx.narratives(), **narr},
        "flashpoints": [{**f, "linked": [p["id"] for p in sorted(fp_links.get(f["id"], []), key=lambda p: -(p.get("risk") or 0))[:12]], "n_linked": len(fp_links.get(f["id"], [])),
                         "linked_unverified": [p["id"] for p in sorted(fp_unv.get(f["id"], []), key=lambda p: -(p.get("risk") or 0))[:12]], "n_linked_unverified": len(fp_unv.get(f["id"], []))} for f in fps],
        "salience": store.salience(),
        "echo": echo[:150], "coordination": cls, "provenance": prov,
        "operations": operations(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "indicators": store.indicator_latest(),
        "sources": src_rows, "platforms": plat_doc, "lanes": lstat, "runs": runs, "refs": refs, "brief": brief, "by_actor": by_actor, "boards": _boards.summary(store),
        "observations": observations, "labels": label_summary, "spend": spend, "calibration": calibration,
        # GHOST LOOM's eight anti-AI seams, coded over every post in the window (not only the posts carried above)
        "ghostloom": gl.section(cur, _unverified, coverage="window"),
    }
