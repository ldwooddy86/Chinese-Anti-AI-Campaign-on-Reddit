"""Watchlists → sources table. One source row per (platform, handle); entity_id ties an outlet's accounts together.

Inclusion rule (the Hamilton 2.0 standard, extended): a source is watched only if it is overtly a Russian, Chinese,
Iranian or North Korean government / state-media account, OR a documented aggregator whose state linkage or state
amplification is published and graded (watchlists/aggregators.json). Nobody enters the list because of what they post.

2.0 adds four files: cn_domestic (state accounts on Weibo, Bilibili, Zhihu, WeChat, plus the hot boards), ir_messengers
(state outlets on Bale, Soroush Plus, Eitaa, Aparat), kp_base (the DPRK state sites and KCNA Watch) and discord (an
empty template: no documented state operation runs on Discord, so nothing is listed until one is)."""
from __future__ import annotations

import json
import os
from typing import Iterable

from .store import Store


def _jload(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return json.load(f)


# platforms whose watchlist accounts PUBLIUS can collect without credentials (others activate when keys are added)
KEYLESS = {"telegram", "rss", "youtube", "cn_hotlist", "odysee", "rutube", "weibo", "bilibili", "zhihu", "douyin", "aparat", "eitaa", "bale", "splus", "virasty", "dzen", "max",
           "dprk_web", "kcnawatch", "wechat_mp", "fourchan"}
STATE_MEDIA_FEEDS = [
    # (entity name, country, feed) — the Hamilton 2.0 website set; verified by `publius verify --platform rss`.
    # MFA statements: the Russian and PRC ministries render their statement lists with JavaScript and serve no RSS, so
    # PUBLIUS reads them through the ministries' own Telegram and X accounts on the Hamilton list (MID_Russia, spokesperson accounts).
    ("RT (English)", "RU", "https://www.rt.com/rss/news/"),
    ("RT — USA section", "RU", "https://www.rt.com/rss/usa/"),
    ("Sputnik Globe", "RU", "https://sputnikglobe.com/export/rss2/archive/index.xml"),
    ("TASS (English)", "RU", "https://tass.com/rss/v2.xml"),
    ("Strategic Culture Foundation", "RU", "https://strategic-culture.su/feed/"),
    ("CGTN — World", "CN", "https://www.cgtn.com/subscribe/rss/section/world.xml"),
    ("CGTN — China", "CN", "https://www.cgtn.com/subscribe/rss/section/china.xml"),
    ("Xinhua (English) — World", "CN", "https://english.news.cn/rss/worldrss.xml"),
    ("Global Times", "CN", "https://www.globaltimes.cn/rss/outbrain.xml"),
    ("People's Daily (English)", "CN", "https://en.people.cn/rss/90777.xml"),
    ("China News Service (ECNS)", "CN", "https://www.ecns.cn/rss/rss.xml"),
    ("Press TV", "IR", "https://www.presstv.ir/rss.xml"),
    ("Tasnim (English)", "IR", "https://www.tasnimnews.com/en/rss/feed/0/7/0/all-stories"),
    ("IRNA (English)", "IR", "https://en.irna.ir/rss"),
    ("Mehr (English)", "IR", "https://en.mehrnews.com/rss"),
    ("Tehran Times", "IR", "https://www.tehrantimes.com/rss"),
    ("Fars (English)", "IR", "https://www.farsnews.ir/en/rss"),
]


def _entities(root: str, names: Iterable[str]) -> list[dict]:
    ents = []
    for n in names:
        fp = os.path.join(root, "watchlists", f"{n}.json")
        if not os.path.exists(fp):
            continue
        d = _jload(fp)
        ents.extend(d.get("entities", []))
    return ents


def operations(root: str) -> list[dict]:
    fp = os.path.join(root, "watchlists", "aggregators.json")
    return _jload(fp).get("operations", []) if os.path.exists(fp) else []


def source_id(platform: str, handle: str) -> str:
    return f"{platform}:{handle.strip().lower()}"


def import_watchlists(store: Store, root: str, names: Iterable[str]) -> dict:
    """Idempotent. The watchlist files are authoritative: a source they switch off is disabled and whatever was collected
    from it is deleted; a source no longer listed is removed; a disabled candidate carries status 'candidate'."""
    n_src, by_plat, seen, cands = 0, {}, set(), 0
    for e in _entities(root, names):
        for plat, h in (e.get("handles") or {}).items():
            if not h:
                continue
            sid = source_id(plat, h)
            if sid in seen:
                continue
            seen.add(sid)
            store.upsert_source({"id": sid, "entity_id": e["id"], "platform": plat, "handle": h, "name": e["name"], "country": e["country"],
                                 "category": e["category"], "tier": e.get("tier", "overt"), "grade": e.get("grade", ""), "lang": e.get("lang", ""),
                                 "evidence": e.get("evidence", []), "enabled": bool(e.get("enabled", True)),
                                 "provenance": json.dumps({"kind": e.get("kind", ""), "affil_verified": bool(e.get("affil_verified", True)), "note": e.get("note", ""), "provenance": e.get("provenance", "")}, ensure_ascii=False)})
            if e.get("status_note") and not e.get("enabled", True):      # a parked candidate: the reason it is off is its status
                store.set_source_status(sid, "candidate", e["status_note"] + (" · " + e["note"] if e.get("note") else ""))
                cands += 1
            n_src += 1
            by_plat[plat] = by_plat.get(plat, 0) + 1
    for name, cc, url in STATE_MEDIA_FEEDS:
        sid = source_id("rss", url)
        seen.add(sid)
        store.upsert_source({"id": sid, "entity_id": "web-" + cc.lower() + "-" + name.lower().replace(" ", "-")[:40], "platform": "rss", "handle": url,
                             "name": name, "country": cc, "category": "gov" if "MFA" in name else "media", "tier": "overt", "grade": "A1",
                             "evidence": ["HAM-METH"], "enabled": True, "provenance": json.dumps({"kind": "institution", "affil_verified": True, "note": "State media website / MFA feed (Hamilton 2.0 website set)"})})
        n_src += 1
        by_plat["rss"] = by_plat.get("rss", 0) + 1
    stale = [s["id"] for s in store.sources() if s["id"] not in seen]
    removed = store.delete_sources(stale) if stale else 0
    purged = store.purge_disabled()
    applied = apply_verification(store, root)
    return {"sources": n_src, "by_platform": by_plat, "verification_applied": applied, "candidates": cands, "removed_sources": removed, "purged_posts": purged}


def apply_verification(store: Store, root: str) -> int:
    """Seed source status from the shipped verification file (dated); `publius verify` refreshes it live."""
    fp = os.path.join(root, "watchlists", "verification.json")
    if not os.path.exists(fp):
        return 0
    v = _jload(fp)
    n = 0
    for handle, r in (v.get("telegram") or {}).items():
        sid = source_id("telegram", handle)
        s = store.source(sid)
        if s and (s.get("status") in (None, "", "unverified")):
            store.set_source_status(sid, r.get("status") or "unverified", (r.get("note") or "") + f" [verified {v['meta'].get('verified')}]", followers=r.get("followers"), last_post_ts=r.get("last_post_ts"))
            n += 1
    return n


def provenance(src: dict) -> dict:
    try:
        return json.loads(src.get("provenance") or "{}")
    except Exception:
        return {}
