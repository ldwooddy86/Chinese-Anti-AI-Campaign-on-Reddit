"""PUBLIUS 2.0 — an independent rebuild of the Hamilton 2.0 method (Russian, Chinese, Iranian and North Korean state and
state-aligned messaging across platforms, including the states' own domestic platforms) with a US domestic-unrest breakout
model and the GHOST LOOM pack. Not affiliated with ASD, GMF or ISD."""
__version__ = "2.0.0"
