"""DPRK: the state's own websites and the mirror that keeps their record.

  dprk_web   The Pyongyang-hosted set: KCNA (kcna.kp), Rodong Sinmun (rodong.rep.kp), Voice of Korea (vok.rep.kp), Naenara
             (naenara.com.kp), The Pyongyang Times (pyongyangtimes.com.kp) and the MFA (mfa.gov.kp). Plain HTTP, slow,
             intermittently unreachable, no feeds: the lane reads the front and section pages, keeps every article link it
             has not seen, and optionally fetches the article for its dateline and body. Long timeouts, one retry, and an
             unreachable host is recorded as such rather than as an error.
  kcnawatch  KCNA Watch (NK News' mirror of KCNA, Rodong and the rest), which keeps items the originals delete: its feed.

North Korea is the null-heavy control in GHOST LOOM 2.0: no documented DPRK influence operation targets US AI policy,
and the collector is here to keep that finding honest. What it reads is the state voice itself; it never reads the
Korean-speaking public, in either Korea or anywhere else."""
from __future__ import annotations

import html
import re
import urllib.parse
from typing import Optional

from ..util import HttpError, clean_text, http_request, now, parse_iso, sha1
from .base import Connector, Stats, register
from .rss import Rss

SITES = {
    # host fragment -> (name, link pattern the article links match, base for relative links)
    "kcna.kp":              ("KCNA", re.compile(r"/(?:en|kp|ru|zh|es|jp)/article/q/[A-Za-z0-9=._-]+\.kcmsf"), "http://kcna.kp"),
    "rodong.rep.kp":        ("Rodong Sinmun", re.compile(r"/(?:en|ko|ru|zh)/index\.php\?[A-Za-z0-9=+/_-]{8,}|/(?:en|ko)/[A-Za-z0-9=+/_-]{8,}"), "http://www.rodong.rep.kp"),
    "vok.rep.kp":           ("Voice of Korea", re.compile(r"/index\.php/(?:en|ko|ru|zh|es|fr|de|jp|ar)/[A-Za-z0-9/_.-]{6,}"), "http://www.vok.rep.kp"),
    "naenara.com.kp":       ("Naenara", re.compile(r"/main/index/(?:en|ko|ru|zh|es|fr|de|ja|ar)/[A-Za-z0-9/_.=?&-]{6,}"), "http://naenara.com.kp"),
    "pyongyangtimes.com.kp": ("The Pyongyang Times", re.compile(r"/(?:\?bbs_qhelp=|articles?/|news/|view/)[A-Za-z0-9/_.=?&-]{4,}"), "http://www.pyongyangtimes.com.kp"),
    "mfa.gov.kp":           ("DPRK MFA", re.compile(r"/(?:en|kp|ru|zh)/(?:view/article|article|news|statement)[A-Za-z0-9/_.=?&-]*"), "http://www.mfa.gov.kp"),
}
_A = re.compile(r'<a\s+[^>]*href="([^"#]+)"[^>]*>(.*?)</a>', re.S | re.I)
_TITLE_TAG = re.compile(r"<title>(.*?)</title>", re.S | re.I)
_MONTHS = {m: i for i, m in enumerate(("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"), 1)}


def site_of(url: str) -> Optional[tuple[str, str, re.Pattern, str]]:
    host = urllib.parse.urlparse(url).netloc.lower()
    for frag, (name, rx, base) in SITES.items():
        if frag in host:
            return frag, name, rx, base
    return None


def article_links(page: str, page_url: str) -> list[dict]:
    """Every anchor on a list page whose href matches the site's article pattern; the anchor text is the title."""
    s = site_of(page_url)
    if not s:
        return []
    frag, name, rx, base = s
    out, seen = [], set()
    for href, inner in _A.findall(page):
        href = html.unescape(href.strip())
        u = urllib.parse.urljoin(page_url if page_url.endswith("/") else page_url + "/", href) if not href.startswith("http") else href
        path = urllib.parse.urlparse(u).path + ("?" + urllib.parse.urlparse(u).query if urllib.parse.urlparse(u).query else "")
        if not rx.search(path) or u in seen:
            continue
        seen.add(u)
        title = clean_text(inner, 300)
        if len(title) < 4:
            continue
        out.append({"url": u, "title": title})
    return out


def dateline(text: str, ref: Optional[int] = None) -> Optional[int]:
    """'Pyongyang, September 26 (KCNA)' / 'Date: 26.09.2026' / '2026-09-26' / 'September 26, 2026' -> epoch (UTC noon of that day)."""
    import calendar
    t = text or ""
    m = re.search(r"(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})", t)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = re.search(r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})", t)
        if m:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        else:
            m = re.search(r"\b(" + "|".join(_MONTHS) + r")\s+(\d{1,2})(?:,?\s+(\d{4}))?", t, re.I)
            if not m:
                return None
            mo, d = _MONTHS[m.group(1).lower()], int(m.group(2))
            import datetime as _dt
            y = int(m.group(3)) if m.group(3) else _dt.datetime.utcfromtimestamp(ref or now()).year
    try:
        return calendar.timegm((y, mo, d, 12, 0, 0))
    except (ValueError, OverflowError):
        return None


def article_body(page: str) -> tuple[str, str]:
    """Title and body of a DPRK article page: the largest text block after the tags come off."""
    title = clean_text((_TITLE_TAG.search(page) or [None, ""])[1] or "", 300)
    page = re.sub(r"(?is)<(script|style|nav|header|footer)[^>]*>.*?</\1>", " ", page)
    blocks = [clean_text(b) for b in re.split(r"(?i)</?(?:div|article|section|td|p)[^>]*>", page)]
    body = max(blocks, key=len) if blocks else ""
    return title, body


@register
class DprkWeb(Connector):
    platform = "dprk_web"
    label = "DPRK state websites (kcna.kp, rodong.rep.kp, vok.rep.kp, naenara.com.kp, pyongyangtimes.com.kp, mfa.gov.kp)"
    region = "kp"
    route_class = "open"
    new_in = "2.0"
    reads = "article links from the state sites' list pages, and (optionally) each article's dateline and body"
    refuses = "nothing on these sites is a person's; the lane reads the state's own publications only and never the Korean-speaking public anywhere"
    probe_url = "http://kcna.kp/en"

    def timeout(self) -> int:
        return int(self.cfg.get("timeout", 60) or 60)

    def fetch(self, url: str) -> str:
        body, _, final = http_request(url, browser=True, timeout=self.timeout(), retries=1, max_bytes=4 * 1024 * 1024)
        return body.decode("utf-8", "replace")

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                page = self.fetch(s["handle"])
                links = article_links(page, s["handle"])
                st = "live" if links else "empty"
                note = f"{len(links)} article links on the page" if links else "page reached; no article links matched (pattern may need updating)"
                self.store.set_source_status(s["id"], st, note)
                res.append({"id": s["id"], "status": st, "note": note})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                note = (str(e)[:120] + " — Pyongyang-hosted sites are slow and often down; retried by `publius verify`, not every cycle") if st == "unreachable" else str(e)[:200]
                self.store.set_source_status(s["id"], st, note); res.append({"id": s["id"], "status": st, "note": note})
        return res

    def watch_sources(self) -> list[dict]:
        return [s for s in super().watch_sources() if s.get("status") != "unreachable"]

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        fetch_bodies = bool(self.cfg.get("fetch_bodies", False))
        per_page = int(self.cfg.get("max_new_articles_per_page", 20) or 20)

        def one(src: dict):
            page = self.fetch(src["handle"])
            links = article_links(page, src["handle"])
            n, newest, fetched = 0, None, 0
            for l in links:
                pid = sha1(self.platform, src["id"], l["url"])
                if self.store.has_post(pid):
                    continue
                ts, text, title = None, "", l["title"]
                if fetch_bodies and fetched < per_page:
                    try:
                        t2, body = article_body(self.fetch(l["url"]))
                        ts = dateline(body[:400]) or dateline(body)
                        text, title, fetched = body, t2 or title, fetched + 1
                    except HttpError:
                        pass
                ts = ts or now()
                newest = max(newest or 0, ts)
                if self.emit(src, l["url"], ts, text or title, url=l["url"], title=title):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


_NEWSTREAM = re.compile(r'<a[^>]+href="(https://kcnawatch\.org/newstream/(\d{10})-\d+/[^"]+)"[^>]*>(.*?)</a>', re.S)


def parse_newstream(page: str) -> list[dict]:
    """The mirror's front page lists the newest items as newstream/<epoch>-<id>/<slug> links (read live 26 Sep 2026); the
    anchor text is the title and the epoch in the URL is the mirror's timestamp."""
    out, seen = [], {}
    for url, ts, inner in _NEWSTREAM.findall(page):
        title = clean_text(inner, 300)
        if url in seen and not title:
            continue
        if url in seen and title and not seen[url]["title"]:
            seen[url]["title"] = title
            continue
        if url in seen:
            continue
        seen[url] = {"url": url, "ts": int(ts), "title": title}
        out.append(seen[url])
    for it in out:
        if not it["title"]:
            it["title"] = clean_text(urllib.parse.unquote(it["url"].rsplit("/", 1)[-1]).replace("-", " ").capitalize(), 300)
    return out


@register
class KcnaWatch(Rss):
    platform = "kcnawatch"
    label = "KCNA Watch (NK News' mirror; feed, or its front-page index behind the member wall)"
    region = "kp"
    route_class = "open"
    new_in = "2.0"
    reads = "the mirror's feed of KCNA, Rodong Sinmun and other DPRK state items when it answers; otherwise the newest items' titles and timestamps from its front page"
    refuses = "the mirror's member-walled article bodies, archive and search; nothing of the mirror's readers"
    probe_url = "https://kcnawatch.org/"

    def fetch(self, url: str) -> tuple[str, list[dict]]:
        body, _, final = http_request(url, headers={"Accept": "application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.5"}, browser=True, timeout=30, retries=1)
        if b"<rss" in body[:4000] or b"<feed" in body[:4000]:
            from .rss import parse_feed
            return parse_feed(body)
        # the feed redirects to the member form for a visitor: fall back to the front page's newstream index
        page = body.decode("utf-8", "replace") if "kcnawatch.org" in final and "popup=" in final else http_request("https://kcnawatch.org/", browser=True, timeout=30, retries=1)[0].decode("utf-8", "replace")
        items = parse_newstream(page)
        if not items:
            raise HttpError(404, "kcnawatch: neither the feed nor the front-page index answered")
        return "KCNA Watch (front-page index; the feed is member-walled)", [{"guid": it["url"], "title": it["title"], "link": it["url"], "body": it["title"], "ts": it["ts"], "media": {}, "views": None, "upstream": []} for it in items]

    def watch_sources(self):
        return [dict(s, handle=s["handle"] if s["handle"].startswith("http") else "https://kcnawatch.org/feed/") for s in Connector.watch_sources(self)]
