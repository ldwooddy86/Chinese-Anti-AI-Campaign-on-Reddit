"""Connector contract. Every connector READS public content only: no posting, reacting, joining, following or DMs.

A connector may implement:
  collect()  pull new posts from the watchlist sources on its platform
  verify()   check that watchlist handles exist, are public and active (status, followers, last post)
  search()   a US-audience breakout lane: how often a URL or phrase appears there (aggregate counts only)
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from ..store import Post, Store
from ..util import clean_text, extract_entities, guess_lang, now, sha1

log = logging.getLogger("publius.connector")


@dataclass
class Stats:
    items: int = 0
    sources: int = 0
    errors: list = field(default_factory=list)


@dataclass
class SearchResult:
    """Aggregate result of a breakout query in one lane. `public_figures` only lists accounts at or above the
    public-figure follower threshold; private individuals are never recorded, only counted."""
    lane: str
    count: int = 0
    reach_max: Optional[int] = None
    public_figures: list = field(default_factory=list)
    violent_or_mobilising: int = 0
    ok: bool = True
    note: str = ""
    cost_usd: float = 0.0


class RouteClosed(Exception):
    """The lawful route stopped answering without a login (a login wall, a redirect to a sign-in page, a signature demand).
    The lane records the closure and stops; it never works around it."""


class Connector:
    platform = "base"
    label = "base"
    requires: tuple = ()             # config keys that must be non-empty for the connector to run
    breakout_lane = False            # implements search() for US-audience breakout measurement
    region = "global"                # global | ru | cn | ir | kp
    route_class = "open"             # open | key | paid | gated | bridge | none | refused
    new_in = "1.0"                   # first version that shipped the lane
    reads = ""                       # one line: what the lane reads
    refuses = ""                     # one line: what the lane refuses even when configured
    probe_url = ""                   # a cheap public endpoint the probe reads (no credentials, no login)
    probe_any_status = False         # True: any HTTP answer (even 4xx) proves the host is reachable (API roots that reject anonymous calls)

    def __init__(self, section: dict, cfg: dict, store: Store):
        self.cfg = section or {}
        self.all = cfg
        self.store = store

    # ------------------------------------------------------------------ readiness
    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled"))

    def ready(self) -> tuple[bool, str]:
        missing = [k for k in self.requires if not str(self.cfg.get(k, "")).strip()]
        if missing:
            return False, "missing " + ", ".join(f"{self.platform}.{k}" for k in missing)
        return True, "ok"

    search_requires: tuple = ()      # extra credentials breakout search needs beyond collection (e.g. a search API key)

    def search_ready(self) -> tuple[bool, str]:
        if not self.breakout_lane:
            return False, "not a breakout lane"
        ok, why = self.ready()
        if not ok:
            return ok, why
        missing = [k for k in self.search_requires if not str(self.cfg.get(k, "")).strip()]
        if missing:
            return False, "search needs " + ", ".join(f"{self.platform}.{k}" for k in missing)
        return True, "ok"

    SKIP_STATUS = ("dead", "refused", "no_route")
    REOPEN_AFTER_S = 24 * 3600        # a closed route is retried once a day on its own; `publius verify` re-opens it sooner

    def watch_sources(self) -> list[dict]:
        out = []
        for s in self.store.sources(platform=self.platform, enabled_only=True):
            if s.get("status") in self.SKIP_STATUS:
                continue
            if s.get("status") == "closed" and now() - int(s.get("last_run") or 0) < self.REOPEN_AFTER_S:
                continue
            out.append(s)
        return out

    # ------------------------------------------------------------------ emission
    def emit(self, src: dict, native_id: str, ts: Optional[int], text: str, url: str = "", title: str = "", media: Optional[dict] = None,
             metrics: Optional[dict] = None, fwd_from: str = "", extra_urls: tuple = (), upstream: Optional[list] = None) -> bool:
        body = clean_text(text)
        ttl = clean_text(title, 400)
        full = (ttl + "\n" + body).strip() if ttl and ttl not in body else body
        ents = extract_entities(full, extra_urls)
        p = Post(id=sha1(self.platform, src["id"], native_id), source_id=src["id"], ts=int(ts or now()), text=body, title=ttl, url=url,
                 lang=guess_lang(full), platform=self.platform, country=src.get("country", ""), category=src.get("category", ""),
                 urls=ents["urls"], domains=ents["domains"], hashtags=ents["hashtags"], mentions=ents["mentions"], media=media or {},
                 metrics={k: v for k, v in (metrics or {}).items() if v is not None}, fwd_from=fwd_from, upstream=upstream or [])
        return self.store.add_post(p)

    # ------------------------------------------------------------------ contract
    def collect(self, max_sources: Optional[int] = None) -> Stats:  # pragma: no cover - abstract
        raise NotImplementedError

    def verify(self, sources: list[dict]) -> list[dict]:
        return []

    def search(self, query: str, kind: str = "url", since: Optional[int] = None) -> SearchResult:
        return SearchResult(lane=self.platform, ok=False, note="not a breakout lane")

    def probe(self) -> dict:
        """One cheap, credential-free read of the lane's public route from the operator's own network. Records reachability,
        never content. Lanes override this when the public route needs more than a GET; a lane with no public route
        returns ok=None (not applicable)."""
        if not self.probe_url:
            return {"ok": None, "note": "no credential-free probe for this lane"}
        from ..util import HttpError, http_request
        try:
            body, hdrs, final = http_request(self.probe_url, timeout=20, retries=0, browser=True, max_bytes=512 * 1024)
            if self.closed_by_login(final, body):
                return {"ok": False, "note": f"route closed: login wall at {final}"}
            return {"ok": True, "note": f"{len(body)} bytes from {final}"}
        except HttpError as e:
            if self.probe_any_status and e.status and e.status not in (403, 407, 451):
                return {"ok": True, "note": f"host answered HTTP {e.status} (anonymous call rejected as expected)"}
            return {"ok": False, "note": f"HTTP {e.status}: {str(e)[:140]}" if e.status else str(e)[:160]}
        except Exception as e:
            return {"ok": False, "note": str(e)[:160]}

    def resolve(self, name: str) -> Optional[dict]:
        """Turn a display name or profile URL into the platform's stable id for the watchlist (`publius resolve`).
        Returns {"id", "name", "note"} or None. Only state accounts are ever looked up; the operator supplies the name."""
        return None

    def meta(self) -> dict:
        return {"region": self.region, "route_class": self.route_class, "new_in": self.new_in, "reads": self.reads, "refuses": self.refuses,
                "probeable": bool(self.probe_url) or type(self).probe is not Connector.probe}

    @staticmethod
    def closed_by_login(final_url: str, body: bytes) -> bool:
        f = (final_url or "").lower()
        if any(k in f for k in ("/login", "signin", "sign-in", "passport.", "/auth", "account.")):
            return True
        head = body[:6000].decode("utf-8", "replace").lower() if body else ""
        return ("请登录" in head) or ("log in to" in head and "<form" in head) or ("ورود به حساب" in head) or ("sina visitor system" in head) \
            or ("showcaptcha" in head) or ("smartcaptcha" in head)

    # ------------------------------------------------------------------ helpers
    def run_sources(self, fn, max_sources: Optional[int] = None) -> Stats:
        st = Stats()
        srcs = self.watch_sources()
        srcs.sort(key=lambda s: (s.get("last_run") or 0))           # least-recently-polled first (fair rotation)
        if max_sources:
            srcs = srcs[:max_sources]
        for s in srcs:
            st.sources += 1
            try:
                r = fn(s)
                n, newest = r[0], r[1]
                cursor = r[2] if len(r) > 2 else None
                self.store.source_ok(s["id"], None if cursor is None else str(cursor), n, newest)
                st.items += n
            except RouteClosed as e:   # the lawful route stopped answering: record it, skip the source until verify re-opens it
                self.store.set_source_status(s["id"], "closed", str(e)[:280])
                self.store.source_error(s["id"], "closed: " + str(e))
                st.errors.append(f"{s['id']}: closed: {e}")
            except Exception as e:  # one bad source never stops the lane
                self.store.source_error(s["id"], str(e))
                st.errors.append(f"{s['id']}: {e}")
                log.debug("source %s failed: %s", s["id"], e)
        return st


REGISTRY: dict[str, type] = {}


def register(cls):
    REGISTRY[cls.platform] = cls
    return cls


def sleep_jitter(sec: float) -> None:
    time.sleep(sec)
