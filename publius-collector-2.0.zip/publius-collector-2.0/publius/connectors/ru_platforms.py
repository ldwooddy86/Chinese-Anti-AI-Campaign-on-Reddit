"""Russian domestic platforms beyond VK, Rutube and Odysee (those stay in gated.py / rss.py):

  ok     Odnoklassniki: the REST API (api.ok.ru/fb.do) with an application key and a permanent token, signed the
         documented way. Reads the wall (stream.get) of watchlisted state-media groups and group info; nothing of users.
  dzen   Dzen (the former Yandex Zen, now VK's): channel RSS where the channel publishes one. Dzen fronts an anti-bot
         wall (SmartCaptcha) to many clients; the wall closes the route, it is never solved.
  max    Max, VK's state-backed messenger that the Pravda network's editions link to (max.ru/<channel>): public channel
         pages, best effort, parsed from the page state the site ships. Unverified from the build network.

Read-only throughout: the OK token is used for GET-style reads only; no like, join, post or message is ever sent."""
from __future__ import annotations

import hashlib
import html
import json
import re
import urllib.parse
from typing import Any, Optional

from ..util import HttpError, clean_text, http_get, http_request, now, parse_count, parse_iso
from .base import Connector, RouteClosed, Stats, register
from .ir_platforms import _OG_TITLE, message_like, page_state
from .rss import Rss, parse_feed

OK_API = "https://api.ok.ru/fb.do"


def ok_sig(params: dict, session_secret_key: str) -> str:
    """OK's request signature: sorted 'k=v' pairs concatenated (access_token and sig excluded) + session secret, MD5."""
    base = "".join(f"{k}={params[k]}" for k in sorted(params) if k not in ("access_token", "sig"))
    return hashlib.md5((base + session_secret_key).encode("utf-8")).hexdigest()


def parse_ok_stream(js: dict) -> list[dict]:
    ents = (js.get("entities") or {}) if isinstance(js, dict) else {}
    out = []
    for t in ents.get("media_topics") or []:
        if not isinstance(t, dict) or not t.get("id"):
            continue
        texts, urls, media = [], [], {}
        for m in t.get("media") or []:
            if not isinstance(m, dict):
                continue
            k = str(m.get("type") or "")
            if k == "text" and m.get("text"):
                texts.append(m["text"])
            elif k == "link":
                u = m.get("url") or m.get("link_url") or ""
                if u:
                    urls.append(u)
                if m.get("title"):
                    texts.append(m["title"])
            elif k in ("photo", "photos"):
                media["photo"] = media.get("photo", 0) + len(m.get("photos") or [1])
            elif k in ("movie", "video", "movie_refs"):
                media["video"] = media.get("video", 0) + 1
        ms = t.get("created_ms")
        out.append({"id": str(t["id"]), "ts": int(ms) // 1000 if isinstance(ms, (int, float)) and ms else None, "text": clean_text("\n".join(texts)), "urls": urls, "media": media,
                    "metrics": {"likes": ((t.get("like_summary") or {}).get("count")), "replies": ((t.get("discussion_summary") or {}).get("comments_count")),
                                "shares": ((t.get("reshare_summary") or {}).get("count"))}, "author_ref": t.get("author_ref") or ""})
    return out


@register
class OK(Connector):
    platform = "ok"
    label = "Odnoklassniki (REST API, signed; group walls)"
    region = "ru"
    route_class = "key"
    new_in = "2.0"
    requires = ("application_key", "access_token", "session_secret_key")
    reads = "the wall of watchlisted state-media groups (stream.get) and group info (group.getInfo) through the documented REST API"
    refuses = "users' walls, friends, discussions' participants; any write method"
    probe_url = OK_API + "?method=group.getInfo&format=json"
    probe_any_status = True

    def call(self, method: str, **params) -> Any:
        p = {k: str(v) for k, v in params.items()}
        p.update({"application_key": self.cfg["application_key"], "method": method, "format": "json"})
        p["sig"] = ok_sig(p, self.cfg["session_secret_key"])
        p["access_token"] = self.cfg["access_token"]
        import json as _j
        raw = http_get(OK_API, params=p, timeout=30)
        js = _j.loads(raw.decode("utf-8", "replace"))
        if isinstance(js, dict) and js.get("error_code"):
            code = int(js["error_code"])
            if code in (102, 103, 10, 104, 458, 459):
                raise RouteClosed(f"ok {method}: error {code} {js.get('error_msg', '')}")
            raise HttpError(400, f"ok {method}: error {code} {js.get('error_msg', '')}")
        return js

    def resolve(self, name: str) -> Optional[dict]:
        n = name.strip()
        if n.isdigit():
            gid = n
        else:
            u = n if n.startswith("http") else f"https://ok.ru/group/{n}" if not n.startswith("ok.ru") else "https://" + n
            r = self.call("url.getInfo", url=u)
            if not isinstance(r, dict) or str(r.get("type", "")).upper() != "GROUP":
                return None
            gid = str(r.get("objectId") or r.get("objectIdStr") or "")
        info = self.group_info(gid)
        return {"id": gid, "name": info.get("name", ""), "note": f"{info.get('members_count', 0):,} members" if info.get("members_count") else "group"} if info else None

    def group_info(self, gid: str) -> dict:
        r = self.call("group.getInfo", uids=gid, fields="name,members_count,description,uid")
        rows = r if isinstance(r, list) else []
        return rows[0] if rows and isinstance(rows[0], dict) else {}

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                g = self.group_info(s["handle"])
                st = "live" if g.get("name") else "not_found"
                note = f"{g.get('members_count') or 0:,} members" if g else "no such group"
                self.store.set_source_status(s["id"], st, note, followers=g.get("members_count"), name=g.get("name") or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": g.get("members_count")})
            except (HttpError, RouteClosed) as e:
                st = "closed" if isinstance(e, RouteClosed) else ("unreachable" if e.status == 0 else "error")
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            r = self.call("stream.get", gid=src["handle"], patterns="POST", count=50, fields="media_topic.*,like_summary.*,discussion_summary.*,reshare_summary.*")
            n, newest = 0, None
            for t in parse_ok_stream(r if isinstance(r, dict) else {}):
                newest = max(newest or 0, t["ts"] or 0)
                if self.emit(src, t["id"], t["ts"], t["text"], url=f"https://ok.ru/group/{src['handle']}/topic/{t['id']}", media=t["media"], metrics=t["metrics"], extra_urls=tuple(t["urls"])):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


# ====================================================================================================== Dzen
def dzen_walled(body: bytes, final: str) -> bool:
    head = body[:8000].decode("utf-8", "replace").lower()
    return "showcaptcha" in (final or "").lower() or "smartcaptcha" in head or "captcha" in head and "<form" in head


@register
class Dzen(Rss):
    platform = "dzen"
    label = "Dzen (channel RSS where published; captcha wall closes the route)"
    region = "ru"
    route_class = "open"
    new_in = "2.0"
    reads = "the RSS feed of watchlisted state-media channels (dzen.ru/<channel>/rss where the channel publishes one)"
    refuses = "solving the SmartCaptcha wall, individuals' channels, comments"
    probe_url = "https://dzen.ru/robots.txt"
    CANDIDATES = ("https://dzen.ru/{handle}/rss", "https://dzen.ru/{handle}?rss=1", "https://dzen.ru/id/{handle}/rss")

    def feed_urls(self, handle: str) -> list[str]:
        if handle.startswith("http"):
            return [handle]
        tpl = str(self.cfg.get("rss_template") or "").strip()
        cands = ([tpl] if tpl else []) + [c for c in self.CANDIDATES if c != tpl]
        return [c.format(handle=handle.lstrip("@")) for c in cands]

    def fetch(self, url_or_handle: str) -> tuple[str, list[dict]]:
        last: Optional[Exception] = None
        for u in self.feed_urls(url_or_handle):
            try:
                body, _, final = http_request(u, headers={"Accept": "application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.5"}, browser=True, timeout=30, retries=1)
                if dzen_walled(body, final):
                    raise RouteClosed(f"dzen answered with a captcha wall at {final}")
                if b"<rss" not in body[:4000] and b"<feed" not in body[:4000]:
                    last = HttpError(404, f"no feed at {u}"); continue
                return parse_feed(body)
            except HttpError as e:
                last = e
                if e.status == 0:
                    break
        raise last or HttpError(404, "no feed")

    def watch_sources(self) -> list[dict]:
        return [s for s in Connector.watch_sources(self) if s.get("status") not in ("unreachable", "closed")]

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                r = Rss.verify(self, [s])
                res.extend(r)
            except RouteClosed as e:
                self.store.set_source_status(s["id"], "closed", str(e)[:200]); res.append({"id": s["id"], "status": "closed", "note": str(e)[:200]})
        return res


# ====================================================================================================== Max
_MAX_INFO = re.compile(r'linkInfo:\{channel:\{(.*?)\}\}', re.S)


def parse_max_page(page: str) -> dict:
    """max.ru/<channel> ships the channel's card in its SvelteKit data (read live 26 Sep 2026): title, description,
    participantsCount, channelId. Messages are loaded by the client after a session handshake and are not served to a visitor."""
    m = _MAX_INFO.search(page)
    if not m:
        return {}
    blob = m.group(1)
    def field(k: str) -> str:
        mm = re.search(k + r':"((?:[^"\\]|\\.)*)"', blob)
        return json.loads('"' + mm.group(1) + '"') if mm else ""
    cnt = re.search(r"participantsCount:(\d+)", blob)
    cid = re.search(r"channelId:(\d+)", blob)
    return {"title": field("title"), "description": field("description"), "subscribers": int(cnt.group(1)) if cnt else None, "channel_id": cid.group(1) if cid else ""}


@register
class Max(Connector):
    platform = "max"
    label = "Max (VK's messenger; public channel cards)"
    region = "ru"
    route_class = "open"
    new_in = "2.0"
    reads = "the channel card a public max.ru/<channel> page ships (title, description, subscriber count, channel id); the Pravda network's editions link to these channels"
    refuses = "message history (served only after the client's session handshake, which the lane never performs), chats, users"
    probe_url = "https://max.ru/tass_agency"

    def fetch(self, handle: str) -> dict:
        body, _, final = http_request("https://max.ru/" + urllib.parse.quote(handle.lstrip("@")), browser=True, timeout=30, retries=1)
        page = body.decode("utf-8", "replace")
        if self.closed_by_login(final, body):
            raise RouteClosed(f"login wall at {final}")
        d = parse_max_page(page)
        d["messages"] = []
        return d

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                d = self.fetch(s["handle"])
                st = "live" if d.get("title") else "not_found"
                note = (f"{d['subscribers']:,} subscribers; channel {d.get('channel_id')}; posts are not served to a visitor" if d.get("title") else "no channel card on the page")
                self.store.set_source_status(s["id"], st, note, followers=d.get("subscribers"), name=d.get("title") or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": d.get("subscribers"), "title": d.get("title")})
            except (HttpError, RouteClosed) as e:
                st = "closed" if isinstance(e, RouteClosed) else ("unreachable" if e.status == 0 else "error")
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def resolve(self, name: str) -> Optional[dict]:
        m = re.search(r"max\.ru/([A-Za-z0-9_.]+)", name.strip())
        h = m.group(1) if m else name.strip().lstrip("@")
        try:
            d = self.fetch(h)
        except (HttpError, RouteClosed):
            return None
        return {"id": h, "name": d.get("title", ""), "note": f"{d.get('subscribers') or 0:,} subscribers; channel {d.get('channel_id')}"} if d.get("title") else None

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        """Metadata refresh only: the page carries no messages for a visitor. Emits no posts."""
        def one(src: dict):
            d = self.fetch(src["handle"])
            if d.get("title"):
                self.store.set_source_status(src["id"], "live", f"{d.get('subscribers') or 0:,} subscribers; posts are not served to a visitor", followers=d.get("subscribers"), name=d["title"])
            return 0, None
        return self.run_sources(one, max_sources)
