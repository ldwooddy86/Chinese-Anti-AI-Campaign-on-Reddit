"""Two more US-audience breakout lanes, aggregate counts only.

  tumblr    the public tagged-posts API (api.tumblr.com/v2/tagged, needs a free API key): how many posts carry a tag
            that matches the phrase. No blog is named: Tumblr's tag feed carries no follower counts, so the public-figure
            threshold cannot be applied and public_figures stays empty by design.
  fourchan  the read-only JSON API (a.4cdn.org, keyless; one request a second by its rules): how many threads on the
            configured boards (default /pol/ and /news/) carry the phrase or URL, with the reply total as reach. Posters
            are anonymous and the lane records none of them."""
from __future__ import annotations

import html
import re
import time
from typing import Optional

from ..util import HttpError, clean_text, http_get_json, now
from .base import Connector, SearchResult, Stats, register


def tag_of(phrase: str) -> str:
    return re.sub(r"[^\w\s-]", "", phrase).strip().lower()


def count_tagged(js: dict, since: Optional[int]) -> tuple[int, int]:
    """Posts in a /v2/tagged page at or after `since`; returns (count, violent_or_mobilising)."""
    from .social import _vm
    posts = js.get("response") or []
    if isinstance(posts, dict):
        posts = posts.get("posts") or []
    keep = [p for p in posts if isinstance(p, dict) and (not since or int(p.get("timestamp") or 0) >= since)]
    texts = [clean_text((p.get("summary") or "") + " " + (p.get("caption") or "") + " " + (p.get("body") or "")) for p in keep]
    return len(keep), _vm(texts)


@register
class Tumblr(Connector):
    platform = "tumblr"
    label = "Tumblr (tagged posts; breakout lane)"
    region = "global"
    route_class = "key"
    new_in = "2.0"
    requires = ("api_key",)
    breakout_lane = True
    reads = "counts of public posts under a tag matching the phrase (api.tumblr.com/v2/tagged)"
    refuses = "naming any blog (no follower counts on the tag feed, so no public-figure threshold can apply), notes, reblog chains"
    probe_url = "https://api.tumblr.com/v2/tagged?tag=news"
    probe_any_status = True

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        return Stats()

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        if kind == "url":
            return SearchResult("tumblr", ok=False, note="the tag feed does not match URLs")
        tag = tag_of(query)
        if not tag:
            return SearchResult("tumblr", ok=False, note="empty tag")
        total, vm, before, pages = 0, 0, None, 0
        while pages < 5:
            params = {"tag": tag, "api_key": self.cfg["api_key"], "limit": 20, "filter": "text"}
            if before:
                params["before"] = before
            js = http_get_json("https://api.tumblr.com/v2/tagged", params=params)
            n, v = count_tagged(js, since)
            total += n; vm += v; pages += 1
            posts = js.get("response") or []
            if not isinstance(posts, list) or len(posts) < 20:
                break
            oldest = min(int(p.get("timestamp") or 0) for p in posts if isinstance(p, dict))
            if since and oldest < since:
                break
            before = oldest
        return SearchResult("tumblr", count=total, violent_or_mobilising=vm, note=f"tag:{tag[:50]}")


@register
class FourChan(Connector):
    platform = "fourchan"
    label = "4chan (catalog counts on /pol/ and /news/; breakout lane)"
    region = "global"
    route_class = "open"
    new_in = "2.0"
    breakout_lane = True
    reads = "thread subjects and opening posts from the boards' public catalogs (a.4cdn.org), counted; the reply total as reach"
    refuses = "recording any post or poster, images, boards outside the configured list"
    probe_url = "https://a.4cdn.org/boards.json"

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        return Stats()

    def catalog(self, board: str) -> list[dict]:
        b = re.sub(r"[^a-z0-9]", "", board.lower())
        if not b:
            return []
        js = http_get_json(f"https://a.4cdn.org/{b}/catalog.json", headers={"Accept": "application/json"}, timeout=30)
        out = []
        for page in js if isinstance(js, list) else []:
            for t in (page or {}).get("threads") or []:
                if isinstance(t, dict):
                    out.append({"no": t.get("no"), "sub": clean_text(html.unescape(t.get("sub") or "")), "com": clean_text(html.unescape(t.get("com") or "")), "replies": int(t.get("replies") or 0),
                                "time": int(t.get("time") or 0), "last_modified": int(t.get("last_modified") or 0), "board": b})
        return out

    def search(self, query: str, kind: str = "url", since: Optional[int] = None) -> SearchResult:
        from .social import _vm
        from ..util import canonical_url, domain_of
        q = query.strip()
        if kind == "url":
            cu = canonical_url(q)
            needle = cu.split("://", 1)[-1].lower()
        else:
            needle = q.lower()
        hits, reach, texts = 0, 0, []
        for board in self.cfg.get("boards") or ["pol", "news"]:
            try:
                threads = self.catalog(board)
            except HttpError as e:
                if e.status == 404:
                    continue
                raise
            time.sleep(1.0)                    # the API's own rule: at most one request a second
            for t in threads:
                if since and max(t["time"], t["last_modified"]) < since:
                    continue
                hay = (t["sub"] + " " + t["com"]).lower()
                if needle in hay:
                    hits += 1; reach += t["replies"]; texts.append(hay)
        return SearchResult("fourchan", count=hits, reach_max=reach or None, violent_or_mobilising=_vm(texts), note=f"{kind}:{q[:60]} on /" + "/, /".join(self.cfg.get("boards") or ["pol", "news"]) + "/")
