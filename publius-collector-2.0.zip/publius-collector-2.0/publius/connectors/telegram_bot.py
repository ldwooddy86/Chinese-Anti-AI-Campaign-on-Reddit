"""Telegram Bot API: the third Telegram route, for channel metadata only.

A bot reads a channel's posts only as that channel's administrator, and PUBLIUS never asks a watchlisted outlet to add
it. What a bot CAN do for any public channel, without joining anything, is getChat and getChatMemberCount: title,
description, linked discussion group, subscriber count. The lane uses that to keep subscriber counts and titles fresh
for channels whose web preview is disabled (the user-session lane reads their posts), and to verify handles cheaply.

  telegram_bot.token   from @BotFather; the bot needs no permission and joins nothing"""
from __future__ import annotations

from typing import Optional

from ..util import HttpError, http_get_json
from .base import Connector, Stats, register

API = "https://api.telegram.org/bot{token}/{method}"


def parse_chat(js: dict) -> dict:
    r = js.get("result") or {}
    return {"ok": bool(js.get("ok")), "title": r.get("title") or "", "type": r.get("type") or "", "username": r.get("username") or "", "description": r.get("description") or "",
            "linked_chat_id": r.get("linked_chat_id"), "id": r.get("id")}


@register
class TelegramBot(Connector):
    platform = "telegram_bot"
    label = "Telegram (Bot API: channel metadata and subscriber counts)"
    region = "global"
    route_class = "key"
    new_in = "2.0"
    requires = ("token",)
    reads = "title, description and subscriber count of watchlisted public channels (getChat, getChatMemberCount)"
    refuses = "message history (a bot reads posts only as a channel's administrator, which PUBLIUS never asks to be), groups, users"
    probe_url = "https://api.telegram.org/"
    probe_any_status = True

    def _call(self, method: str, **params):
        try:
            return http_get_json(API.format(token=self.cfg["token"], method=method), params=params, timeout=20)
        except HttpError as e:
            if e.status in (400, 404):
                return {"ok": False, "description": str(e)}
            raise

    def chat(self, handle: str) -> dict:
        h = "@" + handle.lstrip("@")
        js = self._call("getChat", chat_id=h)
        d = parse_chat(js)
        if d["ok"] and d["type"] != "channel":
            raise HttpError(403, f"refused: {h} is a {d['type'] or 'chat'}, not a broadcast channel")
        if d["ok"]:
            cnt = self._call("getChatMemberCount", chat_id=h)
            d["members"] = cnt.get("result") if cnt.get("ok") else None
        return d

    def watch_sources(self) -> list[dict]:
        return [s for s in self.store.sources(platform="telegram", enabled_only=True) if s.get("status") in ("no_preview", "unverified", "not_found", "", None)]

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                d = self.chat(s["handle"])
                if not d["ok"]:
                    self.store.set_source_status(s["id"], "not_found", "Bot API: " + str(d.get("description", ""))[:150]); res.append({"id": s["id"], "status": "not_found"}); continue
                note = f"{d['members']:,} subscribers per Bot API" if d.get("members") else "channel found (Bot API)"
                st = s.get("status") if s.get("status") in ("live", "no_preview") else "live"
                self.store.set_source_status(s["id"], st, note, followers=d.get("members"), name=d["title"] or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": d.get("members"), "title": d["title"]})
            except HttpError as e:
                self.store.set_source_status(s["id"], "error", str(e)[:200]); res.append({"id": s["id"], "status": "error", "note": str(e)[:200]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        """Metadata refresh only: subscriber counts for channels without a public preview. Emits no posts."""
        st = Stats()
        for s in self.watch_sources()[: max_sources or None]:
            st.sources += 1
            try:
                d = self.chat(s["handle"])
                if d["ok"] and d.get("members"):
                    self.store.set_source_status(s["id"], s.get("status") or "no_preview", s.get("status_note") or "", followers=d["members"], name=d["title"] or None)
            except HttpError as e:
                st.errors.append(f"{s['handle']}: {e}")
        return st
