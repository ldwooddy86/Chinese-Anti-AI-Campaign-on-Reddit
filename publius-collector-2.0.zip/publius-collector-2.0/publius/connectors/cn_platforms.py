"""Chinese domestic platforms, read the lawful way: the state's own accounts and the public hot boards.

Rails (config.py enforces the first at load; the code repeats all of them):
  - state accounts and public boards only. Ordinary users, comments, chats, complaint channels and search results
    about people are never read; a watchlist row for an account exists because its state attribution is documented.
  - public endpoints and visitor cookies only. A login cookie (SUB, SESSDATA, z_c0, sessionid ...) is refused at config
    load and never sent; the lanes work as an anonymous visitor sees the platform, or not at all.
  - a login wall, a visitor-system wall or a signature demand closes the route (RouteClosed). The lane records the
    closure and stops; nothing works around it.

Lanes
  weibo     state accounts through the mobile container API (m.weibo.cn), and the public hot-search board
  bilibili  state accounts' uploads through the WBI-signed space API (a documented public signature, not a login),
            the popular list and the trending search words
  zhihu     state accounts' own answers, articles and pins, and the hot list
  douyin    the hot board only: account pages demand a request signature the lane will not forge

Every board read is also handed to publius.boards, which keeps snapshots and flags entries that drop early.
Nothing in this module was reachable from the build network; the parsers are exercised on fixtures
(tests/test_offline.py) and `python -m publius probe` checks the routes from the operator's own network."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import re
import time
import urllib.parse
from functools import reduce
from typing import Optional

from .. import boards
from ..analysis.lexicon import match_all
from ..util import HttpError, clean_text, day, http_request, now, parse_iso, sha1
from .base import Connector, RouteClosed, Stats, register

US_WORDS = ["美国", "美方", "中美", "美中", "美西方", "美媒", "美企", "美政府", "美总统", "美官员", "美议员", "美舰", "美军", "特朗普", "华盛顿", "白宫", "美股", "美联储", "五角大楼",
            "硅谷", "OpenAI", "英伟达", "马斯克", "苹果公司", "谷歌", "微软"]
BOARD_HANDLES = {"hot", "hot_search", "popular", "hotwords", "hot_list", "board"}


def us_related(text: str) -> bool:
    t = text or ""
    return any(w in t for w in US_WORDS) or bool(match_all(t, "zh").get("us_anchor"))


def resolved_id(conn: Connector, handle: str) -> str:
    """A watchlist may carry a display name instead of the platform's numeric id; the first use resolves it through the
    lane's resolver and caches it in the store (kv resolved:<platform>:<name>), so the id is looked up once."""
    h = handle.strip()
    if h.isdigit():
        return h
    key = f"resolved:{conn.platform}:{h.lower()}"
    v = conn.store.kv_get(key, "")
    if v:
        return v
    r = conn.resolve(h)
    if not r or not r.get("id"):
        raise HttpError(404, f"could not resolve {h!r} to a {conn.platform} id; run `publius resolve {conn.platform} \"{h}\"`")
    conn.store.kv_set(key, str(r["id"]))
    return str(r["id"])


def _json(body: bytes) -> dict:
    try:
        v = json.loads(body.decode("utf-8", "replace"))
        return v if isinstance(v, dict) else {"_": v}
    except ValueError:
        return {}


def _get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None, timeout: int = 25) -> tuple[dict, str, bytes]:
    h = {"Accept": "application/json, text/plain, */*", "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.5"}
    h.update(headers or {})
    body, _, final = http_request(url, params=params, headers=h, timeout=timeout, browser=True, retries=1)
    if Connector.closed_by_login(final, body):
        raise RouteClosed(f"login or visitor wall at {final}")
    return _json(body), final, body


# ====================================================================================================== Weibo
WB_INDEX = "https://m.weibo.cn/api/container/getIndex"
WB_HOT = "https://weibo.com/ajax/side/hotSearch"
WB_HOT_M = "https://m.weibo.cn/api/container/getIndex?containerid=106003type%3D25%26t%3D3%26disable_hot%3D1%26filter_type%3Drealtimehot"
_WB_REL = re.compile(r"^(\d+)(分钟|小时)前$")


def weibo_time(s: str, ref: Optional[int] = None) -> Optional[int]:
    """Weibo's created_at comes as 'Fri Sep 26 10:00:00 +0800 2026' on the mobile API, or relative Chinese forms."""
    if not s:
        return None
    s = str(s).strip()
    ref = ref or now()
    try:
        return int(_dt.datetime.strptime(s, "%a %b %d %H:%M:%S %z %Y").timestamp())
    except ValueError:
        pass
    if s in ("刚刚", "刚才"):
        return ref
    m = _WB_REL.match(s)
    if m:
        return ref - int(m.group(1)) * (60 if m.group(2) == "分钟" else 3600)
    cst = _dt.timezone(_dt.timedelta(hours=8))
    today = _dt.datetime.fromtimestamp(ref, cst)
    m = re.match(r"^昨天\s*(\d{1,2}):(\d{2})$", s)
    if m:
        d = (today - _dt.timedelta(days=1)).replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        return int(d.timestamp())
    m = re.match(r"^(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?$", s)
    if m:
        d = today.replace(month=int(m.group(1)), day=int(m.group(2)), hour=int(m.group(3) or 0), minute=int(m.group(4) or 0), second=0, microsecond=0)
        return int(d.timestamp())
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{2}))?$", s)
    if m:
        d = _dt.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4) or 0), int(m.group(5) or 0), tzinfo=cst)
        return int(d.timestamp())
    return parse_iso(s)


def parse_weibo_cards(js: dict, ref: Optional[int] = None) -> list[dict]:
    """The mobile container feed (containerid 107603<uid>): one item per card_type 9 mblog."""
    out = []
    for card in ((js.get("data") or {}).get("cards") or []):
        if not isinstance(card, dict) or int(card.get("card_type") or 0) != 9:
            continue
        mb = card.get("mblog") or {}
        if not isinstance(mb, dict) or not mb.get("id"):
            continue
        user = mb.get("user") or {}
        rt = mb.get("retweeted_status") or {}
        text = mb.get("text") or ""
        if rt:
            text = text + "\n// " + (rt.get("text") or "")
        media = {}
        if mb.get("pics") or rt.get("pics"):
            media["photo"] = len(mb.get("pics") or rt.get("pics") or [])
        pi = mb.get("page_info") or rt.get("page_info") or {}
        if str(pi.get("type", "")).lower() in ("video", "live"):
            media["video"] = 1
        urls = []
        if isinstance(pi.get("page_url"), str) and pi["page_url"].startswith("http"):
            urls.append(pi["page_url"])
        out.append({"id": str(mb.get("id")), "mid": str(mb.get("mid") or mb.get("id")), "ts": weibo_time(mb.get("created_at") or "", ref), "text": clean_text(text),
                    "url": f"https://m.weibo.cn/detail/{mb.get('id')}", "media": media, "urls": urls,
                    "metrics": {"shares": mb.get("reposts_count"), "replies": mb.get("comments_count"), "likes": mb.get("attitudes_count")},
                    "fwd_uid": str((rt.get("user") or {}).get("id") or "") if rt else "", "user": {"id": str(user.get("id") or ""), "name": user.get("screen_name") or "",
                    "followers": user.get("followers_count"), "verified_reason": user.get("verified_reason") or ""}})
    return out


def parse_weibo_hot(js: dict) -> list[dict]:
    """weibo.com/ajax/side/hotSearch (shape read live 26 Sep 2026): data.realtime[] {word, num, rank (0-based), realpos, label_name,
    word_scheme}, data.hotgov {word/name, url, is_gov} and data.hotgovs[] {word, pos}: the pinned government entries (rank 0)."""
    d = js.get("data") or {}
    out, seen = [], set()
    govs = [g for g in (d.get("hotgovs") or []) if isinstance(g, dict)] or ([d["hotgov"]] if isinstance(d.get("hotgov"), dict) else [])
    for g in govs:
        w = g.get("word") or g.get("name")
        if w and w not in seen:
            seen.add(w)
            out.append({"title": w, "heat": int(g.get("num") or 0), "rank": 0, "label": "置顶 " + (g.get("icon_desc") or "") if g.get("icon_desc") else "置顶", "url": g.get("url") or ("https://s.weibo.com/weibo?q=" + urllib.parse.quote(w))})
    for i, it in enumerate(d.get("realtime") or [], 1):
        if not isinstance(it, dict) or not it.get("word"):
            continue
        w = it["word"]
        if w in seen:
            continue
        seen.add(w)
        pos = it.get("realpos") if isinstance(it.get("realpos"), int) and it.get("realpos") > 0 else (int(it["rank"]) + 1 if isinstance(it.get("rank"), int) else i)
        out.append({"title": w, "heat": int(it.get("num") or it.get("raw_hot") or 0), "rank": int(pos), "label": it.get("label_name") or it.get("icon_desc") or "",
                    "url": "https://s.weibo.com/weibo?q=" + urllib.parse.quote(it.get("word_scheme") or ("#" + w + "#"))})
    return out


def parse_weibo_hot_mobile(js: dict) -> list[dict]:
    """The mobile hot list container (a fallback when weibo.com answers with the visitor system): card_type 4 groups."""
    out = []
    for card in ((js.get("data") or {}).get("cards") or []):
        for i, g in enumerate(card.get("card_group") or [], 1):
            if not isinstance(g, dict) or not g.get("desc"):
                continue
            out.append({"title": g["desc"], "heat": int(str(g.get("desc_extr") or "0").split(" ")[-1] or 0) if str(g.get("desc_extr") or "").split(" ")[-1].isdigit() else 0,
                        "rank": i, "label": (g.get("icon_desc") or ""), "url": g.get("scheme") or ""})
    return out


@register
class Weibo(Connector):
    platform = "weibo"
    label = "Weibo (state accounts via the mobile container API; hot search)"
    region = "cn"
    route_class = "open"
    new_in = "2.0"
    reads = "posts of watchlisted state accounts (m.weibo.cn container feed, visitor view) and the public hot-search board"
    refuses = "ordinary users, comments, search about people, any login cookie; a visitor-system or login wall closes the route"
    probe_url = WB_HOT

    def _feed(self, uid: str) -> list[dict]:
        js, final, body = _get(WB_INDEX, params={"type": "uid", "value": uid, "containerid": f"107603{uid}"}, headers={"Referer": f"https://m.weibo.cn/u/{uid}", "X-Requested-With": "XMLHttpRequest"})
        if js.get("ok") in (0, -100) and not (js.get("data") or {}).get("cards"):
            if js.get("ok") == -100 or "登录" in str(js.get("msg", "")):
                raise RouteClosed(f"weibo asks for a login on {uid}: {js.get('msg', '')}")
            raise HttpError(404, f"no content for uid {uid}: {js.get('msg', '')}")
        return parse_weibo_cards(js)

    def _profile(self, uid: str) -> dict:
        js, _, _ = _get(WB_INDEX, params={"type": "uid", "value": uid, "containerid": f"100505{uid}"}, headers={"Referer": f"https://m.weibo.cn/u/{uid}"})
        ui = (js.get("data") or {}).get("userInfo") or {}
        return {"name": ui.get("screen_name") or "", "followers": ui.get("followers_count"), "verified_reason": ui.get("verified_reason") or "", "verified": bool(ui.get("verified")),
                "description": ui.get("description") or ""}

    def resolve(self, name: str) -> Optional[dict]:
        name = name.strip()
        m = re.search(r"/u/(\d{5,})|uid=(\d{5,})|^(\d{5,})$", name)
        if m:
            uid = next(g for g in m.groups() if g)
        else:
            body, _, final = http_request("https://m.weibo.cn/n/" + urllib.parse.quote(name), browser=True, timeout=25, retries=1)
            if self.closed_by_login(final, body):
                raise RouteClosed(f"weibo name lookup: visitor or login wall at {final[:80]}")
            m = re.search(r"/u/(\d{5,})|/profile/(\d{5,})|value=(\d{5,})", final or "") or re.search(r'"id"\s*:\s*"?(\d{5,})"?', body[:200000].decode("utf-8", "replace"))
            if not m:
                return None
            uid = next(g for g in m.groups() if g)
        p = self._profile(uid)
        return {"id": uid, "name": p["name"], "note": (p["verified_reason"] or "no verification label") + (f"; {p['followers']:,} followers" if p.get("followers") else "")}

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            if s["handle"] in BOARD_HANDLES:
                continue
            try:
                p = self._profile(resolved_id(self, s["handle"]))
                st = "live" if p["name"] else "not_found"
                note = (p["verified_reason"] or "no verification label")[:120]
                self.store.set_source_status(s["id"], st, note, followers=p["followers"], name=p["name"] or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": p["followers"]})
            except RouteClosed as e:
                self.store.set_source_status(s["id"], "closed", str(e)[:200]); res.append({"id": s["id"], "status": "closed", "note": str(e)[:200]})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def hot_board(self) -> list[dict]:
        try:
            js, _, _ = _get(WB_HOT, headers={"Referer": "https://weibo.com/"})
            entries = parse_weibo_hot(js)
            if entries:
                return entries
        except RouteClosed:
            pass
        js, _, _ = _get(WB_HOT_M, headers={"Referer": "https://m.weibo.cn/"})
        return parse_weibo_hot_mobile(js)

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        watch = {s["id"]: s for s in self.store.sources(platform=self.platform, enabled_only=True)}
        known_uids = {s["handle"] for s in watch.values() if s["handle"].isdigit()} | {self.store.kv_get(f"resolved:weibo:{s['handle'].strip().lower()}", "") for s in watch.values()}
        known_uids.discard("")

        def one(src: dict):
            h = src["handle"]
            if h in BOARD_HANDLES:
                if not self.cfg.get("hot_search", True):
                    return 0, None
                entries = self.hot_board()
                rep = boards.record(self.store, "weibo", entries)
                n = 0
                for e in entries:
                    if not us_related(e["title"]):
                        continue
                    if self.emit(src, sha1("weibo-hot", e["title"], day(now())), now(), e["title"] + (f" [{e['label']}]" if e.get("label") else ""), url=e["url"], title=e["title"],
                                 metrics={"views": e["heat"], "rank": e["rank"]}):
                        n += 1
                if rep["dropped"]:
                    self.store.set_source_status(src["id"], "live", f"{rep['n']} entries; {len(rep['dropped'])} dropped early since the previous read")
                return n, now()
            if not self.cfg.get("accounts", True):
                return 0, None
            uid = resolved_id(self, h)
            n, newest = 0, None
            for m in self._feed(uid):
                newest = max(newest or 0, m["ts"] or 0)
                fwd = m["fwd_uid"] if m["fwd_uid"] in known_uids else ""      # a repost is attributed only to another watchlisted state account
                if self.emit(src, m["id"], m["ts"], m["text"], url=m["url"], media=m["media"], metrics=m["metrics"], fwd_from=fwd, extra_urls=tuple(m["urls"])):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


# ====================================================================================================== Bilibili
BILI_NAV = "https://api.bilibili.com/x/web-interface/nav"
BILI_SPI = "https://api.bilibili.com/x/frontend/finger/spi"
BILI_ARC = "https://api.bilibili.com/x/space/wbi/arc/search"
BILI_SERIES = "https://api.bilibili.com/x/series/recArchivesByKeywords"     # keyless, unsigned: a user's uploads (verified live 26 Sep 2026)
BILI_CARD = "https://api.bilibili.com/x/web-interface/card"
BILI_POPULAR = "https://api.bilibili.com/x/web-interface/popular"
BILI_SQUARE = "https://api.bilibili.com/x/web-interface/wbi/search/square"
BILI_USER_SEARCH = "https://api.bilibili.com/x/web-interface/wbi/search/type"
BILI_USER_SEARCH_LEGACY = "https://api.bilibili.com/x/web-interface/search/type"
MIXIN_TAB = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60,
             51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52]
_WBI_STRIP = re.compile(r"[!'()*]")


def wbi_mixin_key(img_key: str, sub_key: str) -> str:
    s = img_key + sub_key
    return reduce(lambda acc, i: acc + s[i], MIXIN_TAB, "")[:32]


def wbi_sign(params: dict, img_key: str, sub_key: str, ts: Optional[int] = None) -> dict:
    """The documented WBI signature: sorted query + mixin key, MD5 -> w_rid, with wts. A public request signature, not a credential."""
    mixin = wbi_mixin_key(img_key, sub_key)
    p = {k: _WBI_STRIP.sub("", str(v)) for k, v in params.items()}
    p["wts"] = str(ts or now())
    query = urllib.parse.urlencode(sorted(p.items()))
    p["w_rid"] = hashlib.md5((query + mixin).encode("utf-8")).hexdigest()
    return p


def wbi_keys_from_nav(js: dict) -> tuple[str, str]:
    wi = ((js.get("data") or {}).get("wbi_img") or {})
    def key(u: str) -> str:
        return (u or "").rsplit("/", 1)[-1].split(".")[0]
    return key(wi.get("img_url", "")), key(wi.get("sub_url", ""))


def bili_check(js: dict, what: str) -> dict:
    if "v_voucher" in js and "code" not in js:
        raise RouteClosed(f"bilibili {what}: risk control asked for a verification voucher, which the lane will not answer")
    code = int(js.get("code") or 0)
    if code == 0:
        return js.get("data") or {}
    if code in (-352, -401, -101, -403):
        raise RouteClosed(f"bilibili {what}: code {code} ({js.get('message', '')}) — a risk-control or login demand the lane will not meet")
    if code in (-412, -799, -509):
        raise HttpError(429, f"bilibili {what}: code {code} ({js.get('message', '')})")
    raise HttpError(400, f"bilibili {what}: code {code} {js.get('message', '')}")


def parse_bili_uploads(data: dict) -> list[dict]:
    out = []
    for v in ((data.get("list") or {}).get("vlist") or []):
        if not isinstance(v, dict) or not v.get("bvid"):
            continue
        out.append({"id": v["bvid"], "ts": int(v.get("created") or 0) or None, "title": v.get("title") or "", "text": v.get("description") or "", "url": f"https://www.bilibili.com/video/{v['bvid']}",
                    "metrics": {"views": v.get("play"), "replies": v.get("comment"), "danmaku": v.get("video_review")}, "author": v.get("author") or "", "mid": str(v.get("mid") or "")})
    return out


def parse_bili_archives(data: dict) -> list[dict]:
    """x/series/recArchivesByKeywords: {archives: [{aid, bvid, title, pubdate, stat: {view}, duration}], page: {total}}."""
    out = []
    for v in data.get("archives") or []:
        if not isinstance(v, dict) or not v.get("bvid"):
            continue
        out.append({"id": v["bvid"], "ts": int(v.get("pubdate") or 0) or None, "title": v.get("title") or "", "text": "", "url": f"https://www.bilibili.com/video/{v['bvid']}",
                    "metrics": {"views": (v.get("stat") or {}).get("view"), "duration": v.get("duration")}, "author": "", "mid": str(v.get("upMid") or "")})
    return out


def parse_bili_popular(data: dict) -> list[dict]:
    out = []
    for i, v in enumerate(data.get("list") or [], 1):
        if not isinstance(v, dict) or not v.get("bvid"):
            continue
        st = v.get("stat") or {}
        out.append({"id": v["bvid"], "rank": i, "ts": int(v.get("pubdate") or 0) or None, "title": v.get("title") or "", "text": v.get("desc") or "", "url": f"https://www.bilibili.com/video/{v['bvid']}",
                    "heat": int(st.get("view") or 0), "metrics": {"views": st.get("view"), "likes": st.get("like"), "replies": st.get("reply"), "shares": st.get("share")},
                    "owner": (v.get("owner") or {}).get("name") or "", "owner_mid": str((v.get("owner") or {}).get("mid") or "")})
    return out


def parse_bili_square(data: dict) -> list[dict]:
    lst = ((data.get("trending") or {}).get("list") or []) if isinstance(data, dict) else []
    if not lst and isinstance(data.get("_"), list):     # older shape: a list of {type, data:{list}}
        for blk in data["_"]:
            if isinstance(blk, dict) and blk.get("type") == "trending":
                lst = (blk.get("data") or {}).get("list") or []
    out = []
    for i, it in enumerate(lst, 1):
        if isinstance(it, dict) and (it.get("keyword") or it.get("show_name")):
            w = it.get("show_name") or it.get("keyword")
            out.append({"title": w, "heat": int(it.get("heat_score") or 0), "rank": i, "url": it.get("uri") or ("https://search.bilibili.com/all?keyword=" + urllib.parse.quote(str(it.get("keyword") or w)))})
    return out


@register
class Bilibili(Connector):
    platform = "bilibili"
    label = "Bilibili (state accounts' uploads via the WBI-signed space API; popular list; trending words)"
    region = "cn"
    route_class = "open"
    new_in = "2.0"
    reads = "uploads of watchlisted state accounts (the keyless series endpoint, the WBI-signed space API as fallback), the popular list and the trending search words, with a visitor cookie only"
    refuses = "ordinary users, comments and danmaku text, any login cookie (SESSDATA); a risk-control answer (-352) closes the route"
    probe_url = BILI_POPULAR + "?ps=1&pn=1"

    def __init__(self, section, cfg, store):
        super().__init__(section, cfg, store)
        self._keys: Optional[tuple[str, str, int]] = None
        self._cookie = ""

    def _headers(self) -> dict:
        h = {"Referer": "https://www.bilibili.com/", "Origin": "https://www.bilibili.com"}
        if not self._cookie and self.cfg.get("visitor_cookie", True):
            try:
                js, _, _ = _get(BILI_SPI, headers={"Referer": "https://www.bilibili.com/"})
                d = js.get("data") or {}
                if d.get("b_3"):
                    self._cookie = f"buvid3={d['b_3']}" + (f"; buvid4={d['b_4']}" if d.get("b_4") else "")
            except (HttpError, RouteClosed):
                self._cookie = ""
        if self._cookie:
            h["Cookie"] = self._cookie
        return h

    def _wbi(self) -> tuple[str, str]:
        if self._keys and time.time() - self._keys[2] < 6 * 3600:
            return self._keys[0], self._keys[1]
        js, _, _ = _get(BILI_NAV, headers=self._headers())
        img, sub = wbi_keys_from_nav(js)          # present even when the visitor is not logged in (code -101)
        if not (img and sub):
            raise RouteClosed("bilibili nav gave no WBI keys to a visitor")
        self._keys = (img, sub, int(time.time()))
        return img, sub

    def _signed(self, url: str, params: dict, what: str) -> dict:
        img, sub = self._wbi()
        try:
            js, _, _ = _get(url, params=wbi_sign(params, img, sub), headers=self._headers())
        except HttpError as e:
            if e.status == 412:
                raise RouteClosed(f"bilibili {what}: HTTP 412, the request was blocked by risk control") from None
            raise
        return bili_check(js, what)

    def uploads(self, mid: str, ps: int = 30) -> list[dict]:
        """The keyless series endpoint first (no signature, no risk control seen from a datacenter address); the WBI-signed
        space API only if it answers nothing. Both are public reads of the account's own uploads."""
        try:
            js, _, _ = _get(BILI_SERIES, params={"mid": mid, "keywords": "", "ps": ps, "pn": 1}, headers=self._headers())
            items = parse_bili_archives(bili_check(js, "series"))
            if items:
                return items
        except (HttpError, RouteClosed):
            pass
        return parse_bili_uploads(self._signed(BILI_ARC, {"mid": mid, "ps": ps, "pn": 1, "order": "pubdate", "platform": "web", "web_location": "1550101"}, "uploads"))

    def resolve(self, name: str) -> Optional[dict]:
        name = name.strip()
        m = re.search(r"space\.bilibili\.com/(\d+)|^(\d+)$", name)
        if m:
            mid = next(g for g in m.groups() if g)
            c = self._card(mid)
            return {"id": mid, "name": c["name"], "note": c["official"] or "no official label"} if c["name"] else None
        try:      # the legacy unsigned search answers a visitor (read live 26 Sep 2026); the WBI-signed one is the fallback
            js, _, _ = _get(BILI_USER_SEARCH_LEGACY, params={"search_type": "bili_user", "keyword": name}, headers=self._headers())
            d = bili_check(js, "user search")
        except (HttpError, RouteClosed):
            d = self._signed(BILI_USER_SEARCH, {"search_type": "bili_user", "keyword": name, "page": 1}, "user search")
        rows = [r for r in (d.get("result") or []) if isinstance(r, dict)]
        rows.sort(key=lambda r: (str(r.get("uname", "")).lower() != name.lower(), int((r.get("official_verify") or {}).get("type", -1)) != 1, -int(r.get("fans") or 0)))
        if not rows:
            return None
        r = rows[0]
        ov = r.get("official_verify") or {}
        return {"id": str(r.get("mid")), "name": r.get("uname") or "", "note": (ov.get("desc") or "no official label") + (f"; {int(r.get('fans') or 0):,} fans" if r.get("fans") else "")}

    def _card(self, mid: str) -> dict:
        js, _, _ = _get(BILI_CARD, params={"mid": mid, "photo": "false"}, headers=self._headers())
        d = bili_check(js, "card")
        c = d.get("card") or {}
        off = c.get("Official") or {}
        return {"name": c.get("name") or "", "fans": c.get("fans"), "official": off.get("title") or off.get("desc") or "", "official_role": off.get("role")}

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            if s["handle"] in BOARD_HANDLES:
                continue
            try:
                c = self._card(resolved_id(self, s["handle"]))
                st = "live" if c["name"] else "not_found"
                note = (c["official"] or "no official label")[:120]
                self.store.set_source_status(s["id"], st, note, followers=c["fans"], name=c["name"] or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": c["fans"]})
            except RouteClosed as e:
                self.store.set_source_status(s["id"], "closed", str(e)[:200]); res.append({"id": s["id"], "status": "closed", "note": str(e)[:200]})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            h = src["handle"]
            if h in ("popular", "board", "hot"):
                if not self.cfg.get("popular", True):
                    return 0, None
                js, _, _ = _get(BILI_POPULAR, params={"ps": 50, "pn": 1}, headers=self._headers())
                items = parse_bili_popular(bili_check(js, "popular"))
                boards.record(self.store, "bilibili_popular", [{"title": it["title"], "heat": it["heat"], "rank": it["rank"]} for it in items])
                n = 0
                for it in items:
                    if not us_related(it["title"] + " " + it["text"]):
                        continue
                    if self.emit(src, sha1("bili-popular", it["id"], day(now())), it["ts"] or now(), it["text"], url=it["url"], title=it["title"], media={"video": 1},
                                 metrics=dict(it["metrics"], rank=it["rank"])):
                        n += 1
                return n, now()
            if h in ("hotwords", "hot_search"):
                if not self.cfg.get("hot_words", True):
                    return 0, None
                d = self._signed(BILI_SQUARE, {"limit": 50, "platform": "web"}, "search square")
                entries = parse_bili_square(d)
                boards.record(self.store, "bilibili_hotwords", entries)
                n = 0
                for e in entries:
                    if us_related(e["title"]) and self.emit(src, sha1("bili-hot", e["title"], day(now())), now(), e["title"], url=e["url"], title=e["title"], metrics={"views": e["heat"], "rank": e["rank"]}):
                        n += 1
                return n, now()
            mid = resolved_id(self, h)
            n, newest = 0, None
            for v in self.uploads(mid):
                newest = max(newest or 0, v["ts"] or 0)
                if self.emit(src, v["id"], v["ts"], v["text"], url=v["url"], title=v["title"], media={"video": 1}, metrics=v["metrics"]):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


# ====================================================================================================== Zhihu
ZH_HOT = "https://www.zhihu.com/api/v3/feed/topstory/hot-lists/total"
ZH_TOP = "https://www.zhihu.com/api/v4/search/top_search/tabs/hot/items"      # trending searches; answers a visitor (read live 26 Sep 2026)
ZH_MEMBER = "https://www.zhihu.com/api/v4/members/{token}"
ZH_ACT = "https://www.zhihu.com/api/v4/members/{token}/activities"
ZH_PINS = "https://www.zhihu.com/api/v4/members/{token}/pins"
_ZH_HEAT = re.compile(r"([\d.]+)\s*万?\s*热度")


def zhihu_url(u: str) -> str:
    """api.zhihu.com/questions/1 -> www.zhihu.com/question/1; answers and articles likewise."""
    if not u:
        return ""
    u = u.replace("https://api.zhihu.com/questions/", "https://www.zhihu.com/question/").replace("https://api.zhihu.com/answers/", "https://www.zhihu.com/answer/")
    u = u.replace("https://api.zhihu.com/articles/", "https://zhuanlan.zhihu.com/p/").replace("https://api.zhihu.com/pins/", "https://www.zhihu.com/pin/")
    return u


def parse_zhihu_hot(js: dict) -> list[dict]:
    out = []
    for i, it in enumerate(js.get("data") or [], 1):
        t = (it or {}).get("target") or {}
        title = t.get("title") or t.get("title_area", {}).get("text") if isinstance(t.get("title_area"), dict) else t.get("title")
        if not title:
            continue
        m = _ZH_HEAT.search(str(it.get("detail_text") or ""))
        heat = int(float(m.group(1)) * (10000 if "万" in str(it.get("detail_text") or "") else 1)) if m else 0
        out.append({"title": title, "excerpt": t.get("excerpt") or "", "url": zhihu_url(t.get("url") or t.get("link", {}).get("url", "") if isinstance(t.get("link"), dict) else t.get("url") or ""),
                    "heat": heat, "rank": i, "ts": int(t.get("created") or 0) or None})
    return out


def parse_zhihu_top(js: dict) -> list[dict]:
    """api/v4/search/top_search/tabs/hot/items: {data: [{query_display, real_query, query_description, index}]} (no heat figure)."""
    out = []
    for i, it in enumerate(js.get("data") or [], 1):
        if not isinstance(it, dict):
            continue
        w = it.get("query_display") or it.get("real_query")
        if not w:
            continue
        idx = it.get("index")
        out.append({"title": w, "excerpt": it.get("query_description") or "", "heat": 0, "rank": int(idx) + 1 if isinstance(idx, int) and idx >= i - 1 and idx > 0 else i, "ts": None,
                    "url": it.get("redirect_link") or ("https://www.zhihu.com/search?type=content&q=" + urllib.parse.quote(str(it.get("real_query") or w)))})
    return out


def parse_zhihu_activities(js: dict, own_token: str) -> list[dict]:
    """Only the member's own writing (answers, articles, pins). An upvote or a follow names someone else and is skipped."""
    out = []
    for a in js.get("data") or []:
        t = (a or {}).get("target") or {}
        kind = t.get("type") or ""
        au = (t.get("author") or {}).get("url_token") or ""
        if kind not in ("answer", "article", "pin") or (au and au != own_token):
            continue
        if kind == "answer":
            title = ((t.get("question") or {}).get("title")) or ""
            body = t.get("excerpt") or t.get("content") or ""
            url = zhihu_url(t.get("url") or "") or (f"https://www.zhihu.com/question/{(t.get('question') or {}).get('id')}/answer/{t.get('id')}" if t.get("id") else "")
        elif kind == "article":
            title = t.get("title") or ""
            body = t.get("excerpt") or t.get("content") or ""
            url = zhihu_url(t.get("url") or "") or (f"https://zhuanlan.zhihu.com/p/{t.get('id')}" if t.get("id") else "")
        else:
            title = ""
            body = " ".join(c.get("content") or "" for c in (t.get("content") or []) if isinstance(c, dict) and c.get("type") == "text") or t.get("excerpt_title") or ""
            url = zhihu_url(t.get("url") or "") or (f"https://www.zhihu.com/pin/{t.get('id')}" if t.get("id") else "")
        ts = int(t.get("created_time") or t.get("created") or t.get("updated") or a.get("created_time") or 0) or None
        out.append({"id": f"{kind}:{t.get('id')}", "kind": kind, "ts": ts, "title": clean_text(title, 300), "text": clean_text(body), "url": url,
                    "metrics": {"likes": t.get("voteup_count") if kind != "pin" else t.get("like_count"), "replies": t.get("comment_count")}})
    return out


def parse_zhihu_pins(js: dict) -> list[dict]:
    out = []
    for p in js.get("data") or []:
        if not isinstance(p, dict) or not p.get("id"):
            continue
        body = " ".join(c.get("content") or "" for c in (p.get("content") or []) if isinstance(c, dict) and c.get("type") == "text")
        out.append({"id": f"pin:{p['id']}", "kind": "pin", "ts": int(p.get("created") or p.get("updated") or 0) or None, "title": "", "text": clean_text(body),
                    "url": zhihu_url(p.get("url") or "") or f"https://www.zhihu.com/pin/{p['id']}", "metrics": {"likes": p.get("like_count") or p.get("reaction_count"), "replies": p.get("comment_count")}})
    return out


def zhihu_closed(js: dict, status: int = 200) -> Optional[str]:
    if status in (401, 403):
        return f"HTTP {status}: zhihu demands a signed request (x-zse-96) or a login"
    err = js.get("error") if isinstance(js, dict) else None
    if isinstance(err, dict) and int(err.get("code") or 0) in (101, 10001, 4041, 40310, 10003, 100001):
        return f"zhihu error {err.get('code')}: {err.get('message', '')}"
    return None


@register
class Zhihu(Connector):
    platform = "zhihu"
    label = "Zhihu (state accounts' answers, articles and pins; the hot list)"
    region = "cn"
    route_class = "open"
    new_in = "2.0"
    reads = "the trending-search board (and the hot list where it answers a visitor), and the own writing of watchlisted state accounts (answers, articles, pins) as a visitor sees it"
    refuses = "ordinary users, comments, upvotes and follows (they name someone else), any login cookie (z_c0); a signature demand (x-zse-96) or an authentication error closes the route"
    probe_url = ZH_TOP

    def _api(self, url: str, params: Optional[dict] = None) -> dict:
        try:
            js, final, body = _get(url, params=params, headers={"Referer": "https://www.zhihu.com/", "x-requested-with": "fetch"})
        except HttpError as e:
            msg = zhihu_closed({}, e.status)
            if msg:
                raise RouteClosed(msg) from None
            raise
        msg = zhihu_closed(js)
        if msg:
            raise RouteClosed(msg)
        return js

    def _member(self, token: str) -> dict:
        js = self._api(ZH_MEMBER.format(token=urllib.parse.quote(token)), params={"include": "follower_count,headline,badge_v2,is_org,answer_count,articles_count"})
        badge = js.get("badge_v2") or {}
        return {"name": js.get("name") or "", "followers": js.get("follower_count"), "is_org": bool(js.get("is_org")), "badge": badge.get("title") or "", "headline": js.get("headline") or ""}

    def resolve(self, name: str) -> Optional[dict]:
        m = re.search(r"zhihu\.com/(?:people|org)/([A-Za-z0-9_-]+)", name.strip())
        tok = m.group(1) if m else name.strip()
        try:
            mm = self._member(tok)
        except HttpError:
            return None
        return {"id": tok, "name": mm["name"], "note": (mm["badge"] or ("organisation account" if mm["is_org"] else "no badge")) + (f"; {mm['followers']:,} followers" if mm.get("followers") else "")} if mm["name"] else None

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            if s["handle"] in BOARD_HANDLES:
                continue
            try:
                mm = self._member(s["handle"])
                st = "live" if mm["name"] else "not_found"
                note = (mm["badge"] or ("organisation account" if mm["is_org"] else "no badge"))[:120]
                self.store.set_source_status(s["id"], st, note, followers=mm["followers"], name=mm["name"] or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": mm["followers"]})
            except RouteClosed as e:
                self.store.set_source_status(s["id"], "closed", str(e)[:200]); res.append({"id": s["id"], "status": "closed", "note": str(e)[:200]})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            h = src["handle"]
            if h in BOARD_HANDLES:
                if not self.cfg.get("hot_list", True):
                    return 0, None
                entries = parse_zhihu_top(self._api(ZH_TOP))
                try:                                      # the hot list carries heat figures when it answers a visitor; it often demands a login
                    hot = parse_zhihu_hot(self._api(ZH_HOT, params={"limit": 50, "desktop": "true"}))
                    seen = {e["title"] for e in entries}
                    entries += [e for e in hot if e["title"] not in seen]
                    boards.record(self.store, "zhihu_hot", [{"title": e["title"], "heat": e["heat"], "rank": e["rank"]} for e in hot])
                except (HttpError, RouteClosed):
                    pass
                boards.record(self.store, "zhihu", [{"title": e["title"], "heat": e["heat"], "rank": e["rank"]} for e in entries if e["url"].startswith("https://www.zhihu.com/search") or e["heat"] == 0])
                n = 0
                for e in entries:
                    if us_related(e["title"] + " " + e["excerpt"]) and self.emit(src, sha1("zhihu-hot", e["title"], day(now())), e["ts"] or now(), e["excerpt"] or e["title"], url=e["url"], title=e["title"],
                                                                                metrics={"views": e["heat"], "rank": e["rank"]}):
                        n += 1
                return n, now()
            if not self.cfg.get("members", True):
                return 0, None
            items = parse_zhihu_activities(self._api(ZH_ACT.format(token=urllib.parse.quote(h)), params={"limit": 20, "desktop": "True"}), h)
            try:
                items += parse_zhihu_pins(self._api(ZH_PINS.format(token=urllib.parse.quote(h)), params={"limit": 20}))
            except (HttpError, RouteClosed):
                pass
            n, newest, seen = 0, None, set()
            for it in items:
                if it["id"] in seen:
                    continue
                seen.add(it["id"])
                newest = max(newest or 0, it["ts"] or 0)
                if self.emit(src, it["id"], it["ts"], it["text"], url=it["url"], title=it["title"], metrics=it["metrics"]):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


# ====================================================================================================== Douyin
DY_HOT = "https://www.douyin.com/aweme/v1/web/hot/search/list/"
DY_PARAMS = {"device_platform": "webapp", "aid": "6383", "channel": "channel_pc_web", "detail_list": "1", "source": "6", "pc_client_type": "1", "version_code": "170400",
             "version_name": "17.4.0", "cookie_enabled": "true", "screen_width": "1920", "screen_height": "1080", "browser_language": "zh-CN", "browser_platform": "Win32",
             "browser_name": "Chrome", "browser_version": "128.0.0.0", "browser_online": "true", "engine_name": "Blink", "engine_version": "128.0.0.0", "os_name": "Windows",
             "os_version": "10", "cpu_core_num": "8", "device_memory": "8", "platform": "PC"}


def parse_douyin_hot(js: dict) -> list[dict]:
    d = js.get("data") or {}
    out = []
    for it in d.get("word_list") or []:
        if not isinstance(it, dict) or not it.get("word"):
            continue
        pos = int(it.get("position") or len(out) + 1)
        out.append({"title": it["word"], "heat": int(it.get("hot_value") or 0), "rank": pos, "label": int(it.get("label") or 0), "ts": int(it.get("event_time") or 0) or None,
                    "url": f"https://www.douyin.com/hot/{it.get('sentence_id')}" if it.get("sentence_id") else "https://www.douyin.com/search/" + urllib.parse.quote(it["word"])})
    out.sort(key=lambda e: e["rank"])
    return out


@register
class Douyin(Connector):
    platform = "douyin"
    label = "Douyin (hot board only)"
    region = "cn"
    route_class = "open"
    new_in = "2.0"
    reads = "the public hot board (word, heat, rank, event time)"
    refuses = "account pages and search (their API demands a forged request signature, X-Bogus, which the lane will not produce), comments, users, any cookie beyond what the board sets"
    probe_url = DY_HOT + "?" + urllib.parse.urlencode(DY_PARAMS)

    def board(self) -> list[dict]:
        js, final, body = _get(DY_HOT, params=DY_PARAMS, headers={"Referer": "https://www.douyin.com/hot", "Accept": "application/json"})
        if not body:
            raise RouteClosed("douyin answered the hot board with an empty body (the endpoint wants the web client's cookies from this address)")
        if not js or int(js.get("status_code") or 0) != 0:
            head = body[:300].decode("utf-8", "replace") if body else ""
            if "verify" in head.lower() or "<html" in head.lower():
                raise RouteClosed("douyin answered the hot board with a verification page")
            raise HttpError(400, f"douyin status {js.get('status_code')}: {js.get('status_msg', '')}")
        return parse_douyin_hot(js)

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            if src["handle"] not in BOARD_HANDLES:
                self.store.set_source_status(src["id"], "no_route", "no lawful route to account pages: the profile API demands a forged signature; only the hot board is read")
                return 0, None
            entries = self.board()
            rep = boards.record(self.store, "douyin", entries)
            n = 0
            for e in entries:
                if us_related(e["title"]) and self.emit(src, sha1("douyin-hot", e["title"], day(now())), e["ts"] or now(), e["title"], url=e["url"], title=e["title"], metrics={"views": e["heat"], "rank": e["rank"]}):
                    n += 1
            self.store.set_source_status(src["id"], "live", f"{rep['n']} entries" + (f"; {len(rep['dropped'])} dropped early" if rep["dropped"] else ""))
            return n, now()
        return self.run_sources(one, max_sources)
