"""Iranian domestic platforms: the state-promoted messengers and the video host that the Islamic Republic's outlets and
offices publish on, read through their public share pages and public JSON.

  bale     Bale (ble.ir), the Bank Melli messenger the state pushes as its Telegram substitute: public channel pages
  splus    Soroush Plus (splus.ir), the IRIB messenger: public channel pages
  aparat   Aparat (aparat.com), the state-favoured video host: the public JSON API (channel videos, channel info)
  virasty  Virasty (virasty.com), the state-backed microblog: public profile pages, best effort
  eitaa    stays in gated.py (unchanged route, new metadata)

All four sit behind hosts that often refuse US IP space, and none was reachable from the build network, so every parser
is heuristic and exercised on fixtures only; `publius probe` and `publius verify` settle the routes from the operator's
network. A login wall closes a route (RouteClosed). Only channels are read; groups and users never."""
from __future__ import annotations

import html
import json
import re
import urllib.parse
from typing import Any, Iterable, Optional

from ..util import HttpError, clean_text, http_get_json, http_request, now, parse_count, parse_iso, sha1
from .base import Connector, RouteClosed, Stats, register

_NEXT = re.compile(r'<script[^>]+id="__NEXT_DATA__"[^>]*>(.*?)</script>', re.S)
_STATE = re.compile(r'window\.__(?:INITIAL_STATE|NUXT|PRELOADED_STATE)__\s*=\s*(\{.*?\})\s*;?\s*</script>', re.S)
_OG_TITLE = re.compile(r'<meta property="og:title" content="([^"]*)"')
_OG_DESC = re.compile(r'<meta property="og:description" content="([^"]*)"')
_TIME = re.compile(r'<time[^>]*datetime="([^"]+)"')
_HREF = re.compile(r'href="(https?://[^"]+)"')


def page_state(page: str) -> Any:
    """The JSON a server-rendered page ships to its script (Next.js __NEXT_DATA__, Nuxt/Redux window state)."""
    for rx in (_NEXT, _STATE):
        m = rx.search(page)
        if m:
            try:
                return json.loads(m.group(1))
            except ValueError:
                continue
    return None


def walk(obj: Any, depth: int = 0) -> Iterable[dict]:
    if depth > 12:
        return
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            yield from walk(v, depth + 1)
    elif isinstance(obj, list):
        for v in obj:
            yield from walk(v, depth + 1)


_TEXT_KEYS = ("text", "message", "content", "body", "caption")
_TIME_KEYS = ("date", "time", "created_at", "createdAt", "timestamp", "sent_at", "published_at", "dateTime")
_ID_KEYS = ("id", "message_id", "messageId", "mid", "post_id", "postId", "rid")


def message_like(state: Any, min_text: int = 2) -> list[dict]:
    """Objects that look like messages: a text field and a time field. Author fields are never read out: a channel's
    posts belong to the channel on the watchlist; a message that carries a sender who is a person is dropped."""
    out, seen = [], set()
    for d in walk(state):
        tk = next((k for k in _TEXT_KEYS if isinstance(d.get(k), str) and len(d[k].strip()) >= min_text), None)
        if not tk:
            continue
        tv = next((d[k] for k in _TIME_KEYS if d.get(k) not in (None, "")), None)
        if tv is None:
            continue
        sender = d.get("sender") or d.get("author") or d.get("user") or {}
        if isinstance(sender, dict) and (sender.get("is_user") or sender.get("type") in ("user", "private")):
            continue
        ts = _ts(tv)
        mid = next((str(d[k]) for k in _ID_KEYS if d.get(k) not in (None, "")), None) or sha1(d[tk], ts or 0)
        if mid in seen:
            continue
        seen.add(mid)
        media = {}
        for k in ("photo", "image", "images", "video", "media", "attachments", "file"):
            v = d.get(k)
            if v:
                kind = "video" if "video" in k or (isinstance(v, dict) and "video" in str(v.get("type", "")).lower()) else "photo"
                media[kind] = media.get(kind, 0) + (len(v) if isinstance(v, list) else 1)
        views = d.get("views") or d.get("view_count") or d.get("viewCount") or d.get("seen")
        out.append({"id": mid, "ts": ts, "text": clean_text(d[tk]), "media": media, "views": parse_count(str(views)) if views not in (None, "") else None,
                    "urls": [u for u in re.findall(r"https?://[^\s\"'<>]+", str(d[tk]))]})
    return out


def _ts(v: Any) -> Optional[int]:
    if isinstance(v, (int, float)):
        v = int(v)
        return v // 1000 if v > 10_000_000_000 else v
    if isinstance(v, str):
        if v.isdigit():
            return _ts(int(v))
        return parse_iso(v)
    return None


def parse_channel_page(page: str, handle: str) -> dict:
    """A public channel page from a messenger's web front: title, subscriber count, messages (from the page state when the
    page ships one, else from the rendered HTML)."""
    title = html.unescape((_OG_TITLE.search(page) or [None, ""])[1] or "")
    subs = None
    m = re.search(r'([\d.,]+\s*[KkMm]?)\s*(?:subscribers|members|عضو|مشترک|دنبال)', page)
    if m:
        subs = parse_count(m.group(1).replace(" ", ""))
    msgs = []
    st = page_state(page)
    if st is not None:
        msgs = message_like(st)
    if not msgs:
        blocks = re.split(r'<div[^>]+class="[^"]*(?:message|post)[^"]*"[^>]*data-(?:message-)?id="([^"]+)"', page)
        for i in range(1, len(blocks) - 1, 2):
            mid, blk = blocks[i], blocks[i + 1]
            tm = _TIME.search(blk)
            txt = re.search(r'<(?:div|p|span)[^>]+class="[^"]*(?:text|body|content)[^"]*"[^>]*>(.*?)</(?:div|p|span)>', blk, re.S)
            if not txt:
                continue
            urls = [html.unescape(u) for u in _HREF.findall(txt.group(1)) if handle.lower() not in u.lower()]
            msgs.append({"id": mid, "ts": parse_iso(tm.group(1)) if tm else None, "text": clean_text(txt.group(1)), "media": {"photo": 1} if "<img" in blk else {}, "views": None, "urls": urls})
    return {"title": title, "subscribers": subs, "messages": msgs}


class _MessengerPages(Connector):
    """Shared shape of the two messenger lanes: fetch the public channel page, parse, emit. Groups are never read
    (the page of a group would carry its members' conversation) and a login wall closes the route."""
    base = ""
    region = "ir"
    route_class = "open"
    new_in = "2.0"

    def url(self, handle: str) -> str:
        return self.base + urllib.parse.quote(handle.lstrip("@"))

    def fetch(self, handle: str) -> dict:
        body, _, final = http_request(self.url(handle), browser=True, timeout=30, retries=1)
        page = body.decode("utf-8", "replace")
        if self.closed_by_login(final, body) or ("/login" in final) or ("ورود" in page[:5000] and "<form" in page[:5000]):
            raise RouteClosed(f"login wall at {final}")
        if re.search(r'(?i)\b(group|گروه)\b[^<]{0,40}(members|عضو)', page[:8000]) and "channel" not in page[:8000].lower() and "کانال" not in page[:8000]:
            raise HttpError(403, "refused: this page is a group (its members' conversation), not a channel")
        return parse_channel_page(page, handle)

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                d = self.fetch(s["handle"])
                last = max([m["ts"] or 0 for m in d["messages"]] or [0]) or None
                st = "live" if d["messages"] else ("empty" if d["title"] else "not_found")
                note = f"{len(d['messages'])} messages visible" if d["messages"] else "no messages parsed from the public page"
                self.store.set_source_status(s["id"], st, note, followers=d["subscribers"], last_post_ts=last, name=d["title"] or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": d["subscribers"], "title": d["title"]})
            except RouteClosed as e:
                self.store.set_source_status(s["id"], "closed", str(e)[:200]); res.append({"id": s["id"], "status": "closed", "note": str(e)[:200]})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                note = (str(e)[:150] + " — host not reachable from this network; Iranian hosts often refuse US IP space") if st == "unreachable" else str(e)[:200]
                self.store.set_source_status(s["id"], st, note); res.append({"id": s["id"], "status": st, "note": note})
        return res

    def watch_sources(self) -> list[dict]:
        return [s for s in super().watch_sources() if s.get("status") not in ("unreachable", "closed")]

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            d = self.fetch(src["handle"])
            if d["subscribers"]:
                self.store.set_source_status(src["id"], "live", src.get("status_note") or "", followers=d["subscribers"])
            n, newest = 0, None
            for m in d["messages"]:
                if not (m["text"] or m["media"]):
                    continue
                newest = max(newest or 0, m["ts"] or 0)
                if self.emit(src, str(m["id"]), m["ts"], m["text"], url=self.url(src["handle"]) + "/" + str(m["id"]), media=m["media"], metrics={"views": m["views"]}, extra_urls=tuple(m["urls"])):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Bale(_MessengerPages):
    platform = "bale"
    label = "Bale (ble.ir public channel pages)"
    base = "https://ble.ir/"
    reads = "public channel pages of watchlisted state outlets and offices (text, links, media kinds, views where shown)"
    refuses = "groups, users, anything behind the web client's login; a login wall closes the route"
    probe_url = "https://ble.ir/"


@register
class Splus(_MessengerPages):
    platform = "splus"
    label = "Soroush Plus (splus.ir public channel pages)"
    base = "https://splus.ir/"
    reads = "public channel pages of watchlisted state outlets and offices"
    refuses = "groups, users, anything behind a login; a login wall closes the route"
    probe_url = "https://splus.ir/"


# ====================================================================================================== Aparat
AP_V1 = "https://www.aparat.com/api/fa/v1"
AP_LEGACY = "https://www.aparat.com/etc/api"


def parse_aparat_videos(js: Any) -> list[dict]:
    """v1 (data[].attributes) or the legacy etc/api shape (videobyuser[])."""
    rows: list[dict] = []
    if isinstance(js, dict) and isinstance(js.get("data"), list):
        for d in js["data"]:
            a = (d or {}).get("attributes") if isinstance(d, dict) else None
            if isinstance(a, dict):
                rows.append(a)
    elif isinstance(js, dict) and isinstance(js.get("videobyuser"), list):
        rows = [r for r in js["videobyuser"] if isinstance(r, dict)]
    out = []
    for a in rows:
        uid = a.get("uid") or a.get("id")
        if not uid:
            continue
        ts = None
        for k in ("create_date", "sdate_rss", "sdate_gmt", "sdate", "publish_date"):
            if a.get(k):
                ts = parse_iso(str(a[k]))
                if ts:
                    break
        if not ts and a.get("sdate_timediff"):
            ts = _ts(a["sdate_timediff"])
        out.append({"id": str(uid), "ts": ts, "title": a.get("title") or "", "text": a.get("description") or a.get("descr") or "", "url": f"https://www.aparat.com/v/{uid}",
                    "views": parse_count(str(a.get("visit_cnt") or a.get("visit_cnt_non_formatted") or "")), "duration": a.get("duration")})
    return out


def parse_aparat_user(js: Any) -> dict:
    a = {}
    if isinstance(js, dict):
        d = js.get("data")
        a = (d.get("attributes") if isinstance(d, dict) else {}) or (js.get("profile") or {})
    return {"name": a.get("name") or a.get("username") or "", "followers": parse_count(str(a.get("follower_cnt") or a.get("follower_cnt_non_formatted") or "")),
            "videos": parse_count(str(a.get("video_cnt") or "")), "official": bool(a.get("official") or a.get("is_official") or a.get("verified"))}


@register
class Aparat(Connector):
    platform = "aparat"
    label = "Aparat (public JSON API: channel videos)"
    region = "ir"
    route_class = "open"
    new_in = "2.0"
    reads = "videos of watchlisted state channels (title, description, views) and channel info, from the public JSON API"
    refuses = "comments, viewers, playlists of individuals, anything behind a login"
    probe_url = AP_V1 + "/video/video/list/username/aparat"

    def _videos(self, user: str) -> list[dict]:
        u = urllib.parse.quote(user)
        try:
            js = http_get_json(f"{AP_V1}/video/video/list/username/{u}", headers={"Referer": "https://www.aparat.com/"}, timeout=30)
            vids = parse_aparat_videos(js)
            if vids:
                return vids
        except (HttpError, ValueError):
            pass
        return parse_aparat_videos(http_get_json(f"{AP_LEGACY}/videoByUser/username/{u}", timeout=30))

    def _user(self, user: str) -> dict:
        u = urllib.parse.quote(user)
        try:
            return parse_aparat_user(http_get_json(f"{AP_V1}/user/user/information/username/{u}", headers={"Referer": "https://www.aparat.com/"}, timeout=30))
        except (HttpError, ValueError):
            return parse_aparat_user(http_get_json(f"{AP_LEGACY}/profile/username/{u}", timeout=30))

    def resolve(self, name: str) -> Optional[dict]:
        m = re.search(r"aparat\.com/([A-Za-z0-9_.-]+)", name.strip())
        u = m.group(1) if m else name.strip().lstrip("@")
        try:
            info = self._user(u)
        except HttpError:
            return None
        return {"id": u, "name": info["name"], "note": ("official" if info["official"] else "no official flag") + (f"; {info['followers']:,} followers" if info.get("followers") else "")} if info["name"] else None

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                info = self._user(s["handle"])
                vids = self._videos(s["handle"]) if info["name"] else []
                last = max([v["ts"] or 0 for v in vids] or [0]) or None
                st = "live" if vids else ("empty" if info["name"] else "not_found")
                note = f"{len(vids)} videos listed" + ("; official" if info["official"] else "")
                self.store.set_source_status(s["id"], st, note, followers=info["followers"], last_post_ts=last, name=info["name"] or None)
                res.append({"id": s["id"], "status": st, "note": note, "followers": info["followers"]})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            n, newest = 0, None
            for v in self._videos(src["handle"]):
                newest = max(newest or 0, v["ts"] or 0)
                if self.emit(src, v["id"], v["ts"], v["text"], url=v["url"], title=v["title"], media={"video": 1}, metrics={"views": v["views"]}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


# ====================================================================================================== Virasty
@register
class Virasty(_MessengerPages):
    platform = "virasty"
    label = "Virasty (public profile pages, best effort)"
    base = "https://virasty.com/"
    reads = "public profile pages of watchlisted state accounts, parsed from the page state the site ships"
    refuses = "ordinary users, replies, followers, anything behind a login; a login wall closes the route"
    probe_url = "https://virasty.com/"

    def fetch(self, handle: str) -> dict:
        body, _, final = http_request(self.url(handle), browser=True, timeout=30, retries=1)
        page = body.decode("utf-8", "replace")
        if self.closed_by_login(final, body):
            raise RouteClosed(f"login wall at {final}")
        st = page_state(page)
        msgs = message_like(st) if st is not None else []
        title = html.unescape((_OG_TITLE.search(page) or [None, ""])[1] or "")
        subs = None
        m = re.search(r'"(?:followers|follower_count|followersCount)"\s*:\s*(\d+)', page)
        if m:
            subs = int(m.group(1))
        return {"title": title, "subscribers": subs, "messages": msgs}
