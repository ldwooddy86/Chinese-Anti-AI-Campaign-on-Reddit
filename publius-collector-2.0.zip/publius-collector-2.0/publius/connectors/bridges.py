"""Bridges: routes that run through something the operator hosts.

  rsshub     An RSSHub instance the operator runs (rsshub.base_url, loopback or LAN). RSSHub turns platform pages into
             feeds; the lane reads the routes listed in the watchlist (a state account's route, never a search route or
             a user's). The public demo instance (rsshub.app) is refused: it is rate-limited, shared, and would put the
             operator's watchlist on someone else's server.
  wechat_mp  WeChat Official Accounts. There is no account-level feed, but an Official Account's public message album
             (mp.weixin.qq.com/mp/appmsgalbum, the page the account itself publishes for sharing) answers as JSON without a
             login. The lane reads that directly; with an RSSHub instance configured it reads the same album through the
             bridge. Reader-side mirrors (sogou, wxnmh, feeddd) are third parties scraping WeChat and are refused.

Handles
  rsshub     the route path, e.g. /weibo/user/1234567 or /bilibili/user/video/12345
  wechat_mp  <__biz>/<album_id>  (from the album URL: __biz=... album_id=...)"""
from __future__ import annotations

import json
import re
import urllib.parse
from typing import Optional

from ..util import HttpError, clean_text, http_request, now, parse_iso, sha1
from .base import Connector, RouteClosed, Stats, register
from .rss import Rss, parse_feed

REFUSED_ROUTES = re.compile(r"^/(?:weibo/search|weibo/keyword|zhihu/search|bilibili/search|douyin/search|xiaohongshu/search|twitter/keyword|telegram/search|.*?/user/[^/]+/(?:followers|following|friends))", re.I)
DEMO_HOSTS = ("rsshub.app", "rsshub.rssforever.com")
ALBUM = "https://mp.weixin.qq.com/mp/appmsgalbum"


def parse_album(js: dict) -> list[dict]:
    resp = js.get("getalbum_resp") or js
    arts = resp.get("article_list") or []
    if isinstance(arts, dict):
        arts = [arts]
    out = []
    for a in arts:
        if not isinstance(a, dict) or not (a.get("url") or a.get("link")):
            continue
        u = a.get("url") or a.get("link")
        ct = a.get("create_time") or a.get("createTime")
        try:
            ts = int(ct) if ct not in (None, "") else None
        except (TypeError, ValueError):
            ts = parse_iso(str(ct))
        out.append({"id": a.get("msgid") or a.get("key") or sha1(u), "ts": ts, "title": clean_text(a.get("title") or "", 300), "text": clean_text(a.get("digest") or a.get("desc") or ""),
                    "url": u, "cover": a.get("cover_img_1_1") or a.get("cover") or ""})
    return out


@register
class RssHub(Rss):
    platform = "rsshub"
    label = "RSSHub bridge (operator-hosted instance; watchlisted routes)"
    region = "global"
    route_class = "bridge"
    new_in = "2.0"
    requires = ("base_url",)
    reads = "the feeds an operator-hosted RSSHub renders for watchlisted state-account routes (Weibo, Bilibili, Douyin, Zhihu, WeChat albums, Toutiao, Kuaishou, Rednote, VK, Telegram)"
    refuses = "the public demo instance, search and keyword routes, follower/following routes, any route for an individual"

    def ready(self) -> tuple[bool, str]:
        ok, why = super().ready()
        if not ok:
            return ok, why
        host = urllib.parse.urlparse(str(self.cfg.get("base_url", ""))).netloc.lower()
        if any(h in host for h in DEMO_HOSTS):
            return False, "rsshub.base_url points at the public demo instance; run your own (docker.io/diygod/rsshub) and point base_url at it"
        return True, "ok"

    def probe(self) -> dict:
        ok, why = self.ready()
        if not ok:
            return {"ok": None, "note": why}
        try:
            body, _, final = http_request(str(self.cfg["base_url"]).rstrip("/") + "/healthz", timeout=10, retries=0)
            return {"ok": True, "note": f"instance answered: {body[:60].decode('utf-8', 'replace')!r}"}
        except HttpError as e:
            return {"ok": False, "note": f"instance not reachable: {e}"}

    def route_url(self, handle: str) -> str:
        h = handle if handle.startswith("/") else "/" + handle
        if REFUSED_ROUTES.search(h):
            raise HttpError(403, f"refused route {h}: search, keyword and follower routes are not read")
        base = str(self.cfg["base_url"]).rstrip("/")
        key = str(self.cfg.get("access_key", "") or "")
        return base + h + (("&" if "?" in h else "?") + "key=" + urllib.parse.quote(key) if key else "")

    def watch_sources(self):
        return [dict(s, handle=self.route_url(s["handle"])) for s in Connector.watch_sources(self) if not REFUSED_ROUTES.search(s["handle"] if s["handle"].startswith("/") else "/" + s["handle"])]

    def verify(self, sources: list[dict]) -> list[dict]:
        rows = []
        for s in sources:
            try:
                rows.append(dict(s, handle=self.route_url(s["handle"])))
            except HttpError as e:
                self.store.set_source_status(s["id"], "refused", str(e)[:200])
        return Rss.verify(self, rows)


@register
class WechatMp(Connector):
    platform = "wechat_mp"
    label = "WeChat Official Accounts (public message albums; RSSHub bridge optional)"
    region = "cn"
    route_class = "bridge"
    new_in = "2.0"
    reads = "an Official Account's public message album (mp.weixin.qq.com/mp/appmsgalbum, JSON), directly or through the operator's RSSHub"
    refuses = "reader-side mirrors (sogou, wxnmh, feeddd), comments, subscribers, anything needing a WeChat login"
    probe_url = "https://mp.weixin.qq.com/"

    def _split(self, handle: str) -> tuple[str, str]:
        h = handle.strip()
        m = re.search(r"__biz=([^&#]+).*?album_id=(\d+)", h)
        if m:
            return urllib.parse.unquote(m.group(1)), m.group(2)
        if "/" in h:
            biz, aid = h.split("/", 1)
            return biz, aid
        raise HttpError(400, "handle must be <__biz>/<album_id> or the album URL")

    def album(self, biz: str, aid: str) -> list[dict]:
        rh = (self.all.get("rsshub") or {})
        if rh.get("base_url") and not any(d in str(rh["base_url"]) for d in DEMO_HOSTS):
            url = str(rh["base_url"]).rstrip("/") + f"/wechat/mp/msgalbum/{urllib.parse.quote(biz, safe='')}/{aid}"
            try:
                body, _, _ = http_request(url, timeout=40, retries=1)
                _, items = parse_feed(body)
                if items:
                    return [{"id": it["guid"], "ts": it["ts"], "title": it["title"], "text": clean_text(it["body"]), "url": it["link"], "cover": ""} for it in items]
            except (HttpError, Exception):
                pass
        body, _, final = http_request(ALBUM, params={"action": "getalbum", "__biz": biz, "album_id": aid, "f": "json", "count": 20}, browser=True, timeout=30, retries=1,
                                      headers={"Referer": "https://mp.weixin.qq.com/", "Accept": "application/json"})
        if self.closed_by_login(final, body):
            raise RouteClosed(f"wechat asked for a login at {final}")
        try:
            js = json.loads(body.decode("utf-8", "replace"))
        except ValueError:
            head = body[:200].decode("utf-8", "replace")
            if "verify" in head.lower() or "<html" in head.lower():
                raise RouteClosed("wechat answered the album with a verification page") from None
            raise HttpError(400, "album did not answer with JSON") from None
        ret = ((js.get("base_resp") or {}).get("ret")) if isinstance(js, dict) else None
        if ret not in (None, 0):
            raise HttpError(400, f"album error {ret}: {(js.get('base_resp') or {}).get('err_msg', '')}")
        return parse_album(js)

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                biz, aid = self._split(s["handle"])
                items = self.album(biz, aid)
                last = max([i["ts"] or 0 for i in items] or [0]) or None
                st = "live" if items else "empty"
                note = f"{len(items)} articles in the album"
                self.store.set_source_status(s["id"], st, note, last_post_ts=last)
                res.append({"id": s["id"], "status": st, "note": note})
            except (HttpError, RouteClosed) as e:
                st = "closed" if isinstance(e, RouteClosed) else ("unreachable" if e.status == 0 else "error")
                self.store.set_source_status(s["id"], st, str(e)[:200]); res.append({"id": s["id"], "status": st, "note": str(e)[:200]})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            biz, aid = self._split(src["handle"])
            n, newest = 0, None
            for it in self.album(biz, aid):
                newest = max(newest or 0, it["ts"] or 0)
                if self.emit(src, str(it["id"]), it["ts"], it["text"], url=it["url"], title=it["title"]):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)
