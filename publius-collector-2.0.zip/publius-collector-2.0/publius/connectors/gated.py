"""Connectors that work once the operator holds platform-granted access. Each is complete and read-only; each states
the access condition in `ready()`.

  meta         Facebook Page public content (Page Public Content Access feature, app review) and Instagram Business
               Discovery (your own IG business account can read public metadata of other business/creator accounts)
  threads      Threads API keyword search (threads_keyword_search permission) — breakout lane
  tiktok       Research API — approved academic / not-for-profit researchers only (TikTok's eligibility rules)
  vk           VK API wall.get with a service token (Russian state media publish there)
  rutube       Rutube public JSON (keyless)
  telegram_user  Telethon user session: reads broadcast channels whose web preview is disabled; forwards are attributed
               only to other public channels, never to a person
  discord      bot token; reads announcement channels of the servers the operator invited the bot to, and the public
               member counts of watchlisted invite links (a keyless endpoint). Chat channels are refused.
  eitaa        Eitaa (Iran's state-promoted messenger) public channel pages; usually unreachable from US IP space
"""
from __future__ import annotations

import os
import re
import time
from typing import Optional

from ..util import HttpError, clean_text, http_get, http_get_json, http_post_form, now, parse_count, parse_iso, sha1
from .base import Connector, SearchResult, Stats, register

GRAPH = "https://graph.facebook.com/v21.0/"


@register
class Facebook(Connector):
    platform = "facebook"
    label = "Facebook Pages (Graph API, Page Public Content Access)"
    requires = ("access_token",)
    route_class = "gated"
    reads = "posts of watchlisted state Pages through the Graph API, once Meta grants Page Public Content Access"
    refuses = "profiles, groups, comments, anything read as a logged-in person"
    probe_url = "https://graph.facebook.com/v21.0/"
    probe_any_status = True

    def __init__(self, section, cfg, store):
        super().__init__(cfg.get("meta", {}), cfg, store)

    def enabled(self) -> bool:
        return bool(self.cfg.get("enabled"))

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        tok = self.cfg["access_token"]

        def one(src: dict):
            r = http_get_json(GRAPH + f"{src['handle']}/posts", params={"access_token": tok, "fields": "id,message,created_time,permalink_url,attachments{type,url},shares", "limit": 25})
            n, newest = 0, None
            for p in r.get("data") or []:
                ts = parse_iso(p.get("created_time", "")) or now()
                newest = max(newest or 0, ts)
                att = ((p.get("attachments") or {}).get("data") or [{}])[0]
                media = {"video": 1} if "video" in str(att.get("type", "")) else ({"photo": 1} if att else {})
                if self.emit(src, p["id"], ts, p.get("message", ""), url=p.get("permalink_url", ""), media=media, metrics={"shares": (p.get("shares") or {}).get("count")}, extra_urls=((att.get("url"),) if att.get("url") else ())):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Instagram(Connector):
    platform = "instagram"
    label = "Instagram (Graph API Business Discovery)"
    requires = ("access_token", "ig_business_id")
    route_class = "gated"
    reads = "public media of watchlisted state business/creator accounts through Business Discovery"
    refuses = "personal accounts, stories, comments, followers"
    probe_url = "https://graph.facebook.com/v21.0/"
    probe_any_status = True

    def __init__(self, section, cfg, store):
        super().__init__(cfg.get("meta", {}), cfg, store)

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        tok, me = self.cfg["access_token"], self.cfg["ig_business_id"]

        def one(src: dict):
            fields = f"business_discovery.username({src['handle']}){{followers_count,media.limit(25){{id,caption,timestamp,permalink,media_type,like_count,comments_count}}}}"
            r = http_get_json(GRAPH + me, params={"fields": fields, "access_token": tok})
            bd = r.get("business_discovery") or {}
            if bd.get("followers_count"):
                self.store.set_source_status(src["id"], "live", "", followers=bd["followers_count"])
            n, newest = 0, None
            for m in (bd.get("media") or {}).get("data") or []:
                ts = parse_iso(m.get("timestamp", "")) or now()
                newest = max(newest or 0, ts)
                if self.emit(src, m["id"], ts, m.get("caption", ""), url=m.get("permalink", ""), media={"video": 1} if m.get("media_type") in ("VIDEO", "REELS") else {"photo": 1},
                             metrics={"likes": m.get("like_count"), "replies": m.get("comments_count")}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Threads(Connector):
    platform = "threads"
    label = "Threads (keyword search; breakout lane)"
    requires = ("access_token",)
    breakout_lane = True
    route_class = "gated"
    reads = "counts of public posts matching a phrase (keyword search, once the permission is granted)"
    refuses = "recording any poster below the public-figure threshold"
    probe_url = "https://graph.threads.net/v1.0/"
    probe_any_status = True

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        return Stats()

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        if kind == "url":
            return SearchResult("threads", ok=False, note="keyword search does not match URLs")
        params = {"q": query, "search_type": "RECENT", "fields": "id,text,timestamp,username", "access_token": self.cfg["access_token"], "limit": 100}
        if since:
            params["since"] = int(since)
        r = http_get_json("https://graph.threads.net/v1.0/keyword_search", params=params)
        data = r.get("data") or []
        from .social import _vm
        return SearchResult("threads", count=len(data), violent_or_mobilising=_vm(d.get("text", "") for d in data), note=f"{kind}:{query[:60]}")


@register
class TikTokResearch(Connector):
    platform = "tiktok"
    label = "TikTok Research API (approved researchers only)"
    requires = ("client_key", "client_secret")
    breakout_lane = True
    route_class = "gated"
    reads = "videos of watchlisted state accounts and US-region keyword counts through the Research API"
    refuses = "the consumer app's routes, comments, viewers"
    probe_url = "https://open.tiktokapis.com/v2/oauth/token/"
    probe_any_status = True

    def _token(self) -> str:
        tok = getattr(self, "_tok", None)
        if tok and tok[1] > time.time():
            return tok[0]
        r = http_post_form("https://open.tiktokapis.com/v2/oauth/token/", {"client_key": self.cfg["client_key"], "client_secret": self.cfg["client_secret"], "grant_type": "client_credentials"})
        self._tok = (r["access_token"], time.time() + int(r.get("expires_in", 7200)) - 60)
        return self._tok[0]

    def _query(self, cond: dict, days: int = 7) -> list[dict]:
        from ..util import http_post_json
        end = time.strftime("%Y%m%d", time.gmtime()); start = time.strftime("%Y%m%d", time.gmtime(time.time() - days * 86400))
        r = http_post_json("https://open.tiktokapis.com/v2/research/video/query/?fields=id,video_description,create_time,username,view_count,like_count,share_count,comment_count",
                           {"query": cond, "start_date": start, "end_date": end, "max_count": 100}, headers={"Authorization": f"Bearer {self._token()}"})
        return ((r.get("data") or {}).get("videos")) or []

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            vids = self._query({"and": [{"operation": "EQ", "field_name": "username", "field_values": [src["handle"]]}]})
            n, newest = 0, None
            for v in vids:
                ts = int(v.get("create_time") or now()); newest = max(newest or 0, ts)
                if self.emit(src, str(v["id"]), ts, v.get("video_description", ""), url=f"https://www.tiktok.com/@{src['handle']}/video/{v['id']}", media={"video": 1},
                             metrics={"views": v.get("view_count"), "likes": v.get("like_count"), "shares": v.get("share_count"), "replies": v.get("comment_count")}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)

    def search(self, query: str, kind: str = "phrase", since: Optional[int] = None) -> SearchResult:
        if kind == "url":
            return SearchResult("tiktok", ok=False, note="keyword search does not match URLs")
        vids = self._query({"and": [{"operation": "IN", "field_name": "keyword", "field_values": [query[:100]]}, {"operation": "EQ", "field_name": "region_code", "field_values": ["US"]}]})
        return SearchResult("tiktok", count=len(vids), reach_max=max([int(v.get("view_count") or 0) for v in vids] or [0]) or None, note=f"{kind}:{query[:60]}")


@register
class VK(Connector):
    platform = "vk"
    label = "VK (wall.get, service token)"
    requires = ("service_token",)
    region = "ru"
    route_class = "key"
    reads = "the walls of watchlisted state-media communities (wall.get with a service token)"
    refuses = "users' walls, friends, members, messages"
    probe_url = "https://api.vk.com/method/wall.get?v=5.199"
    probe_any_status = True

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        tok = self.cfg["service_token"]

        def one(src: dict):
            r = http_get_json("https://api.vk.com/method/wall.get", params={"domain": src["handle"], "count": 50, "access_token": tok, "v": "5.199"})
            if r.get("error"):
                raise HttpError(400, r["error"].get("error_msg", "vk error"))
            n, newest = 0, None
            for p in (r.get("response") or {}).get("items") or []:
                ts = int(p.get("date") or now()); newest = max(newest or 0, ts)
                links = tuple(a["link"]["url"] for a in p.get("attachments") or [] if a.get("type") == "link")
                media = {"video": 1} if any(a.get("type") == "video" for a in p.get("attachments") or []) else ({"photo": 1} if any(a.get("type") == "photo" for a in p.get("attachments") or []) else {})
                if self.emit(src, str(p["id"]), ts, p.get("text", ""), url=f"https://vk.com/wall{p.get('owner_id')}_{p['id']}", media=media,
                             metrics={"views": (p.get("views") or {}).get("count"), "likes": (p.get("likes") or {}).get("count"), "shares": (p.get("reposts") or {}).get("count")}, extra_urls=links):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class Rutube(Connector):
    platform = "rutube"
    label = "Rutube (public JSON)"
    region = "ru"
    reads = "videos of watchlisted state channels (public person/video JSON)"
    refuses = "comments, viewers"
    probe_url = "https://rutube.ru/api/video/person/23489467/?page=1"

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            r = http_get_json(f"https://rutube.ru/api/video/person/{src['handle']}/", params={"page": 1})
            n, newest = 0, None
            for v in r.get("results") or []:
                ts = parse_iso(v.get("publication_ts") or v.get("created_ts") or "") or now(); newest = max(newest or 0, ts)
                if self.emit(src, v["id"], ts, v.get("description", ""), url=v.get("video_url", ""), title=v.get("title", ""), media={"video": 1}, metrics={"views": v.get("hits")}):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)


@register
class TelegramUser(Connector):
    platform = "telegram_user"
    label = "Telegram (user session via Telethon)"
    requires = ("api_id", "api_hash")
    route_class = "key"
    reads = "posts of watchlisted broadcast channels whose public preview is disabled; forwards attributed only to other public channels"
    refuses = "groups (their members' conversation), users, discovery of channels the watchlist does not name, any forward that names a person"

    def __init__(self, section, cfg, store):
        super().__init__(cfg.get("telegram", {}), cfg, store)

    def watch_sources(self) -> list[dict]:
        # only channels whose public preview is unavailable; the web connector covers the rest for free
        return [s for s in self.store.sources(platform="telegram", enabled_only=True) if s.get("status") in ("no_preview",)]

    def client(self):
        from telethon import TelegramClient  # optional dependency
        return TelegramClient(os.path.join(self.all["general"]["data_dir"], self.cfg.get("session", "publius_user")), int(self.cfg["api_id"]), str(self.cfg["api_hash"]))

    async def login(self) -> None:
        c = self.client(); await c.start(); await c.disconnect()

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        import asyncio
        return asyncio.run(self._collect(max_sources))

    async def _collect(self, max_sources):
        st = Stats()
        c = self.client(); await c.connect()
        try:
            if not await c.is_user_authorized():
                st.errors.append("Telegram session not authorised: run `python -m publius login telegram`"); return st
            srcs = self.watch_sources()[: max_sources or None]
            from telethon.tl.types import Channel, PeerChannel
            fwd_cache: dict = {}

            async def fwd_channel(m) -> str:
                """The public username of the channel a post was forwarded from; anything else (a user, a private channel) is ''."""
                fh = getattr(m, "fwd_from", None)
                fid = getattr(fh, "from_id", None) if fh else None
                if not isinstance(fid, PeerChannel):
                    return ""
                cid = int(fid.channel_id)
                if cid not in fwd_cache:
                    try:
                        e = await c.get_entity(fid)
                        fwd_cache[cid] = e.username if isinstance(e, Channel) and getattr(e, "broadcast", False) and getattr(e, "username", None) else ""
                    except Exception:
                        fwd_cache[cid] = ""
                return fwd_cache[cid]

            for s in srcs:
                st.sources += 1
                try:
                    ent = await c.get_entity(s["handle"])
                    if not (isinstance(ent, Channel) and getattr(ent, "broadcast", False)):
                        raise ValueError("refused: not a broadcast channel (a group is its members' conversation)")
                    msgs = await c.get_messages(ent, limit=int(self.cfg.get("max_messages_per_channel", 100)), min_id=int(s.get("cursor") or 0))
                    n, newest, top = 0, None, int(s.get("cursor") or 0)
                    for m in msgs:
                        top = max(top, m.id)
                        if not m.message:
                            continue
                        ts = int(m.date.timestamp()); newest = max(newest or 0, ts)
                        urls = tuple(e.url for e in (m.entities or []) if getattr(e, "url", None))
                        fwd = await fwd_channel(m) if getattr(m, "fwd_from", None) else ""
                        if self.emit(dict(s, id=s["id"]), str(m.id), ts, m.message, url=f"https://t.me/{s['handle']}/{m.id}", media={"video": 1} if m.video else ({"photo": 1} if m.photo else {}),
                                     metrics={"views": getattr(m, "views", None), "shares": getattr(m, "forwards", None)}, fwd_from=fwd, extra_urls=urls):
                            n += 1
                    try:
                        full = await c.get_participants(ent, limit=0)
                        subs = getattr(full, "total", None)
                    except Exception:
                        subs = None
                    if subs:
                        self.store.set_source_status(s["id"], s.get("status") or "no_preview", s.get("status_note") or "", followers=int(subs))
                    self.store.source_ok(s["id"], str(top), n, newest); st.items += n
                except Exception as e:
                    self.store.source_error(s["id"], str(e)); st.errors.append(f"{s['handle']}: {e}")
        finally:
            await c.disconnect()
        return st


DISCORD = "https://discord.com/api/v10"
ANNOUNCEMENT = 5          # GUILD_ANNOUNCEMENT: an outlet's or office's broadcast channel
FORUM_REFUSED = {0: "text chat", 2: "voice", 4: "category", 10: "thread", 11: "thread", 12: "private thread", 13: "stage", 15: "forum", 16: "media"}


def parse_discord_messages(rows: list, channel_id: str, guild_id: str = "@me") -> list[dict]:
    """Messages of an announcement channel: content plus embed titles/descriptions, attachment kinds, reaction totals,
    link URLs. The author field is read only to tell a webhook or bot post from a person's; nothing about the author is kept."""
    out = []
    for m in rows if isinstance(rows, list) else []:
        if not isinstance(m, dict) or not m.get("id"):
            continue
        parts = [m.get("content") or ""]
        urls = []
        for e in m.get("embeds") or []:
            if not isinstance(e, dict):
                continue
            for k in ("title", "description"):
                if e.get(k):
                    parts.append(str(e[k]))
            if e.get("url"):
                urls.append(e["url"])
        media = {}
        for a in m.get("attachments") or []:
            ct = str((a or {}).get("content_type") or "")
            kind = "video" if ct.startswith("video") else ("photo" if ct.startswith("image") else "file")
            media[kind] = media.get(kind, 0) + 1
        reacts = sum(int((r or {}).get("count") or 0) for r in m.get("reactions") or [])
        out.append({"id": str(m["id"]), "ts": parse_iso(m.get("timestamp") or "") or now(), "text": "\n".join(p for p in parts if p), "urls": urls, "media": media,
                    "metrics": {"likes": reacts or None}, "url": f"https://discord.com/channels/{guild_id}/{channel_id}/{m['id']}", "pinned": bool(m.get("pinned"))})
    return out


def parse_invite(js: dict) -> dict:
    g = (js or {}).get("guild") or {}
    return {"guild": g.get("name") or "", "guild_id": str(g.get("id") or ""), "members": js.get("approximate_member_count"), "online": js.get("approximate_presence_count"),
            "channel": ((js.get("channel") or {}).get("name") or ""), "expires": js.get("expires_at")}


@register
class DiscordBot(Connector):
    """Discord has no documented state influence operation on it (Ed. 2026.09e finding); the lane exists so that claim can
    be tested rather than assumed. It reads two things. (1) Announcement channels (type 5) that the watchlist names by
    channel id, in servers the operator has invited the bot to: where an outlet or office broadcasts. A chat channel,
    thread, forum or voice channel is its members' conversation and is refused even when listed. (2) The public member
    counts behind watchlisted invite links (GET /invites/{code}?with_counts=true, no token needed): how large a server
    is, never who is in it. It never joins a server on its own, never adds sources, never reads members."""
    platform = "discord"
    label = "Discord (bot; announcement channels of invited servers; invite counts)"
    requires = ()                     # invite counts need no token; channel reads check for one per source
    route_class = "key"
    reads = "announcement channels named by the watchlist (messages, embeds, attachment kinds, reaction totals) in servers the operator invited the bot to; public member counts of watchlisted invites"
    refuses = "chat channels, threads, forums, DMs, member lists, joining servers, adding sources; anything about a member"
    probe_url = DISCORD + "/invites/discord-developers?with_counts=true"

    def _hdr(self) -> dict:
        if not str(self.cfg.get("token", "")).strip():
            raise HttpError(401, "missing discord.token: channel reads need a bot token (invite counts do not)")
        return {"Authorization": f"Bot {self.cfg['token']}", "Accept": "application/json"}

    def _get(self, path: str, params: Optional[dict] = None, auth: bool = True):
        for attempt in range(4):
            try:
                return http_get_json(DISCORD + path, headers=self._hdr() if auth else {"Accept": "application/json"}, params=params, timeout=30)
            except HttpError as e:
                if e.status == 429 and attempt < 3:
                    try:
                        import json as _j
                        wait = float((_j.loads(e.body.decode("utf-8", "replace") or "{}") or {}).get("retry_after") or e.retry_after or 2.0)
                    except Exception:
                        wait = float(e.retry_after or 2.0)
                    time.sleep(min(60.0, wait + 0.5))
                    continue
                raise
        raise HttpError(429, "discord: rate limited after retries")

    def invite(self, code: str) -> dict:
        return parse_invite(self._get(f"/invites/{code.split('/')[-1]}", params={"with_counts": "true"}, auth=False))

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            h = s["handle"].strip()
            try:
                if h.startswith("invite:") or "discord.gg/" in h or "discord.com/invite/" in h:
                    inv = self.invite(h.split(":", 1)[-1])
                    note = f"{inv['guild']}: {inv['members'] or 0:,} members, {inv['online'] or 0:,} online"
                    self.store.set_source_status(s["id"], "live", note, followers=inv["members"], name=inv["guild"] or None)
                    res.append({"id": s["id"], "status": "live", "note": note, "followers": inv["members"]}); continue
                ch = self._get(f"/channels/{h}")
                t = int(ch.get("type", -1))
                if t != ANNOUNCEMENT:
                    note = f"refused: channel type {t} ({FORUM_REFUSED.get(t, 'not an announcement channel')}) is its members' conversation"
                    self.store.set_source_status(s["id"], "refused", note); res.append({"id": s["id"], "status": "refused", "note": note}); continue
                note = f"announcement channel #{ch.get('name', '')} in guild {ch.get('guild_id', '')}"
                self.store.set_source_status(s["id"], "live", note, name=ch.get("name") or None)
                res.append({"id": s["id"], "status": "live", "note": note})
            except HttpError as e:
                st = "not_found" if e.status in (403, 404, 10003, 50001) else ("unreachable" if e.status == 0 else "error")
                note = ("the bot is not in that server or the channel does not exist (invite the bot with Read Messages / View Channel only)" if st == "not_found" else str(e)[:200])
                self.store.set_source_status(s["id"], st, note); res.append({"id": s["id"], "status": st, "note": note})
        return res

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            h = src["handle"].strip()
            if h.startswith("invite:") or "discord.gg/" in h or "discord.com/invite/" in h:
                inv = self.invite(h.split(":", 1)[-1])
                self.store.set_source_status(src["id"], "live", f"{inv['guild']}: {inv['members'] or 0:,} members, {inv['online'] or 0:,} online", followers=inv["members"], name=inv["guild"] or None)
                return 0, None
            ch = self._get(f"/channels/{h}")
            t = int(ch.get("type", -1))
            if t != ANNOUNCEMENT:
                raise HttpError(403, f"refused: channel type {t} ({FORUM_REFUSED.get(t, 'not an announcement channel')}) is its members' conversation")
            params = {"limit": 100}
            if src.get("cursor"):
                params["after"] = src["cursor"]
            rows = self._get(f"/channels/{h}/messages", params=params)
            n, newest, top = 0, None, int(src.get("cursor") or 0)
            for m in parse_discord_messages(rows, h, str(ch.get("guild_id") or "@me")):
                top = max(top, int(m["id"]))
                if not (m["text"] or m["media"]):
                    continue
                newest = max(newest or 0, m["ts"])
                if self.emit(src, m["id"], m["ts"], m["text"], url=m["url"], media=m["media"], metrics=m["metrics"], extra_urls=tuple(m["urls"])):
                    n += 1
            return n, newest, top or None
        return self.run_sources(one, max_sources)


@register
class Eitaa(Connector):
    platform = "eitaa"
    label = "Eitaa (Iranian messenger, public pages)"
    region = "ir"
    reads = "public channel pages of watchlisted state outlets (text, links, dates, subscriber count)"
    refuses = "groups, users, anything behind the client's login"
    probe_url = "https://eitaa.com/"

    def verify(self, sources: list[dict]) -> list[dict]:
        res = []
        for s in sources:
            try:
                page = http_get(f"https://eitaa.com/{s['handle']}", browser=True, timeout=20).decode("utf-8", "replace")
                m = re.search(r'etme_channel_info_counter[^>]*>\s*<span class="counter_value">([^<]+)</span>', page)
                subs = parse_count(m.group(1)) if m else None
                posts = re.findall(r'data-post="[^/]+/(\d+)"', page)
                st = "live" if posts else ("empty" if subs else "not_found")
                note = f"{len(posts)} posts visible" + (f"; {subs:,} subscribers" if subs else "")
                self.store.set_source_status(s["id"], st, note, followers=subs)
                res.append({"id": s["id"], "status": st, "note": note, "followers": subs})
            except HttpError as e:
                st = "unreachable" if e.status == 0 else "error"
                note = (str(e)[:120] + " — eitaa.com usually refuses US IP space") if st == "unreachable" else str(e)[:200]
                self.store.set_source_status(s["id"], st, note); res.append({"id": s["id"], "status": st, "note": note})
        return res

    def watch_sources(self) -> list[dict]:
        return [s for s in super().watch_sources() if s.get("status") != "unreachable"]

    def collect(self, max_sources: Optional[int] = None) -> Stats:
        def one(src: dict):
            page = http_get(f"https://eitaa.com/{src['handle']}", browser=True, timeout=20).decode("utf-8", "replace")
            m = re.search(r'etme_channel_info_counter[^>]*>\s*<span class="counter_value">([^<]+)</span>', page)
            if m and parse_count(m.group(1)):
                self.store.set_source_status(src["id"], "live", src.get("status_note") or "", followers=parse_count(m.group(1)))
            n, newest = 0, None
            for mid, body, when in re.findall(r'data-post="[^/]+/(\d+)".*?<div class="etme_widget_message_text[^"]*"[^>]*>(.*?)</div>.*?<time datetime="([^"]+)"', page, re.S):
                ts = parse_iso(when) or now(); newest = max(newest or 0, ts)
                if self.emit(src, mid, ts, body, url=f"https://eitaa.com/{src['handle']}/{mid}"):
                    n += 1
            return n, newest
        return self.run_sources(one, max_sources)
