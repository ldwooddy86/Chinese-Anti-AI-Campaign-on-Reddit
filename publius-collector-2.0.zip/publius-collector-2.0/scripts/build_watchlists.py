#!/usr/bin/env python3
"""Normalise the published Hamilton 2.0 account list and the curated aggregator tier into watchlists/*.json.

  python scripts/build_watchlists.py            (reads scripts/hamilton_accounts_raw.json)

Inputs
  hamilton_accounts_raw.json  rows parsed from securingdemocracy.org/hamilton-monitored-accounts-on-twitter/ (ASD, list dated Nov 2023)
Outputs
  watchlists/hamilton_base.json   1 entity per row, per-platform handles, category gov|media, kind institution|person, tier overt
  watchlists/aggregators.json     state-aligned aggregators, laundering networks and domestic-aggregator lanes, each with evidence refs
"""
from __future__ import annotations

import json
import os
import re
import urllib.parse


def _jload(path, encoding="utf-8"):
    with open(path, encoding=encoding) as f:
        return json.load(f)


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CC = {"Russia": "RU", "China": "CN", "Iran": "IR"}
PLAT = {"Twitter ID": "x", "Facebook ID": "facebook", "YouTube ID": "youtube", "Instagram ID": "instagram", "Rumble ID": "rumble", "Telegram ID": "telegram"}
INSTITUTION_RX = re.compile(
    r"(embass|consul|ministr|mission|minist|ambassad|office|government|kremlin|president|parliament|council|agency|news|press|tv\b|television|radio|channel|"
    r"daily|times|review|network|media|service|centre|center|institute|foundation|university|official|spokes|mfa|irna|isna|mehr|tasnim|fars|sputnik|\brt\b|rt |cgtn|cctv|"
    r"xinhua|global times|people.s daily|china daily|xinhuanet|tass|ria|izvestia|lenta|inosmi|ruptly|redfish|in the now|inthenow|prime|moscow 24|rossiya|vesti|"
    r"hispantv|press tv|presstv|al.?alam|al.?kawthar|iribnews|irib|tehran|kayhan|khamenei|leader|shanghai|beijing|guangming|ecns|china news|voice|live|update|"
    r"magazine|journal|world|online|club|forum|culture|history|society|chamber|duma|armed forces|army|navy|defen|security|command|federation|republic|state|"
    r"show|declassified|stream|tone|paper|moments|global|visual|latino|today|files|house|people|speaks|insight|mundo|discover|real|nexo|shabestan|pc chinese)",
    re.I)


def clean_handle(platform: str, v: str) -> str:
    v = (v or "").strip()
    if not v or v.lower() in ("parody account", "n/a", "-"):
        return ""
    v = v.split("\n")[0].strip()
    if platform == "telegram":
        v = re.sub(r"^(https?://)?t\.me/", "", v)
        v = re.sub(r"^s/", "", v).strip("/@ ")
    if platform == "facebook":
        v = urllib.parse.unquote(v)
    if platform == "x" and " " in v:
        return ""        # two rows carry display names instead of handles
    if platform == "youtube":
        v = v.replace("–", "-").replace("—", "-")
    return v.strip()


def hamilton_entities(raw: list[dict]) -> list[dict]:
    out, n = [], {"RU": 0, "CN": 0, "IR": 0}
    for r in raw:
        cc = CC.get(r.get("Category", ""))
        if not cc:
            continue
        n[cc] += 1
        handles = {}
        for col, plat in PLAT.items():
            h = clean_handle(plat, r.get(col, ""))
            if h:
                handles[plat] = h
        if not handles:
            continue
        name = r["Name"].strip()
        cat = "gov" if r.get("Account Type", "").lower().startswith("diplomatic") else "media"
        kind = "institution" if (INSTITUTION_RX.search(name) or re.match(r"(?i)^(russ|chin|iran|росс|rus |ch |ir )", name)) else "person"
        person = kind == "person"
        note = ""
        if person and cat == "media":
            note = ("Individual Hamilton listed as a state-media personality in Nov 2023. Off by default: current affiliation is unverified and the list "
                    "includes US persons. Enable after re-verifying employment with the outlet.")
        elif person:
            note = "Official listed by Hamilton in Nov 2023; office held now is unverified. Collected, but hidden from the Unrest Watch until re-verified."
        out.append({"id": f"ham-{cc.lower()}-{n[cc]:04d}", "name": name, "country": cc, "category": cat, "kind": kind, "tier": "overt", "grade": "A2",
                    "handles": handles, "affil_verified": not person, "enabled": not (person and cat == "media"),
                    "provenance": "Hamilton 2.0 published account list (ASD/GMF, list dated Nov 2023)", "evidence": ["HAM-LIST", "HAM-METH"], "note": note})
    return out


# ------------------------------------------------------------------------------------------------------------ aggregator tier
# Each enabled row rests on independently published evidence of state linkage (a government finding, a joint government
# report, or a named research report). Being named as an upstream by the Pravda network is NOT evidence: rows whose only
# basis would be that, or whose cited research was not verified for this build, are kept as disabled candidates
# ("evidence pending") so they show on the Watchlist tab but are never collected or scored until an analyst adds a source.
# Each row: documented state linkage or documented amplification by state accounts. Grades are NATO Admiralty for the ATTRIBUTION
# (reliability of the attributing source x credibility of the claim), not for the content. Telegram handles are live-verified by `publius verify`.
AGGREGATORS = [
    # ---------------------------------------------------------------- Russia: laundering / aggregator networks
    {"id": "agg-ru-pravda-usa", "name": "Pravda network — USA edition (Portal Kombat)", "country": "RU", "category": "aggregator", "kind": "network", "tier": "aligned", "grade": "A2",
     "handles": {"rss": "https://usa.news-pravda.com/rss.xml"}, "evidence": ["VIGINUM-PK", "ASP-PRAVDA", "NG-PRAVDA", "DFRLAB-PRAVDA-2026", "PRAVDA-UPSTREAM"],
     "note": "Automated aggregator that republishes Russian state media and pro-Kremlin Telegram channels into ~90 country subdomains; each item names its upstream source, which PUBLIUS records as provenance."},
    {"id": "agg-ru-pravda-en", "name": "Pravda network — English hub", "country": "RU", "category": "aggregator", "kind": "network", "tier": "aligned", "grade": "A2",
     "handles": {"rss": "https://news-pravda.com/rss.xml"}, "evidence": ["VIGINUM-PK", "ASP-PRAVDA"], "note": "Hub of the same network; multilingual."},
    {"id": "agg-ru-pravda-uk", "name": "Pravda network — UK edition", "country": "RU", "category": "aggregator", "kind": "network", "tier": "aligned", "grade": "A2",
     "handles": {"rss": "https://uk.news-pravda.com/rss.xml"}, "evidence": ["VIGINUM-PK", "ASP-PRAVDA"], "note": "English-language sibling; items often cross-post to the USA edition."},
    {"id": "agg-ru-pravda-ca", "name": "Pravda network — Canada edition", "country": "RU", "category": "aggregator", "kind": "network", "tier": "aligned", "grade": "A2",
     "handles": {"rss": "https://canada.news-pravda.com/rss.xml"}, "evidence": ["VIGINUM-PK", "ASP-PRAVDA"], "note": "English-language sibling."},
    # ---------------------------------------------------------------- Russia: Telegram aggregators with documented state linkage or state amplification
    {"id": "agg-ru-rybar", "name": "Rybar", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "A2",
     "handles": {"telegram": "rybar", "x": "rybar_force"}, "evidence": ["RFJ-RYBAR"], "note": "US Rewards for Justice (Oct 2024) described Rybar as a Rostec-funded propaganda operation engaged in US election interference."},
    {"id": "agg-ru-rybar-en", "name": "Rybar in English", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "A2",
     "handles": {"telegram": "rybar_in_english"}, "evidence": ["RFJ-RYBAR"], "note": "English service of the same operation."},
    {"id": "agg-ru-rybar-mena", "name": "Rybar MENA", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "A2",
     "handles": {"telegram": "rybar_mena"}, "evidence": ["RFJ-RYBAR", "PRAVDA-UPSTREAM"], "note": "Regional service; laundered into Pravda-USA."},
    {"id": "agg-ru-intelslava", "enabled": False, "status_note": "candidate: evidence pending", "name": "Intel Slava Z", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B3",
     "handles": {"telegram": "intelslava"}, "evidence": ["PRAVDA-UPSTREAM", "DFRLAB-TG"], "note": "High-reach English-language pro-Kremlin war aggregator; an upstream of the Pravda network. No public state-ownership finding."},
    {"id": "agg-ru-geoprime", "enabled": False, "status_note": "candidate: evidence pending", "name": "Geopolitics Prime", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "C3",
     "handles": {"telegram": "geopolitics_prime"}, "evidence": ["PRAVDA-UPSTREAM"], "note": "English aggregator; recurrent Pravda-USA upstream. Attribution rests on laundering pattern only."},
    {"id": "agg-ru-infodefense", "enabled": False, "status_note": "candidate: evidence pending", "name": "InfoDefense (English)", "country": "RU", "category": "aggregator", "kind": "network", "tier": "aligned", "grade": "B2",
     "handles": {"telegram": "infodefenseen"}, "evidence": ["DFRLAB-TG"], "note": "Multilingual Telegram network redistributing Russian state narratives to foreign audiences."},
    {"id": "agg-ru-african-initiative", "name": "African Initiative (English)", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B2",
     "handles": {"telegram": "africaninitiativeen"}, "evidence": ["AFRICAN-INITIATIVE", "PRAVDA-UPSTREAM"], "note": "Russian state-linked news agency; laundered into Pravda-USA."},
    {"id": "agg-ru-tsargrad", "name": "Tsargrad TV", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B3",
     "handles": {"telegram": "tsargradtv"}, "evidence": ["OFAC-MALOFEEV"], "note": "Owned by Konstantin Malofeev, sanctioned by the US since 2014 and indicted by DOJ in 2022 for sanctions evasion. State-aligned ownership, not state ownership: graded accordingly."},
    {"id": "agg-ru-izvestia", "enabled": False, "status_note": "candidate: evidence pending", "name": "Izvestia", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B2",
     "handles": {"telegram": "izvestia"}, "evidence": ["PRAVDA-UPSTREAM"], "note": "Kremlin-aligned daily (National Media Group); heavy Pravda-USA upstream."},
    {"id": "agg-ru-dvamajors", "enabled": False, "status_note": "candidate: evidence pending", "name": "Two Majors", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "C3",
     "handles": {"telegram": "dva_majors"}, "evidence": ["PRAVDA-UPSTREAM"], "note": "Milblogger aggregator; Pravda-USA upstream."},
    {"id": "agg-ru-rusvesna", "enabled": False, "status_note": "candidate: evidence pending", "name": "Russian Spring war correspondents", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "C3",
     "handles": {"telegram": "rvvoenkor"}, "evidence": ["PRAVDA-UPSTREAM"], "note": "Milblogger aggregator; Pravda-USA upstream."},
    {"id": "agg-ru-colonelcassad", "enabled": False, "status_note": "candidate: evidence pending", "name": "Colonelcassad (Boris Rozhin)", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "C3",
     "handles": {"telegram": "boris_rozhin"}, "evidence": ["DFRLAB-TG"], "note": "Large pro-Kremlin aggregator; frequently re-used by state media."},
    {"id": "agg-ru-readovka", "enabled": False, "status_note": "candidate: evidence pending", "name": "Readovka", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "C3",
     "handles": {"telegram": "readovkanews"}, "evidence": ["DFRLAB-TG"], "note": "High-reach Russian-language aggregator."},
    {"id": "agg-ru-southfront", "name": "SouthFront (English)", "country": "RU", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "A2",
     "handles": {"telegram": "southfronteng", "rss": "https://southfront.press/feed/"}, "evidence": ["HAM-METH", "GEC-PILLARS"], "note": "Named by the US State Department (GEC, 2020) as part of Russia's disinformation ecosystem; Hamilton tracks its website."},
    # ---------------------------------------------------------------- China
    {"id": "agg-cn-hotlist-baidu", "name": "Baidu realtime hot list (US-topic filter)", "country": "CN", "category": "domestic_aggregator", "kind": "board", "tier": "overt", "grade": "A1",
     "handles": {"cn_hotlist": "baidu"}, "evidence": ["CN-HOTLIST"], "note": "China's largest search trending board; PUBLIUS keeps only entries about the United States. A domestic-agenda signal, not a US-audience channel."},
    {"id": "agg-cn-hotlist-weibo", "name": "Weibo hot search (US-topic filter)", "country": "CN", "category": "domestic_aggregator", "kind": "board", "tier": "overt", "grade": "A1",
     "handles": {"cn_hotlist": "weibo"}, "evidence": ["CN-HOTLIST"], "enabled": False, "note": "Refused since 1.1: the hot-search endpoint needs a logged-in cookie, and PUBLIUS never reads behind a login. Kept so the refusal is on the record."},
    {"id": "agg-cn-hotlist-toutiao", "name": "Toutiao hot board (US-topic filter)", "country": "CN", "category": "domestic_aggregator", "kind": "board", "tier": "overt", "grade": "A1",
     "handles": {"cn_hotlist": "toutiao"}, "evidence": ["CN-HOTLIST"], "note": "ByteDance news aggregator trending board."},
    # ---------------------------------------------------------------- Iran and axis
    {"id": "agg-ir-sabereen", "name": "Sabereen News", "country": "IR", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B3",
     "handles": {"telegram": "sabreenS1"}, "evidence": ["ISW-IRAN"], "enabled": False, "status_note": "candidate: live handle unconfirmed", "note": "Iraqi 'axis of resistance' aggregator aligned with IRGC-backed militias. The handle on record resolved to a 19-subscriber page on 24 Sep 2026: disabled until the live handle is confirmed."},
    {"id": "agg-ir-almayadeen", "enabled": False, "status_note": "candidate: evidence pending", "name": "Al Mayadeen English", "country": "IR", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B3",
     "handles": {"telegram": "AlMayadeenEnglish"}, "evidence": ["ISW-IRAN"], "note": "Beirut-based, Iran-aligned outlet; English service targets Western audiences. Its website sits behind a bot challenge, so the Telegram channel is the lane."},
    {"id": "agg-ir-explosive", "name": "Explosive Media (Lego AI videos)", "country": "IR", "category": "aggregator", "kind": "institution", "tier": "aligned", "grade": "B2",
     "handles": {"x": "ExplosiveMediaa"}, "evidence": ["RF-IRAN-AI"], "note": "A representative told the BBC the Iranian regime is a 'customer'; Tasnim redistributes its videos in near real time."},
]

# Known covert operations: no stable handles. Used as indicator sets (hashtags, domains, phrases) and in the Brief.
OPERATIONS = [
    {"id": "op-matryoshka", "name": "Matryoshka / Operation Overload", "country": "RU", "status": "active against the 2026 midterms", "grade": "B2",
     "indicators": {"hashtags": ["alldemocratsarecriminals"], "phrases": ["not cnn content", "cameo"], "impersonated_brands": ["CNN", "BBC", "New York Times"]},
     "summary": "Voice-cloned celebrity deepfakes branded with newsroom logos attacking Democrats in battleground Senate races, amplified by inauthentic accounts on X and Bluesky (Sep 2026).",
     "evidence": ["AFP-MATRYOSHKA", "NYT-RU-CHAOS"]},
    {"id": "op-portal-kombat", "name": "Portal Kombat / Pravda network", "country": "RU", "status": "active", "grade": "A2",
     "indicators": {"domains": ["news-pravda.com"]}, "summary": "Aggregator network laundering state media and Telegram content at very high volume; documented to seed AI chatbot answers.",
     "evidence": ["VIGINUM-PK", "ASP-PRAVDA", "NG-PRAVDA"]},
    {"id": "op-sda", "name": "Social Design Agency (Doppelganger)", "country": "RU", "status": "active (sanctioned)", "grade": "A2",
     "indicators": {}, "summary": "State-controlled PR firm; hijacked Bluesky accounts to push fake stories (2026) and organised false-flag vandalism in Europe to incite unrest.",
     "evidence": ["BRENNAN-2026"]},
    {"id": "op-ai-agents-cn", "name": "PRC autonomous AI-agent campaign", "country": "CN", "status": "disclosed Sep 2026", "grade": "B2",
     "indicators": {}, "summary": "Government-backed; Chinese open-source models driving agents that created and ran fake personas on Instagram, Facebook and TikTok.",
     "evidence": ["NYT-AI-AGENTS"]},
    {"id": "op-ai-agents-ir", "name": "Iranian autonomous AI-agent campaign", "country": "IR", "status": "disclosed Sep 2026", "grade": "B2",
     "indicators": {}, "summary": "Government-backed; same pattern as the PRC campaign, unsophisticated but end-to-end automated.",
     "evidence": ["NYT-AI-AGENTS"]},
    {"id": "op-storm-2035", "name": "Storm-2035", "country": "IR", "status": "active after early-2026 takedown", "grade": "B2",
     "indicators": {}, "summary": "Creator/amplifier persona network on Instagram, X and Bluesky; pivoted within 24 h of 28 Feb 2026 from divisive Western politics to pro-regime war content.",
     "evidence": ["RF-IRAN-AI"]},
    {"id": "op-brics4clicks", "name": "BRICS4CLICKS and Verified4War (X)", "country": "IR", "status": "active; handles rotate", "grade": "B3",
     "indicators": {}, "summary": "Two ~20-account pro-Iran X networks posing as global news outlets; >1 billion views in the war's first month; content shared by Iranian embassies and a Russian diplomat.",
     "evidence": ["ISD-IRAN-1B"]},
    {"id": "op-us-casualty", "name": "US-casualty AI video network", "country": "IR", "status": "reported 2026", "grade": "B3",
     "indicators": {"phrases": ["military funeral", "flag-draped"]}, "summary": "47 inauthentic accounts, >40 million views of AI-generated US military funerals and distressed soldiers, aimed at pressure to end the war.",
     "evidence": ["RF-IRAN-AI"]},
]


def main() -> None:
    raw = _jload(os.path.join(HERE, "hamilton_accounts_raw.json"))
    ents = hamilton_entities(raw)
    os.makedirs(os.path.join(ROOT, "watchlists"), exist_ok=True)
    meta = {"source": "https://securingdemocracy.org/hamilton-monitored-accounts-on-twitter/", "list_date": "2023-11", "parsed": "2026-09-24",
            "note": "Overt accounts only, as published by ASD. Individuals are flagged affil_verified=false until re-verified."}
    with open(os.path.join(ROOT, "watchlists", "hamilton_base.json"), "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "entities": ents}, f, ensure_ascii=False, indent=1)
    with open(os.path.join(ROOT, "watchlists", "aggregators.json"), "w", encoding="utf-8") as f:
        json.dump({"meta": {"curated": "2026-09-24", "grading": "NATO Admiralty applied to the attribution, not the content"}, "entities": AGGREGATORS, "operations": OPERATIONS},
                  f, ensure_ascii=False, indent=1)
    from collections import Counter
    c = Counter((e["country"], e["category"], e["kind"]) for e in ents)
    print(len(ents), "Hamilton entities;", sum(len(e["handles"]) for e in ents), "platform handles")
    for k, v in sorted(c.items()):
        print(" ", k, v)
    print(len(AGGREGATORS), "aggregator-tier entities;", len(OPERATIONS), "operations")


if __name__ == "__main__":
    main()
