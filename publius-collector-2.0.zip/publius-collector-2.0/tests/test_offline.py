"""Offline test suite: no network, no accounts.  python tests/test_offline.py"""
from __future__ import annotations

import json
import math
import os
import sys
import tempfile
import threading
import time
import unittest
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from publius import util  # noqa: E402
from publius.analysis import breakout as bo  # noqa: E402
from publius.analysis import coordination as co  # noqa: E402
from publius.analysis import features as fx  # noqa: E402
from publius.analysis import trends as tr  # noqa: E402
from publius.analysis.model import LEVELS, Model, icd203, logistic  # noqa: E402
from publius.connectors.base import SearchResult  # noqa: E402
from publius.connectors.rss import parse_feed  # noqa: E402
from publius.connectors.telegram_web import parse_preview  # noqa: E402
from publius.store import Post, Store  # noqa: E402

TG_FIXTURE = """<meta property="og:title" content="Example Channel">
<div class="tgme_channel_info_counter"><span class="counter_value">93.1K</span> <span class="counter_type">subscribers</span></div>
<div class="tgme_widget_message_wrap js-widget_message_wrap"><div class="tgme_widget_message js-widget_message" data-post="example/101">
<div class="tgme_widget_message_forwarded_from accent_color">Forwarded from <a class="tgme_widget_message_forwarded_from_name" href="https://t.me/upstreamchan/55"><span dir="auto">Upstream</span></a></div>
<a class="tgme_widget_message_video_player js-message_video_player" href="https://t.me/example/101"></a>
<div class="tgme_widget_message_text js-message_text" dir="auto">Americans must take to the streets in <b>Austin</b> after the ICE shooting. <a href="https://www.rt.com/usa/1234-ice/?utm_source=tg">rt.com</a></div>
<div class="tgme_widget_message_reactions js-message_reactions"><span class="tgme_reaction"><i class="emoji"><b>x</b></i>36</span><span class="tgme_reaction"><i class="emoji"><b>y</b></i>1.2K</span></div><div class="tgme_widget_message_footer compact js-message_footer">
<span class="tgme_widget_message_views">12.5K</span><span class="copyonly"> views</span><a class="tgme_widget_message_date" href="https://t.me/example/101"><time datetime="2026-09-24T19:22:52+00:00" class="time">19:22</time></a>
</div></div></div>
<div class="tgme_widget_message_wrap js-widget_message_wrap"><div class="tgme_widget_message js-widget_message" data-post="example/102">
<div class="tgme_widget_message_text js-message_text" dir="auto">Weather in Moscow.</div><div class="tgme_widget_message_footer"><span class="tgme_widget_message_views">900</span>
<a class="tgme_widget_message_date" href="https://t.me/example/102"><time datetime="2026-09-24T20:00:00+00:00" class="time">20:00</time></a></div></div></div>"""

RSS_FIXTURE = b"""<?xml version="1.0"?><rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:media="http://search.yahoo.com/mrss/"><channel><title>Pravda USA</title>
<item><title>Senate rejects war powers resolution</title><link>https://usa.news-pravda.com/world/2026/09/24/1.html</link><guid>g1</guid>
<pubDate>Thu, 24 Sep 2026 18:00:55 -0400</pubDate><enclosure url="https://x/img.jpg" type="image/jpeg"/>
<content:encoded><![CDATA[<p>49 senators supported it.</p><p><a href="https://t.me/SGTnewsNetwork">source</a> <a href="https://max.ru/mir_tass">Subscribe</a> <a href="https://t.me/addlist/abc">folder</a></p>]]></content:encoded></item>
</channel></rss>"""


class TestUtil(unittest.TestCase):
    def test_canonical_url(self):
        self.assertEqual(util.canonical_url("https://www.RT.com/usa/1234-ice/?utm_source=tg&id=5#x"), "https://rt.com/usa/1234-ice?id=5")
        self.assertEqual(util.canonical_url("https://youtu.be/abc123"), "https://youtube.com/watch?v=abc123")
        self.assertEqual(util.canonical_url("https://t.me/s/intelslava/"), "https://t.me/intelslava")

    def test_entities_and_lang(self):
        e = util.extract_entities("Watch #AllDemocratsAreCriminals from @rt_com https://www.rt.com/x?utm_medium=a")
        self.assertIn("alldemocratsarecriminals", e["hashtags"]); self.assertIn("rt_com", e["mentions"]); self.assertEqual(e["domains"], ["rt.com"])
        self.assertEqual(util.guess_lang("Протесты в США продолжаются"), "ru")
        self.assertEqual(util.guess_lang("美国的抗议活动仍在继续"), "zh")
        self.assertEqual(util.guess_lang("اعتراضات در آمریکا ادامه دارد"), "fa")
        self.assertEqual(util.guess_lang("Protests continue across the United States today"), "en")

    def test_counts_and_times(self):
        self.assertEqual(util.parse_count("93.1K"), 93100); self.assertEqual(util.parse_count("1.2M"), 1200000); self.assertEqual(util.parse_count("2 501 402"), 2501402)
        self.assertEqual(util.parse_iso("2026-09-24T19:22:52+00:00"), 1790277772)
        self.assertEqual(util.parse_iso("Thu, 24 Sep 2026 18:00:55 -0400"), 1790287255)


class TestParsers(unittest.TestCase):
    def test_telegram_preview(self):
        d = parse_preview(TG_FIXTURE, "example")
        self.assertEqual(d["title"], "Example Channel"); self.assertEqual(d["subscribers"], 93100)
        m = d["messages"][0]
        self.assertEqual(m["id"], 101); self.assertEqual(m["views"], 12500); self.assertEqual(m["reactions"], 1236)
        self.assertEqual(m["fwd"], "upstreamchan"); self.assertIn("video", m["media"])
        self.assertTrue(any("rt.com/usa/1234-ice" in u for u in m["urls"]))
        self.assertIn("take to the streets", m["text"])

    def test_rss_upstream(self):
        title, items = parse_feed(RSS_FIXTURE)
        self.assertEqual(title, "Pravda USA")
        self.assertEqual(items[0]["upstream"], ["mir_tass", "sgtnewsnetwork"])
        self.assertEqual(items[0]["media"], {"photo": 1})


def _post(text, lang="en", ts=None, platform="telegram", category="media", **kw):
    d = {"id": util.sha1(text, ts), "text": text, "title": "", "lang": lang, "ts": ts or int(time.time()), "platform": platform, "category": category, "hashtags": [], "media": {}}
    d.update(kw)
    return d


class TestFeaturesAndSeverity(unittest.TestCase):
    def test_ladder(self):
        now = int(time.time())
        s0 = fx.extract(_post("Russia and China sign an energy agreement in Beijing.", ts=now))
        s1 = fx.extract(_post("Democrats and Republicans are tearing America apart over immigration.", ts=now))
        s2 = fx.extract(_post("The US midterm elections are rigged, a sham election run by a corrupt regime.", ts=now))
        s3 = fx.extract(_post("Americans must take to the streets and shut it down after the ICE raids in Austin.", ts=now))
        s4 = fx.extract(_post("Civil war is coming to America and the ICE agents deserve to die.", ts=now))
        self.assertEqual([s0["severity"], s1["severity"], s2["severity"], s3["severity"], s4["severity"]], [0, 1, 2, 3, 4])
        self.assertIn("N02", s2["narratives"])
        self.assertIn("FP-02", s3["flashpoints"])

    def test_abbreviation_does_not_split_sentence(self):
        self.assertEqual(fx.extract(_post("The U.S. elections are rigged, a sham run by a corrupt regime."))["severity"], 2)

    def test_russian_native(self):
        f = fx.extract(_post("В США началась гражданская война: протесты и беспорядки в Техасе", lang="ru"))
        self.assertTrue(f["us"]); self.assertIn("N01", f["narratives"])

    def test_report_is_not_a_call(self):
        f = fx.extract(_post("Protesters marched in Austin after the ICE shooting, police said."))
        self.assertLess(f["severity"], 3)

    def test_currency_is_not_a_us_subject(self):
        from publius.analysis.lexicon import match_all
        self.assertIsNone(match_all("Diesel topped 100 Turkish liras (2.05 U.S. dollars) per liter", "en").get("us_anchor"))
        self.assertIsNone(match_all("Цена достигла 5 долларов США за баррель", "ru").get("us_anchor"))
        self.assertTrue(match_all("Власти США заявили", "ru").get("us_anchor"))
        self.assertTrue(match_all("US troops in Syria", "en").get("us_anchor"))

    def test_georgia_disambiguation(self):
        from publius.analysis.gazetteer import countries_in
        self.assertNotIn("Georgia", countries_in("Georgia's governor Kemp said Atlanta voters would decide"))
        self.assertIn("Georgia", countries_in("Tbilisi protests continue in Georgia"))


class TestModel(unittest.TestCase):
    def setUp(self):
        self.m = Model()
        self.base = {k: 0.0 for k in self.m.names}

    def test_reference_post_lift_is_one(self):
        pr = self.m.predict(self.base)
        self.assertAlmostEqual(pr["levels"][3]["p"], self.m.ref_p3, places=12)
        self.assertAlmostEqual(self.m.score(self.base, 1, {})["rr"], 1.0, places=6)
        self.assertGreater(pr["levels"][3]["p"], logistic(-self.m.theta[3]))   # parameter uncertainty pulls a rare event toward 0.5

    def test_monotone_and_ordered(self):
        risky = dict(self.base, us_domestic=1, outgroup_n=3, moral_emotional_n=5, flashpoint=1, echo=math.log1p(4), cross_country=1, velocity_z=2)
        p0, p1 = self.m.predict(self.base), self.m.predict(risky)
        self.assertGreater(p1["levels"][3]["p"], p0["levels"][3]["p"])
        ps = [p1["levels"][k]["p"] for k in LEVELS]
        self.assertEqual(ps, sorted(ps, reverse=True))
        for k in LEVELS:
            self.assertLessEqual(p1["levels"][k]["lo"], p1["levels"][k]["p"]); self.assertGreaterEqual(p1["levels"][k]["hi"], p1["levels"][k]["p"])

    def test_flags_and_cap(self):
        cfg = {"model": {"alert_p3": 0.2, "alert_min_severity": 3, "watch_rr": 2.0, "watch_min_severity": 3, "s2_watch_rr": 5.0}}
        hot = dict(self.base, us_domestic=1, outgroup_n=3, flashpoint=1, echo=2.0, cross_country=1, velocity_z=4, early_pickup=2.0, platform_reach=0.6)
        self.assertEqual(self.m.score(hot, 3, cfg)["flag"], "ALERT")
        capped = self.m.score(hot, 3, cfg, affil_verified=False)
        self.assertEqual(capped["flag"], "WATCH"); self.assertTrue(capped["capped_unverified"])
        self.assertEqual(self.m.score(self.base, 1, cfg)["flag"], "")
        self.assertEqual(self.m.score(self.base, 4, cfg)["flag"], "WATCH")

    def test_icd203(self):
        self.assertEqual(icd203(0.02), "almost no chance"); self.assertEqual(icd203(0.5), "roughly even chance"); self.assertEqual(icd203(0.97), "almost certain")


class TestCalibration(unittest.TestCase):
    def test_recovery(self):
        import numpy as np
        from publius.analysis.calibrate import calibrate
        rng = np.random.default_rng(3)
        m = Model()
        truth = dict(m.beta); truth["flashpoint"] = 1.5
        th = {2: 1.6, 3: 3.2, 4: 4.6, 5: 6.0, 6: 7.9}
        rows = []
        for i in range(2500):
            x = {k: 0.0 for k in m.names}
            x["us_domestic"] = float(rng.random() < 0.3); x["flashpoint"] = float(rng.random() < 0.2); x["velocity_z"] = float(np.clip(rng.normal(), -2, 4))
            x["lang_en"] = 0.0 if rng.random() < 0.7 else -1.0; x["log_followers"] = float(rng.normal())
            eta = sum(truth[k] * x[k] for k in m.names); u = rng.random(); y = 1
            for k in LEVELS:
                if u < logistic(eta - th[k]):
                    y = k
            rows.append({"x": x, "y": y, "w": 1.0, "ts": i})
        res = calibrate(rows)
        self.assertEqual(res["status"], "ok")
        self.assertLess(abs(res["params"]["beta"]["flashpoint"] - 1.5), 0.35)
        self.assertLessEqual(res["backtest"]["b3"]["fitted"]["ece"], res["backtest"]["b3"]["prior"]["ece"] + 0.02)

    def test_weights_and_full_covariance(self):
        import numpy as np
        from publius.analysis.calibrate import fit, kish
        w = np.array([1.0] * 50 + [20.0] * 10)
        k = kish(w)
        self.assertAlmostEqual(float(k.sum()), float(w.sum()) ** 2 / float((w * w).sum()), places=6)
        rng = np.random.default_rng(5); m = Model()
        X = np.zeros((400, len(m.names))); X[:, m.names.index("us_domestic")] = rng.random(400) < 0.4
        y = np.where(rng.random(400) < 0.15, 3, 1)
        par = fit(X, y, np.ones(400), m.names, m.prior)
        mm = Model({**par, "version": "t"})
        pr = mm.predict({"us_domestic": 1.0})["levels"][3]
        self.assertTrue(0 < pr["lo"] < pr["p"] < pr["hi"] < 1)
        self.assertEqual(len(par["cov_full"]), len(m.names) + 5)

    def test_insufficient(self):
        from publius.analysis.calibrate import calibrate
        self.assertEqual(calibrate([{"x": {"us_domestic": 1.0}, "y": 1, "w": 1, "ts": 0}])["status"], "insufficient")


class TestCoordinationTrends(unittest.TestCase):
    def test_clusters_and_cls(self):
        t0 = 1_790_000_000
        posts = []
        for i, (src, cc) in enumerate([("a", "RU"), ("b", "RU"), ("c", "IR")]):
            posts.append({"id": f"p{i}", "source_id": src, "country": cc, "platform": "telegram", "ts": t0 + i * 30, "urls": ["https://rt.com/usa/1"], "text": "x", "title": ""})
        long = "The United States is sliding toward civil war as protests spread from Austin to Memphis and the federal government deploys troops"
        posts.append({"id": "q1", "source_id": "d", "country": "CN", "platform": "rss", "ts": t0, "urls": [], "text": long, "title": ""})
        posts.append({"id": "q2", "source_id": "e", "country": "RU", "platform": "telegram", "ts": t0 + 600, "urls": [], "text": long + " today", "title": ""})
        cm = co.clusters(posts)
        self.assertEqual(cm["p0"], cm["p2"]); self.assertEqual(cm["q1"], cm["q2"]); self.assertNotEqual(cm["p0"], cm["q1"])
        d = co.diffusion_features(posts, cm)
        self.assertEqual(d["p0"]["echo_sources"], 2); self.assertEqual(d["p0"]["cross_country"], 1.0)
        shares = []
        for k in range(4):
            shares += [{"id": f"s{k}a", "source_id": "x1", "ts": t0 + k * 5000, "urls": [f"https://ex.com/{k}"]}, {"id": f"s{k}b", "source_id": "x2", "ts": t0 + k * 5000 + 20, "urls": [f"https://ex.com/{k}"]},
                       {"id": f"s{k}c", "source_id": "x3", "ts": t0 + k * 5000 + 2500, "urls": [f"https://ex.com/{k}"]}]
        r = co.coordinated_link_sharing(shares, min_repeats=3)
        self.assertTrue(any({e["a"], e["b"]} == {"x1", "x2"} for e in r["edges"]))
        self.assertFalse(any("x3" in (e["a"], e["b"]) for e in r["edges"]))

    def test_signature_links_and_footers_do_not_chain(self):
        t0 = 1_790_000_000
        footer = "Support the channel: https://qr.nspk.ru/AS1000 | Subscribe @chan"
        posts = [{"id": f"s{i}", "source_id": "chan", "country": "RU", "platform": "telegram", "ts": t0 + i * 3600,
                  "urls": ["https://qr.nspk.ru/AS1000", "https://max.ru/chan", "https://example.org/promo"],
                  "text": f"Story number {i} about topic {i * 7} with its own distinct wording and facts {i * 13}\n{footer}", "title": ""} for i in range(6)]
        self.assertEqual(len(set(co.clusters(posts).values())), 6)
        self.assertTrue(co.is_signature("https://x.com/rt_com")); self.assertFalse(co.is_signature("https://x.com/rt_com/status/1"))
        self.assertTrue(co.is_signature("https://rt.com/")); self.assertFalse(co.is_signature("https://vk.com/wall-1_2"))
        self.assertFalse(co.is_signature("https://rumble.com/v4abc-some-title.html"))

    def test_echo_counts_direct_neighbours_only(self):
        t0 = 1_790_000_000
        chain = [{"id": "a1", "source_id": "A", "country": "RU", "platform": "telegram", "ts": t0, "urls": ["https://ex.org/story/1"], "text": "", "title": ""},
                 {"id": "b1", "source_id": "B", "country": "CN", "platform": "rss", "ts": t0 + 60, "urls": ["https://ex.org/story/1", "https://ex.org/story/2"], "text": "", "title": ""},
                 {"id": "c1", "source_id": "C", "country": "IR", "platform": "x", "ts": t0 + 120, "urls": ["https://ex.org/story/2"], "text": "", "title": ""}]
        g = co.link_graph(chain)
        cm = co.clusters(chain, graph=g)
        d = co.diffusion_features(chain, cm, graph=g)
        self.assertEqual(len(set(cm.values())), 1)
        self.assertEqual(d["a1"]["echo_sources"], 1); self.assertEqual(d["b1"]["echo_sources"], 2)
        self.assertEqual(d["a1"]["cluster_size"], 3)

    def test_fightin_words(self):
        cur = [{"text": "Memphis Task Force occupation continues", "lang": "en", "hashtags": []} for _ in range(12)] + [{"text": "Weather report", "lang": "en", "hashtags": []}] * 5
        base = [{"text": "Weather report today", "lang": "en", "hashtags": []}] * 40
        top = tr.fightin_words(cur, base, top=5)
        self.assertTrue(any("memphis" in t["term"].lower() for t in top[:3]))
        self.assertFalse(any(t["term"] == "memphis task" for t in top))   # bigram swallowed by the proper-noun phrase


class TestBreakout(unittest.TestCase):
    def test_level_ladder(self):
        cfg = {"model": {"breakout_min_pickups": 3}}
        self.assertEqual(bo.level({}, cfg)[0], 1)
        self.assertEqual(bo.level({"bluesky": {"count": 4}}, cfg)[0], 2)
        self.assertEqual(bo.level({"bluesky": {"count": 4}, "reddit": {"count": 3}}, cfg)[0], 3)
        self.assertEqual(bo.level({"gdelt": {"count": 1}}, cfg)[0], 1)      # one article is noise; two make a cross-medium breakout
        self.assertEqual(bo.level({"gdelt": {"count": 2}}, cfg)[0], 4)
        self.assertEqual(bo.level({"x": {"count": 9, "public_figures": ["@big"]}}, cfg)[0], 5)
        self.assertEqual(bo.level({"x": {"count": 9, "violent_or_mobilising": 3}}, cfg)[0], 6)

    def test_audit_deterministic(self):
        self.assertEqual(bo.audit_draw("abc", 0.05), bo.audit_draw("abc", 0.05))
        hits = sum(bo.audit_draw(f"id{i}", 0.05) for i in range(4000))
        self.assertTrue(120 < hits < 280)

    def test_run_checks_records_counts_only(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.upsert_source({"id": "telegram:x", "entity_id": "e", "platform": "telegram", "handle": "x", "name": "X", "country": "RU", "category": "media", "tier": "overt", "grade": "A2", "evidence": []})
            ts = int(time.time()) - 2 * 3600
            st.add_post(Post(id="p1", source_id="telegram:x", ts=ts, text="The midterm elections are rigged and Americans must rise up", urls=["https://rt.com/usa/9"], platform="telegram", country="RU"))
            st.add_post(Post(id="p2", source_id="telegram:x", ts=ts, text="Weather in Moscow", platform="telegram", country="RU"))
            st.update_analysis("p1", severity=3, rr=4.0, risk=10.0, features={"sel": {"selected": True, "p": 1.0, "why": "rule"}})
            st.update_analysis("p2", severity=0, rr=0.5, risk=0.0, features={"sel": {"selected": False, "p": 0.05, "why": "not selected"}})

            class Lane:
                def search(self, q, kind="url", since=None):
                    return SearchResult("bluesky", count=5, reach_max=250000, public_figures=["@famous"], violent_or_mobilising=0)
            r = bo.run_checks(st, {"bluesky": Lane()}, {"model": {"breakout_min_pickups": 3}})
            self.assertEqual(r["checked"], 1)
            obs = st.breakout_obs("p1")
            self.assertEqual(obs[0]["count"], 5); self.assertEqual(obs[0]["public_figures"], ["@famous"])
            self.assertEqual(set(obs[0].keys()) - {"post_id", "lane", "ts", "count", "reach_max", "public_figures", "violent_or_mobilising", "query", "note"}, set())
            self.assertEqual(st.post("p1")["breakout_level"], 5)
            self.assertEqual(st.breakout_obs("p2"), [])                       # unselected posts are never measured
            b = st.post("p1")["breakout"]
            self.assertEqual(b["checks"], 1); self.assertFalse(b["measurable"])   # one social lane cannot separate levels 2 and 3


class TestStoreServerExport(unittest.TestCase):
    def test_labels_precedence(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.set_label("p", 3, "analyst"); st.set_label("p", 1, "auto")
            self.assertEqual(st.labels()[0]["level"], 3)

    def test_watchlist_import_is_authoritative(self):
        from publius.watchlist import import_watchlists, source_id
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            import_watchlists(st, ROOT, ["aggregators"])
            cand = st.source(source_id("telegram", "intelslava"))
            self.assertEqual((cand["status"], cand["enabled"]), ("candidate", 0))
            st.upsert_source({"id": "telegram:old_channel", "entity_id": "x", "platform": "telegram", "handle": "old_channel", "name": "Old", "country": "RU", "category": "media"})
            st.add_post(Post(id="old1", source_id="telegram:old_channel", ts=int(time.time()), text="x", platform="telegram", country="RU", category="media"))
            st.add_post(Post(id="cand1", source_id=cand["id"], ts=int(time.time()), text="x", platform="telegram", country="RU", category="aggregator"))
            r = import_watchlists(st, ROOT, ["aggregators"])
            self.assertEqual(r["removed_sources"], 1); self.assertEqual(r["purged_posts"], 1)
            self.assertIsNone(st.post("old1")); self.assertIsNone(st.post("cand1"))
            self.assertTrue(all(s["enabled"] == 0 for s in st.sources() if s["status"] == "candidate"))

    def test_second_opinion_is_advisory(self):
        from publius import pipeline
        from publius.config import load
        from publius.watchlist import import_watchlists
        with tempfile.TemporaryDirectory() as d:
            cp = os.path.join(d, "c.toml")
            with open(cp, "w") as fh:
                fh.write(f'[general]\ndata_dir = "{d}/data"\n[server]\ntoken = "t"\n')
            cfg = load(cp)
            st = Store(cfg["general"]["data_dir"])
            import_watchlists(st, ROOT, ["aggregators"])
            src = [s for s in st.sources(platform="telegram") if s["enabled"]][0]
            st.add_post(Post(id="a1", source_id=src["id"], ts=int(time.time()) - 600, text="The Senate passed the budget bill after a long debate in Washington.",
                             platform="telegram", country=src["country"], category=src["category"], lang="en"))
            pipeline.analyse(cfg, st)
            rule = st.post("a1")["severity"]
            st.update_analysis("a1", llm={"severity": 4, "rule_severity": rule, "disagreement": True, "rationale": "test"})
            pipeline.analyse(cfg, st)
            self.assertEqual(st.post("a1")["severity"], rule)          # shown, never applied
            snap = pipeline.snapshot(cfg, st)
            self.assertTrue(snap["posts"]["a1"]["llm"]["disagree"])
            self.assertIn("observations", snap); self.assertIn("labels", snap)

    def test_exercise_runs_on_a_copy(self):
        from publius import exercise, pipeline
        from publius.config import load
        from publius.watchlist import import_watchlists
        with tempfile.TemporaryDirectory() as d:
            cp = os.path.join(d, "c.toml")
            with open(cp, "w") as fh:
                fh.write(f'[general]\ndata_dir = "{d}/data"\n[server]\ntoken = "t"\n')
            cfg = load(cp)
            st = Store(cfg["general"]["data_dir"])
            import_watchlists(st, ROOT, ["aggregators"])
            src = st.source("rss:https://usa.news-pravda.com/rss.xml")
            texts = ["Americans must take to the streets over the rigged midterm elections in Washington and Texas this week",
                     "The Senate vote on the Iran war powers resolution exposes a Congress that no longer answers to American voters",
                     "Federal agents at polling places in Chicago show the midterm elections are rigged against ordinary Americans"]
            for i, t in enumerate(texts):
                st.add_post(Post(id=f"e{i}", source_id=src["id"], ts=int(time.time()) - (3 + i) * 3600, text=t, url=f"https://usa.news-pravda.com/x/{i}",
                                 platform="rss", country="RU", category="aggregator", lang="en"))
            pipeline.analyse(cfg, st)
            res = exercise.run(cfg, os.path.join(d, "ex"), seed=7, log=lambda *a: None)
            self.assertGreaterEqual(res["exercise"]["counts"]["measured"], 1)
            self.assertEqual(st.conn().execute("SELECT COUNT(*) FROM breakout_obs").fetchone()[0], 0)     # the real store is untouched
            self.assertEqual(st.kv_get("exercise", ""), "")
            cp2 = Store(res["data_dir"])
            self.assertGreater(cp2.conn().execute("SELECT COUNT(*) FROM breakout_obs").fetchone()[0], 0)
            cfg2 = dict(cfg, general=dict(cfg["general"], data_dir=res["data_dir"]))
            snap = pipeline.snapshot(cfg2, cp2)
            self.assertTrue(snap["meta"]["exercise"]); self.assertTrue(any(l.get("simulated") for l in snap["lanes"]))
            pf = [x for obs in snap["observations"].values() for o in obs for x in o["pf"]]
            self.assertTrue(all(x.startswith("public figure #") and x.endswith("(sim)") for x in pf))  # never a real account

    def test_server_and_export(self):
        from publius import pipeline
        from publius.config import load
        from publius.export import static_html
        from publius.server import Server
        with tempfile.TemporaryDirectory() as d:
            cp = os.path.join(d, "config.toml")
            with open(cp, "w") as fh:
                fh.write(f'[general]\ndata_dir = "{d}/data"\n[server]\nport = 8791\ntoken = "tok"\n')
            cfg = load(cp)
            st = Store(cfg["general"]["data_dir"])
            from publius.watchlist import import_watchlists
            import_watchlists(st, ROOT, ["aggregators"])
            src = st.sources(platform="telegram")[0]
            st.add_post(Post(id="p1", source_id=src["id"], ts=int(time.time()) - 600, text="Americans must take to the streets over the rigged midterm elections </script><b>x</b>", platform="telegram", country=src["country"], category=src["category"], lang="en"))
            pipeline.analyse(cfg, st)
            snap = pipeline.snapshot(cfg, st)
            self.assertIn("p1", snap["posts"]); self.assertEqual(snap["posts"]["p1"]["sev"], 3)
            html = static_html(snap)
            self.assertNotIn("</script><b>", html.split('id="publius-snapshot">')[1].split("</script>")[0])
            self.assertEqual(snap["ghostloom"]["coverage"], "window")           # 1.1: the whole window is coded
            from publius.export import write
            res = write(snap, os.path.join(d, "exp"), html=False)
            with open(res["ghostloom"], encoding="utf-8") as fh:
                pk = json.load(fh)
            self.assertEqual((pk["kind"], pk["ghostloom"]["coverage"], pk["ghostloom"]["posts"]), ("publius-ghostloom-pack", "window", 1))
            srv = Server(cfg, st); srv.start()
            try:
                base = "http://127.0.0.1:8791"
                with urllib.request.urlopen(base + "/") as r:
                    self.assertIn(b"PUBLIUS", r.read())
                try:
                    urllib.request.urlopen(base + "/api/status"); self.fail("expected 401")
                except urllib.error.HTTPError as e:
                    self.assertEqual(e.code, 401)
                with urllib.request.urlopen(base + "/api/snapshot?k=tok") as r:
                    self.assertIn("p1", json.loads(r.read())["posts"])
                req = urllib.request.Request(base + "/api/label?k=tok", data=json.dumps({"post_id": "p1", "level": 4}).encode(), headers={"Origin": "https://evil.example"}, method="POST")
                try:
                    urllib.request.urlopen(req); self.fail("expected 403")
                except urllib.error.HTTPError as e:
                    self.assertEqual(e.code, 403)
                req = urllib.request.Request(base + "/api/label?k=tok", data=json.dumps({"post_id": "p1", "level": 4}).encode(), headers={"Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req) as r:
                    self.assertTrue(json.loads(r.read())["ok"])
                self.assertEqual(st.labels()[0]["level"], 4)
                for hdrs, url, body, code in [({}, "/api/status?k=wrong", None, 401), ({"Host": "rebind.example:8791"}, "/api/status?k=tok", None, 421),
                                              ({"Content-Type": "application/json"}, "/api/label?k=tok", b"[1,2]", 400), ({}, "/../config.toml", None, 404)]:
                    req = urllib.request.Request(base + url, data=body, headers=hdrs, method="POST" if body else "GET")
                    try:
                        urllib.request.urlopen(req); self.fail(f"expected {code} for {url}")
                    except urllib.error.HTTPError as e:
                        self.assertEqual(e.code, code, url)
            finally:
                srv.stop()
            cfg["server"]["token"] = ""
            srv2 = Server(cfg, st)
            self.assertTrue(srv2.generated_token and len(cfg["server"]["token"]) >= 24)
            srv2.httpd.server_close()

    def test_config_rails(self):
        from publius.config import load
        with tempfile.TemporaryDirectory() as d:
            cp = os.path.join(d, "c.toml")
            with open(cp, "w") as fh:
                fh.write('[server]\nhost = "0.0.0.0"\n')
            with self.assertRaises(SystemExit):
                load(cp)


class TestGhostLoomBridge(unittest.TestCase):
    """1.1: GHOST LOOM's eight anti-AI seams in four languages, the pack it loads, and the refusal rails."""

    def code(self, text):
        from publius.analysis.ghostloom import coder
        return coder().code("", text)

    def test_seams_multilingual(self):
        self.assertEqual(self.code("New data centers are pushing up electricity bills for residents in Virginia.")["seams"], ["DC"])
        self.assertEqual(self.code("From AI data centers to electric vehicles, copper and rare earths matter.")["seams"], [])
        self.assertIn("MIL", self.code("Российские войска нанесли удары по дата-центрам в Киеве.")["seams"])
        self.assertIn("MIL", self.code("Germany's Axel Springer awards Palantir founder Peter Thiel")["seams"])
        self.assertIn("TRUST", self.code("Australia says an OpenAI agent hacked into a government website.")["seams"])
        self.assertIn("DOOM", self.code("Amid talk of the dangers of uncontrolled development of advanced neural networks, the White House...")["seams"])
        self.assertIn("DOOM", self.code("На фоне обсуждения опасности бесконтрольного развития передовых нейросетей")["seams"])
        self.assertIn("BUB", self.code("美国人工智能泡沫正在破裂")["seams"])
        self.assertIn("ART", self.code("Нейросеть обвинили в плагиате: художники требуют защиты авторских прав")["seams"])
        self.assertTrue(self.code("رئیس‌جمهور درباره هوش مصنوعی و امنیت سخن گفت")["ai"])

    def test_gate_rejects_lookalikes(self):
        for t in ("ТВОЙ ГОЛОС — СИЛА РОССИИ", "J'ai vu le président hier.", "Il chargé d'affaires a.i. ha incontrato il ministro.",
                  "I found a brilliant chip shop in the North.", "ЦОДД начал тестировать светящиеся дороги", "Both sides used Iran as a bargaining chip.",
                  "Общий алгоритм выборов один и тот же", "искусство и культура России"):
            self.assertFalse(self.code(t)["ai"], t)
        self.assertEqual(self.code("Искусственный интеллект помогает врачам читать снимки")["seams"], [])   # 'искусственный' is not 'искусство'
        self.assertEqual(self.code("Искусственный интеллект и искусство: художники против плагиата")["seams"], ["ART"])

    def test_section_counts_all_lists_verified_only(self):
        from publius.analysis.ghostloom import section
        posts = [{"id": "a", "ts": 1790000000, "country": "RU", "lang": "en", "name": "Outlet", "title": "", "text": "Data centers drive up power bills", "sev_rule": "divisive framing"},
                 {"id": "b", "ts": 1790000000, "country": "IR", "lang": "fa", "name": "Unverified", "title": "", "text": "مراکز داده برق را می‌بلعند", "unverified": True},
                 {"id": "c", "ts": 1790000000, "country": "CN", "lang": "en", "name": "Other", "title": "", "text": "The weather in Beijing"}]
        s = section(posts, lambda p: bool(p.get("unverified")))
        self.assertEqual(s["posts"], 3)
        self.assertEqual(s["seams"]["DC"]["total"], 2)
        self.assertEqual([i["id"] for i in s["items"]], ["a"])
        self.assertEqual(s["unlisted_unverified"], 1)
        self.assertTrue(s["items"][0]["us"])

    def test_pack_leaves_out_simulation(self):
        from publius.analysis.ghostloom import bridge_pack
        snap = {"meta": {"version": "1.1.0", "exercise": {"seed": 1}, "model": {"version": "prior", "calibrated": True, "beta": []}},
                "posts": {"p": {"id": "p", "ts": 1790000000, "country": "RU", "lang": "en", "name": "RT", "title": "AI bubble", "text": "The AI bubble will burst", "sim": True, "p3": 0.9}},
                "lanes": [{"platform": "reddit", "label": "Reddit", "enabled": True, "breakout_ready": True, "simulated": True, "real_enabled": False, "real_ready": False, "real_why": "needs keys"}],
                "indicators": [{"op_id": "x", "lane": "reddit", "count": 9, "note": "simulated"}], "calibration": {"status": "ok"}, "labels": {"total": 3},
                "provenance": [{"aggregator": "rss:https://usa.news-pravda.com/rss.xml", "upstream": "chan_a", "items": 4, "watchlisted": True},
                               {"aggregator": "rss:https://usa.news-pravda.com/rss.xml", "upstream": "someone", "items": 2, "watchlisted": False},
                               {"aggregator": "rss:https://other.example/feed", "upstream": "elsewhere", "items": 9, "watchlisted": False}],
                "sources": [{"id": "rss:https://usa.news-pravda.com/rss.xml", "name": "Pravda USA", "status": "live", "enabled": True, "entity": "e1", "kind": "institution"}]}
        pk = bridge_pack(snap)
        self.assertTrue(pk["publius"]["exercise"])
        self.assertFalse(pk["model"]["calibrated"])
        self.assertEqual(pk["lanes"][0]["enabled"], False); self.assertFalse(pk["lanes"][0]["breakout_ready"])
        for k in ("indicators", "calibration", "labels", "observations", "posts", "spend"):
            self.assertNotIn(k, pk)
        self.assertNotIn("p3", json.dumps(pk["ghostloom"]))
        self.assertEqual([list(x) for x in pk["provenance"]["upstreams_watchlisted"]], [["chan_a", 4]])
        self.assertEqual(pk["provenance"]["upstreams_other"], {"channels": 1, "items": 2})     # Pravda editions only, as the brief counts
        self.assertEqual(dict((a, n) for a, n in pk["provenance"]["aggregators"])["Pravda USA"], 6)
        self.assertNotIn("someone", json.dumps(pk)); self.assertNotIn("elsewhere", json.dumps(pk))
        self.assertEqual(pk["ghostloom"]["seams"]["BUB"]["total"], 1)

    def test_weibo_is_refused(self):
        from publius.config import load
        from publius.connectors.news_boards import CnHotlist
        with tempfile.TemporaryDirectory() as d:
            cp = os.path.join(d, "c.toml")
            with open(cp, "w") as fh:
                fh.write(f'[general]\ndata_dir = "{d}/data"\n[cn_hotlist]\nboards = ["baidu", "weibo"]\nweibo_cookie = "SUB=abc"\n')
            import contextlib, io
            with contextlib.redirect_stderr(io.StringIO()):
                cfg = load(cp)
            self.assertEqual(cfg["cn_hotlist"]["boards"], ["baidu"]); self.assertNotIn("weibo_cookie", cfg["cn_hotlist"])
            with self.assertRaises(util.HttpError) as cm:
                CnHotlist({}, cfg, Store(cfg["general"]["data_dir"])).board("weibo")
            self.assertIn("refused", str(cm.exception))

    def test_discord_reads_announcement_channels_only(self):
        from publius.connectors import gated
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            st.upsert_source({"id": "discord:111", "entity_id": "e", "platform": "discord", "handle": "111", "name": "Chat", "country": "RU", "category": "media", "tier": "overt", "grade": "A2", "evidence": []})
            calls = []

            def fake(url, headers=None, params=None, **kw):
                calls.append(url)
                return {"type": 0} if url.endswith("/111") else [{"id": "1", "timestamp": "2026-09-24T10:00:00+00:00", "content": "hi"}]
            orig = gated.http_get_json
            gated.http_get_json = fake
            try:
                bot = gated.DiscordBot({"enabled": True, "token": "t"}, {"discord": {"enabled": True, "token": "t"}}, st)
                stats = bot.collect()
            finally:
                gated.http_get_json = orig
            self.assertEqual(stats.items, 0)
            self.assertTrue(any("refused" in e for e in stats.errors))
            self.assertFalse(any(u.endswith("/messages") for u in calls))


if __name__ == "__main__":
    unittest.main(verbosity=2)
