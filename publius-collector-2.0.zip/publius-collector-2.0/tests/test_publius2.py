"""Offline tests for the 2.0 lanes: parsers on fixtures, the rails, the probe record, the pack schema, the watchlists.
No network, no accounts.  python tests/test_publius2.py"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from publius import boards, config  # noqa: E402
from publius.connectors import base, bridges, breakout_extra, cn_platforms as cn, dprk, gated, ir_platforms as ir, ru_platforms as ru, telegram_bot  # noqa: E402
from publius.store import Store  # noqa: E402


class TestBase(unittest.TestCase):
    def test_registry_has_every_2_0_lane(self):
        import publius.pipeline  # noqa: F401  (imports every connector module)
        want = {"telegram", "telegram_user", "telegram_bot", "discord", "eitaa", "bale", "splus", "aparat", "virasty", "weibo", "bilibili", "zhihu", "douyin", "cn_hotlist",
                "wechat_mp", "rsshub", "rss", "vk", "ok", "rutube", "dzen", "max", "odysee", "dprk_web", "kcnawatch", "youtube", "x", "bluesky", "mastodon", "truthsocial",
                "gab", "reddit", "threads", "facebook", "instagram", "tiktok", "tumblr", "fourchan", "gdelt"}
        self.assertEqual(want - set(base.REGISTRY), set())
        for plat, cls in base.REGISTRY.items():
            self.assertIn(cls.region, ("global", "ru", "cn", "ir", "kp"), plat)
            self.assertIn(cls.route_class, ("open", "key", "paid", "gated", "bridge", "none", "refused"), plat)
            self.assertTrue(cls.reads, f"{plat} has no reads line")
            self.assertTrue(cls.refuses, f"{plat} has no refuses line")

    def test_closed_by_login(self):
        self.assertTrue(base.Connector.closed_by_login("https://passport.weibo.com/visitor/visitor?entry=miniblog", b""))
        self.assertTrue(base.Connector.closed_by_login("https://m.weibo.cn/u/1", "<html><body>请登录后查看</body></html>".encode("utf-8")))
        self.assertTrue(base.Connector.closed_by_login("https://dzen.ru/showcaptcha?x=1", b"<html>SmartCaptcha</html>"))
        self.assertTrue(base.Connector.closed_by_login("https://x.example/", b"<html>Sina Visitor System</html>"))
        self.assertFalse(base.Connector.closed_by_login("https://m.weibo.cn/api/container/getIndex?type=uid", b'{"ok":1,"data":{}}'))

    def test_meta(self):
        c = cn.Weibo({}, {}, None)
        m = c.meta()
        self.assertEqual(m["region"], "cn"); self.assertEqual(m["new_in"], "2.0"); self.assertTrue(m["probeable"])


class TestWeibo(unittest.TestCase):
    FEED = {"ok": 1, "data": {"cards": [
        {"card_type": 9, "mblog": {"id": "5100000001", "mid": "5100000001", "created_at": "Fri Sep 26 10:00:00 +0800 2026", "text": "美国国会<span class='url-icon'></span>再次未能通过预算案 <a href='https://weibo.com/x'>网页链接</a>",
                                   "reposts_count": 120, "comments_count": 45, "attitudes_count": 900, "pics": [{"pid": "a"}, {"pid": "b"}],
                                   "user": {"id": 2803301701, "screen_name": "人民日报", "followers_count": 160000000, "verified": True, "verified_reason": "人民日报法人微博"}}},
        {"card_type": 9, "mblog": {"id": "5100000002", "created_at": "3小时前", "text": "转发微博", "retweeted_status": {"id": "5000", "text": "原文", "user": {"id": 2656274875, "screen_name": "央视新闻"}, "page_info": {"type": "video", "page_url": "https://video.weibo.com/show?fid=1"}},
                                   "user": {"id": 2803301701, "screen_name": "人民日报"}}},
        {"card_type": 11, "mblog": None}]}}
    HOT = {"ok": 1, "data": {"hotgov": {"word": "#习近平会见外宾#", "num": 0, "url": "https://s.weibo.com/weibo?q=x", "is_gov": 1}, "hotgovs": [{"word": "#习近平会见外宾#", "pos": 1, "icon_desc": "热"}],
                             "realtime": [{"word": "美联储降息", "num": 4300000, "rank": 0, "realpos": 1, "label_name": "热", "word_scheme": "#美联储降息#"}, {"word": "秋分", "num": 3200000, "rank": 1, "realpos": 2}, {"word": "OpenAI新模型发布", "num": 2100000, "rank": 2, "realpos": 3, "icon_desc": "新"}]}}

    def test_feed(self):
        items = cn.parse_weibo_cards(self.FEED, ref=1790400000)
        self.assertEqual(len(items), 2)
        a = items[0]
        self.assertEqual(a["id"], "5100000001"); self.assertEqual(a["ts"], 1790388000)
        self.assertIn("美国国会", a["text"]); self.assertNotIn("<span", a["text"])
        self.assertEqual(a["media"], {"photo": 2}); self.assertEqual(a["metrics"]["likes"], 900)
        self.assertEqual(a["user"]["verified_reason"], "人民日报法人微博")
        b = items[1]
        self.assertEqual(b["ts"], 1790400000 - 3 * 3600); self.assertEqual(b["fwd_uid"], "2656274875"); self.assertEqual(b["media"], {"video": 1})
        self.assertEqual(b["urls"], ["https://video.weibo.com/show?fid=1"])

    def test_hot(self):
        e = cn.parse_weibo_hot(self.HOT)
        self.assertEqual(e[0]["rank"], 0); self.assertEqual(e[0]["label"], "置顶 热"); self.assertEqual(len(e), 4)
        self.assertEqual([x["title"] for x in e[1:]], ["美联储降息", "秋分", "OpenAI新模型发布"])
        self.assertEqual(e[1]["rank"], 1); self.assertEqual(e[1]["heat"], 4300000)
        self.assertTrue(cn.us_related("美联储降息")); self.assertFalse(cn.us_related("秋分")); self.assertTrue(cn.us_related("OpenAI新模型发布"))

    def test_times(self):
        self.assertEqual(cn.weibo_time("刚刚", 1000), 1000)
        self.assertEqual(cn.weibo_time("15分钟前", 10000), 10000 - 900)
        self.assertEqual(cn.weibo_time("2026-09-25 14:30"), 1790317800)
        self.assertIsNone(cn.weibo_time("nonsense"))


class TestBilibili(unittest.TestCase):
    def test_wbi_matches_the_documented_vectors(self):
        img, sub = "7cd084941338484aae1ad9425b84077c", "4932caff0ff746eab6f01bf08b70ac45"
        self.assertEqual(cn.wbi_mixin_key(img, sub), "ea1db124af3c7062474693fa704f4ff8")
        signed = cn.wbi_sign({"foo": "114", "bar": "514", "zab": 1919810}, img, sub, ts=1702204169)
        self.assertEqual(signed["w_rid"], "8f6f2b5b3d485fe1886cec6a0be8c5d4"); self.assertEqual(signed["wts"], "1702204169")
        self.assertEqual(cn.wbi_keys_from_nav({"code": -101, "data": {"wbi_img": {"img_url": f"https://i0.hdslb.com/bfs/wbi/{img}.png", "sub_url": f"https://i0.hdslb.com/bfs/wbi/{sub}.png"}}}), (img, sub))

    def test_uploads_popular_square_and_codes(self):
        up = cn.parse_bili_uploads({"list": {"vlist": [{"aid": 1, "bvid": "BV1xx411c7mD", "title": "美国政府停摆第三天", "description": "d", "created": 1790300000, "play": 50000, "comment": 120, "video_review": 300, "mid": 456664753, "author": "央视新闻"}]}})
        self.assertEqual(up[0]["url"], "https://www.bilibili.com/video/BV1xx411c7mD"); self.assertEqual(up[0]["metrics"]["views"], 50000)
        pop = cn.parse_bili_popular({"list": [{"bvid": "BV2", "title": "t", "desc": "d", "pubdate": 1, "stat": {"view": 9, "like": 2}, "owner": {"mid": 5, "name": "n"}}]})
        self.assertEqual(pop[0]["heat"], 9); self.assertEqual(pop[0]["rank"], 1)
        sq = cn.parse_bili_square({"trending": {"list": [{"keyword": "美国", "show_name": "美国大选", "heat_score": 77}]}})
        self.assertEqual(sq[0]["title"], "美国大选"); self.assertEqual(sq[0]["heat"], 77)
        with self.assertRaises(base.RouteClosed):
            cn.bili_check({"code": -352, "message": "风控校验失败"}, "uploads")
        with self.assertRaises(cn.HttpError) as e:
            cn.bili_check({"code": -412, "message": "请求被拦截"}, "uploads")
        self.assertEqual(e.exception.status, 429)
        self.assertEqual(cn.bili_check({"code": 0, "data": {"x": 1}}, "ok"), {"x": 1})


class TestZhihuDouyin(unittest.TestCase):
    def test_zhihu(self):
        hot = cn.parse_zhihu_hot({"data": [{"target": {"id": 1, "title": "如何看待美国政府再次停摆？", "excerpt": "e", "url": "https://api.zhihu.com/questions/1", "created": 1790300000}, "detail_text": "1234 万热度"},
                                          {"target": {"id": 2, "title": "秋天的第一杯奶茶", "url": "https://api.zhihu.com/questions/2"}, "detail_text": "12 万热度"}]})
        self.assertEqual(hot[0]["url"], "https://www.zhihu.com/question/1"); self.assertEqual(hot[0]["heat"], 12340000); self.assertEqual(hot[1]["rank"], 2)
        acts = cn.parse_zhihu_activities({"data": [
            {"verb": "ANSWER_CREATE", "created_time": 5, "target": {"type": "answer", "id": 9, "question": {"id": 1, "title": "Q?"}, "excerpt": "A", "voteup_count": 3, "comment_count": 1, "author": {"url_token": "huan-qiu-shi-bao"}}},
            {"verb": "ANSWER_VOTE_UP", "target": {"type": "answer", "id": 10, "excerpt": "someone else", "author": {"url_token": "some-user"}}},
            {"verb": "MEMBER_CREATE_ARTICLE", "target": {"type": "article", "id": 11, "title": "T", "excerpt": "B", "url": "https://api.zhihu.com/articles/11", "created": 6, "author": {"url_token": "huan-qiu-shi-bao"}}},
        ], }, "huan-qiu-shi-bao")
        self.assertEqual([a["kind"] for a in acts], ["answer", "article"])           # the upvote of someone else's answer is dropped
        self.assertEqual(acts[0]["url"], "https://www.zhihu.com/question/1/answer/9"); self.assertEqual(acts[1]["url"], "https://zhuanlan.zhihu.com/p/11")
        self.assertEqual(cn.zhihu_closed({}, 403)[:8], "HTTP 403"); self.assertIsNone(cn.zhihu_closed({"data": []}))

    def test_douyin(self):
        e = cn.parse_douyin_hot({"status_code": 0, "data": {"word_list": [{"word": "秋分", "hot_value": 9000000, "position": 2, "sentence_id": "b"}, {"word": "美国政府停摆", "hot_value": 12000000, "position": 1, "sentence_id": "a", "event_time": 1790300000}]}})
        self.assertEqual([x["rank"] for x in e], [1, 2]); self.assertEqual(e[0]["url"], "https://www.douyin.com/hot/a"); self.assertTrue(cn.us_related(e[0]["title"]))


class TestBoards(unittest.TestCase):
    def test_tracker_flags_an_early_drop(self):
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            r1 = boards.record(st, "weibo", [{"title": "A", "heat": 100, "rank": 1}, {"title": "B", "heat": 90, "rank": 2}, {"title": "C", "heat": 10, "rank": 30}], ts=1000)
            self.assertEqual(r1["dropped"], []); self.assertEqual(sorted(r1["new"]), ["A", "B", "C"])
            r2 = boards.record(st, "weibo", [{"title": "A", "heat": 110, "rank": 1}, {"title": "D", "heat": 80, "rank": 2}], ts=1000 + 1800)
            self.assertEqual([x["title"] for x in r2["dropped"]], ["B"])                 # high and hot at the previous read, gone now
            self.assertEqual(r2["dropped"][0]["minutes_since"], 30); self.assertEqual(r2["new"], ["D"])
            self.assertEqual(boards.boards(st), ["weibo"]); self.assertEqual(boards.summary(st)[0]["snaps"], 2)


class TestDiscordTelegram(unittest.TestCase):
    def test_discord_messages_and_invite(self):
        rows = [{"id": "2", "timestamp": "2026-09-26T10:00:00.000000+00:00", "content": "Breaking", "embeds": [{"title": "RT", "description": "story", "url": "https://www.rt.com/x"}],
                 "attachments": [{"content_type": "video/mp4"}], "reactions": [{"count": 4}, {"count": 6}], "author": {"id": "1", "username": "someone"}},
                {"id": "1", "timestamp": "2026-09-26T09:00:00+00:00", "content": ""}]
        m = gated.parse_discord_messages(rows, "555", "999")
        self.assertEqual(m[0]["text"], "Breaking\nRT\nstory"); self.assertEqual(m[0]["urls"], ["https://www.rt.com/x"]); self.assertEqual(m[0]["media"], {"video": 1})
        self.assertEqual(m[0]["metrics"]["likes"], 10); self.assertEqual(m[0]["url"], "https://discord.com/channels/999/555/2")
        self.assertNotIn("author", m[0]); self.assertNotIn("someone", json.dumps(m))
        inv = gated.parse_invite({"guild": {"id": "999", "name": "Outlet HQ"}, "approximate_member_count": 12000, "approximate_presence_count": 800, "channel": {"name": "news"}})
        self.assertEqual(inv["members"], 12000); self.assertEqual(inv["guild"], "Outlet HQ")
        self.assertEqual(gated.ANNOUNCEMENT, 5); self.assertIn(0, gated.FORUM_REFUSED)

    def test_telegram_bot_chat(self):
        d = telegram_bot.parse_chat({"ok": True, "result": {"id": -100123, "title": "RT News", "type": "channel", "username": "rt_russian", "description": "d"}})
        self.assertEqual(d["type"], "channel"); self.assertEqual(d["title"], "RT News")
        self.assertFalse(telegram_bot.parse_chat({"ok": False})["ok"])


class TestIranianAndRussian(unittest.TestCase):
    NEXT = '<html><head><meta property="og:title" content="Tasnim"></head><body><script id="__NEXT_DATA__" type="application/json">' + json.dumps({"props": {"pageProps": {"channel": {"title": "Tasnim", "members": 120000},
        "messages": [{"id": 77, "text": "خبر فوری: کنگره آمریکا ...", "date": 1790300000, "views": "12.3K", "photo": {"id": 1}},
                     {"id": 78, "message": "hi", "date": 1790300100, "sender": {"is_user": True}}]}}}) + '</script></body></html>'
    HTML = '<html><meta property="og:title" content="Fars"><div class="counter">45.2K subscribers</div><div class="message" data-message-id="9"><div class="text">Text one <a href="https://farsnews.ir/a">link</a></div><time datetime="2026-09-26T10:00:00+00:00"></time></div></html>'

    def test_channel_pages(self):
        d = ir.parse_channel_page(self.NEXT, "tasnimnews")
        self.assertEqual(d["title"], "Tasnim"); self.assertEqual(len(d["messages"]), 1)          # the user-sent message is dropped
        self.assertEqual(d["messages"][0]["id"], "77"); self.assertEqual(d["messages"][0]["views"], 12300); self.assertEqual(d["messages"][0]["media"], {"photo": 1})
        d2 = ir.parse_channel_page(self.HTML, "farsna")
        self.assertEqual(d2["subscribers"], 45200); self.assertEqual(d2["messages"][0]["id"], "9"); self.assertEqual(d2["messages"][0]["urls"], ["https://farsnews.ir/a"])
        self.assertEqual(d2["messages"][0]["ts"], 1790416800)

    def test_aparat(self):
        v = ir.parse_aparat_videos({"data": [{"type": "Video", "attributes": {"id": 1, "uid": "abc12", "title": "T", "description": "D", "visit_cnt": "1,234", "sdate_rss": "Fri, 26 Sep 2026 10:00:00 +0330"}}]})
        self.assertEqual(v[0]["url"], "https://www.aparat.com/v/abc12"); self.assertEqual(v[0]["views"], 1234); self.assertTrue(v[0]["ts"])
        legacy = ir.parse_aparat_videos({"videobyuser": [{"uid": "zz", "title": "t", "sdate": "2026-09-25T10:00:00+03:30"}]})
        self.assertEqual(legacy[0]["id"], "zz")
        u = ir.parse_aparat_user({"data": {"attributes": {"name": "Press TV", "follower_cnt": "88K", "official": True}}})
        self.assertEqual(u["followers"], 88000); self.assertTrue(u["official"])

    def test_ok_signature_and_stream(self):
        p = {"application_key": "APPKEY", "method": "group.getInfo", "format": "json", "uids": "1", "access_token": "tok", "sig": "old"}
        import hashlib
        exp = hashlib.md5(("application_key=APPKEYformat=jsonmethod=group.getInfouids=1" + "secret").encode()).hexdigest()
        self.assertEqual(ru.ok_sig(p, "secret"), exp)
        t = ru.parse_ok_stream({"entities": {"media_topics": [{"id": "5", "created_ms": 1790300000000, "media": [{"type": "text", "text": "Hello"}, {"type": "link", "url": "https://ria.ru/x", "title": "RIA"}, {"type": "movie"}],
                                                                 "like_summary": {"count": 3}, "discussion_summary": {"comments_count": 2}, "reshare_summary": {"count": 1}}]}})
        self.assertEqual(t[0]["ts"], 1790300000); self.assertEqual(t[0]["text"], "Hello\nRIA"); self.assertEqual(t[0]["urls"], ["https://ria.ru/x"]); self.assertEqual(t[0]["media"], {"video": 1})
        self.assertTrue(ru.dzen_walled(b"<html><div class='SmartCaptcha'></div></html>", "https://dzen.ru/showcaptcha")); self.assertFalse(ru.dzen_walled(b"<rss>", "https://dzen.ru/x/rss"))


class TestDprk(unittest.TestCase):
    PAGE = '<html><body><a href="/en/article/q/abc123.kcmsf">Respected Comrade Kim Jong Un Inspects Factory</a><a href="/en/article/q/abc123.kcmsf">dup</a>' \
           '<a href="/en/about">About</a><a href="http://kcna.kp/en/article/q/def456.kcmsf">US Warmongers Denounced</a></body></html>'

    def test_links_and_dateline(self):
        l = dprk.article_links(self.PAGE, "http://kcna.kp/en")
        self.assertEqual([x["title"] for x in l], ["Respected Comrade Kim Jong Un Inspects Factory", "US Warmongers Denounced"])
        self.assertTrue(l[0]["url"].startswith("http://kcna.kp/en/article/q/"))
        self.assertEqual(dprk.dateline("Pyongyang, September 26 (KCNA) -- The ...", ref=1790400000), 1790424000)
        self.assertEqual(dprk.dateline("Date: 26.09.2026"), 1790424000)
        self.assertIsNone(dprk.dateline("no date here"))
        t, b = dprk.article_body("<html><head><title>KCNA | Title</title><script>x</script></head><body><div>short</div><div><p>A long body paragraph of the article that carries the text.</p></div></body></html>")
        self.assertEqual(t, "KCNA | Title"); self.assertIn("long body", b)
        self.assertEqual(dprk.article_links("<a href='/x'>y</a>", "https://example.com/"), [])


class TestBridgesAndBreakout(unittest.TestCase):
    def test_wechat_album_and_rsshub_rails(self):
        a = bridges.parse_album({"getalbum_resp": {"article_list": [{"title": "T", "url": "https://mp.weixin.qq.com/s/abc", "create_time": "1790300000", "digest": "D", "msgid": "1"}]}})
        self.assertEqual(a[0]["ts"], 1790300000); self.assertEqual(a[0]["id"], "1")
        cfg = {"rsshub": {"enabled": True, "base_url": "https://rsshub.app"}}
        r = bridges.RssHub(cfg["rsshub"], cfg, None)
        self.assertFalse(r.ready()[0])
        cfg = {"rsshub": {"enabled": True, "base_url": "http://127.0.0.1:1200"}}
        r = bridges.RssHub(cfg["rsshub"], cfg, None)
        self.assertTrue(r.ready()[0])
        self.assertEqual(r.route_url("/weibo/user/1"), "http://127.0.0.1:1200/weibo/user/1")
        with self.assertRaises(bridges.HttpError):
            r.route_url("/weibo/search/hot")
        w = bridges.WechatMp({}, {}, None)
        self.assertEqual(w._split("https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzA%3D%3D&action=getalbum&album_id=42"), ("MzA==", "42"))
        self.assertEqual(w._split("MzA==/42"), ("MzA==", "42"))

    def test_tumblr_and_fourchan(self):
        self.assertEqual(breakout_extra.tag_of("No Kings!"), "no kings")
        n, vm = breakout_extra.count_tagged({"response": [{"timestamp": 100, "summary": "take to the streets now"}, {"timestamp": 50, "summary": "x"}]}, since=60)
        self.assertEqual(n, 1)
        fc = breakout_extra.FourChan({"boards": ["pol"]}, {}, None)
        fc.catalog = lambda board: [{"no": 1, "sub": "Thread", "com": "see https://rt.com/usa/1234-ice/ now", "replies": 40, "time": 100, "last_modified": 100, "board": "pol"},
                                    {"no": 2, "sub": "", "com": "unrelated", "replies": 5, "time": 100, "last_modified": 100, "board": "pol"}]
        import time as _t
        _t.sleep = lambda s: None
        r = fc.search("https://www.rt.com/usa/1234-ice/?utm_source=x", kind="url")
        self.assertEqual(r.count, 1); self.assertEqual(r.reach_max, 40)
        r2 = fc.search("unrelated", kind="phrase")
        self.assertEqual(r2.count, 1)


class TestConfigRailsAndPipeline(unittest.TestCase):
    def test_cookie_rail_and_sections(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "config.toml")
            with open(p, "w") as f:
                f.write('[weibo]\nenabled = true\ncookie = "SUB=abc"\n[bilibili]\nvisitor_cookie = true\nsessdata = "x"\n[cn_hotlist]\nboards = ["baidu", "weibo"]\nweibo_cookie = "y"\n')
            import io, contextlib
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                cfg = config.load(p)
            self.assertNotIn("cookie", cfg["weibo"]); self.assertNotIn("sessdata", cfg["bilibili"]); self.assertTrue(cfg["bilibili"]["visitor_cookie"])
            self.assertEqual(cfg["cn_hotlist"]["boards"], ["baidu"]); self.assertIn("dropped", err.getvalue())
            for sect in ("telegram_bot", "weibo", "bilibili", "zhihu", "douyin", "wechat_mp", "rsshub", "bale", "splus", "aparat", "virasty", "ok", "dzen", "max", "dprk_web", "kcnawatch", "tumblr", "fourchan"):
                self.assertIn(sect, cfg, sect)
            self.assertIn("kp_base", cfg["general"]["watchlists"])
            red = config.redacted(dict(cfg, ok={"access_token": "t", "session_secret_key": "s", "application_key": "k"}, tumblr={"api_key": "a"}))
            self.assertEqual(red["ok"]["access_token"], "•••"); self.assertEqual(red["tumblr"]["api_key"], "•••")

    def test_watchlists_import_and_lane_status(self):
        from publius.pipeline import lane_status, probe
        from publius.watchlist import import_watchlists
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            cfg = config.load(os.path.join(d, "none.toml"))
            r = import_watchlists(st, ROOT, ["aggregators", "cn_domestic", "ir_messengers", "kp_base", "discord"])
            bp = r["by_platform"]
            for plat in ("weibo", "bilibili", "zhihu", "douyin", "bale", "splus", "eitaa", "aparat", "dprk_web", "kcnawatch"):
                self.assertGreater(bp.get(plat, 0), 0, plat)
            self.assertEqual({s["country"] for s in st.sources(platform="dprk_web")}, {"KP"})
            self.assertEqual(st.source("weibo:hot")["category"], "domestic_aggregator")
            closed = [s for s in st.sources(platform="dprk_web") if not s["enabled"]]
            self.assertTrue(all(s["status"] == "candidate" for s in closed) and len(closed) == 5)
            self.assertEqual(st.source("wechat_mp:template/0")["status"], "candidate")
            ls = {l["platform"]: l for l in lane_status(cfg, st)}
            self.assertEqual(ls["weibo"]["region"], "cn"); self.assertEqual(ls["dprk_web"]["region"], "kp"); self.assertEqual(ls["ok"]["route_class"], "key")
            self.assertGreater(ls["weibo"]["sources"], 0); self.assertIsNone(ls["weibo"]["probe"])
            self.assertFalse(ls["ok"]["ready"]); self.assertIn("ok.application_key", ls["ok"]["why"])
            # a probe records its result without a network: a lane with no probe URL answers None
            class Dummy(base.Connector):
                platform = "dummy"; label = "d"
            base.REGISTRY["dummy"] = Dummy
            try:
                out = probe(cfg, st, ["dummy"])
                self.assertIsNone(out["dummy"]["ok"]); self.assertIn("ts", out["dummy"])
                self.assertEqual(json.loads(st.kv_get("probe:dummy"))["ok"], None)
            finally:
                base.REGISTRY.pop("dummy", None)

    def test_snapshot_and_pack_schema_2(self):
        from publius.analysis.ghostloom import bridge_pack
        from publius.pipeline import snapshot
        from publius.watchlist import import_watchlists
        from publius.store import Post
        from publius.util import now
        with tempfile.TemporaryDirectory() as d:
            st = Store(d)
            cfg = config.load(os.path.join(d, "none.toml"))
            import_watchlists(st, ROOT, ["kp_base", "cn_domestic"])
            src = st.source("dprk_web:http://kcna.kp/en")
            st.add_post(Post(id="p1", source_id=src["id"], ts=now() - 3600, text="US warmongers denounced in AI weapons row", title="", url="http://kcna.kp/en/article/q/1.kcmsf", lang="en", platform="dprk_web", country="KP", category="media"))
            boards.record(st, "weibo", [{"title": "美国政府停摆", "heat": 5, "rank": 1}], ts=now())
            snap = snapshot(cfg, st, days=7)
            self.assertIn("KP", snap["by_actor"]); self.assertEqual(snap["by_actor"]["KP"]["posts"], 1)
            self.assertIn("KP|all|all", snap["panels"]); self.assertEqual(snap["boards"][0]["board"], "weibo")
            pack = bridge_pack(snap)
            self.assertEqual(pack["schema"], 2); self.assertEqual(pack["by_actor"]["KP"]["posts"], 1); self.assertEqual(pack["boards"][0]["n"], 1)
            lane = next(l for l in pack["lanes"] if l["platform"] == "dprk_web")
            self.assertEqual(lane["region"], "kp"); self.assertEqual(lane["new_in"], "2.0"); self.assertTrue(lane["reads"])
            self.assertEqual(pack["kind"], "publius-ghostloom-pack")


if __name__ == "__main__":
    unittest.main(verbosity=2)
